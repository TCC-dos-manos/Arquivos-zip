<?php
    include_once '../model/DAO/EmpresaDAO.php';
    include_once '../model/DAO/conexao.php';
    
    

    $empresaDAO = new EmpresaDAO($conexao);
    $edita = $empresaDAO->consultarId($_GET['cnpj']);
    var_dump($edita);
    echo $edita['razao'];

    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
    <nav>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="cadastrarEmpresa.php">Cadastrar</a></li>
            <li><a href="consultarEmpresa.php">Consultar</a></li>
        </ul>

    </nav>
</header>

<h1>Alterar Empresa</h1>


<form method="POST" action="../control/alterarEmpresaControl.php">

    <label>CNPJ: </label>
    <input type="text" name="cnpj" value="<?= $edita->__getCNPJ() ?>">
    <br><br>
    
    <label>Razão social: </label>    
    <input type="text" name="razao" value="<?= $edita->__getRazao() ?>"/>
    <br><br>
    
    <label>Endereço do Empresa: </label>    
    <input type="text" name="endereco" value="<?= $edita->__getEndereco() ?>"/>
    <br><br>

    <label>Bairro do Empresa: </label>    
    <input type="text" name="bairro" value="<?= $edita->__getBairro() ?>"/>
    <br><br>

    <label>CEP do Empresa: </label>    
    <input type="number" name="cep" value="<?= $edita->__getCep() ?>"/>
    <br><br>

    <label>Situação: </label>
    <input type="radio" name="situacao" value="ativa"><label>Ativa</label>
    <input type="radio" name="situacao" value="inativa"><label>Inativa</label>
    <input type="radio" name="situacao" value="pendente"><label>Pendente</label>
    <br><br>

    <input type="submit" value="Alterar " name="btnCadastrar"/>
    
 
</form>



</body>
</html>