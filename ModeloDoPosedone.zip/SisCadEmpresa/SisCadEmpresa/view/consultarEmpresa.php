<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
    <nav>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="cadastrarEmpresa.php">Cadastrar</a></li>
            <li><a href="consultarEmpresa.php">Consultar</a></li>
        </ul>

    </nav>
    <h1>Consultar Empresa</h1>
    <table>
        <tr>
            <th>CNPJ</th>
            <th>RAZÃO</th>
            <th>ENDEREÇO</th>
            <th>BAIRRO</th>
            <th>CEP</th>
            <th>SITUAÇÃO</th>
        </tr>
        <?php    require_once '../model/DTO/EmpresaDTO.php';
                 require_once '../control/consultarEmpresaControl.php';
        
        $listaEmpresas = $empresaDTO->__getListaEmpresas();
        if ($listaEmpresas != null){
            foreach($listaEmpresas as $empresa) : ?>
                <tr>
                    <td><?= $empresa['cnpj'] ?></td>
                    <td><?= $empresa['razao'] ?></td>
                    <td><?= $empresa['endereco'] ?></td>
                    <td><?= $empresa['bairro'] ?></td>
                    <td><?= $empresa['cep'] ?></td>   
                    <td><?= $empresa['situacao']?></td>
                    <td><button><a href="../control/excluirEmpresaControl.php?cnpj=<?= $empresa['cnpj']?>"> Excluir </a></button></td>   
                    <td><button><a href="../view/alterarEmpresa.php?cnpj=<?= $empresa['cnpj']?>"> Alterar </a></button></td>      
                </tr>
        <?php endforeach  ; } ?>
    </table>
</body>
</html>