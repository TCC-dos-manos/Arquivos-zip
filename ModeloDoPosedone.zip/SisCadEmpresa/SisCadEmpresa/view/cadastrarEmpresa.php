<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>
    <nav>
        <ul>
            <li><a href="../index.php">Home</a></li>
            <li><a href="cadastrarEmpresa.php">Cadastrar</a></li>
            <li><a href="consultarEmpresa.php">Consultar</a></li>
        </ul>

    </nav>
</header>

<h1>Cadastrar Empresa</h1>

<form method="POST" action="../control/cadastrarEmpresaControl.php">

    <label>CNPJ: </label>
    <input type="number" name="cnpj">
    <br><br>

    <label>Razão social: </label>    
    <input type="text" name="razao"/>
    <br><br>
    
    <label>Endereço da Empresa: </label>    
    <input type="text" name="endereco"/>
    <br><br>

    <label>Bairro da Empresa: </label>    
    <input type="text" name="bairro"/>
    <br><br>

    <label>CEP da Empresa: </label>    
    <input type="number" name="cep"/>
    <br><br>

    <label>Situação: </label>
    <input type="radio" name="situacao" value="ativa"><label>Ativa</label>
    <input type="radio" name="situacao" value="inativa"><label>Inativa</label>
    <input type="radio" name="situacao" value="pendente"><label>Pendente</label>
    <br><br>

    <input type="submit" value="Cadastrar" name="btnCadastrar"/>
    <input type="hidden" name="cnpj"/>
</form>



</body>
</html>