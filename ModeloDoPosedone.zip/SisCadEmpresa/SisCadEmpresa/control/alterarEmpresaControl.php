<?php

    require_once '../model/DTO/EmpresaDTO.php';
    require_once '../model/DAO/EmpresaDAO.php';
    require_once '../model/DAO/conexao.php';

    if (!empty($_POST['idAlterar'])){

        $cnpj = $_POST['idAlterar'];

        $empresaDAO = new EmpresaDAO($conexao);
        $empresaDAO->consultarId($cnpj);

        $empresaDTO = new EmpresaDTO();
        $empresaDTO->__setNome($_POST['nome']);
        $empresaDTO->__setEndereco($_POST['endereco']);
        $empresaDTO->__setBairro($_POST['bairro']);
        $empresaDTO->__setCep($_POST['cep']);
        $empresaDTO->__setSituacao($_POST['situacao']);
    
       $empresaDAO->alterarEmpresa($empresaDTO, $cnpj);
    }
    header("Location: ../view/consultarEmpresa.php");
?>