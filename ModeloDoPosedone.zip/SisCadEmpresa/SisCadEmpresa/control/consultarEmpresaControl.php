<?php
    require_once '../model/DTO/EmpresaDTO.php';
    require_once '../model/DAO/EmpresaDAO.php';
    require_once '../model/DAO/conexao.php';

    $empresaDTO = new EmpresaDTO();
    $empresaDAO = new EmpresaDAO($conexao);
    $empresaDAO->consultarEmpresa($empresaDTO);
    
?>