<?php

    require_once '../model/DTO/EmpresaDTO.php';
    require_once '../model/DAO/EmpresaDAO.php';
    require_once '../model/DAO/conexao.php';

    if (!empty($_GET['cnpj'])){

        $cnpj = $_GET['cnpj'];

        $empresaDAO = new EmpresaDAO($conexao);
        $empresaDAO->excluirEmpresa( $cnpj);
    }
     header("Location: ../view/consultarEmpresa.php");
?>