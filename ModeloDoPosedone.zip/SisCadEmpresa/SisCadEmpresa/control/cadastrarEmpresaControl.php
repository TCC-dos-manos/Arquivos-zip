<?php
    require_once '../model/DTO/EmpresaDTO.php';
    require_once '../model/DAO/EmpresaDAO.php';
    require_once '../model/DAO/conexao.php';
    

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if($_POST['btnCadastrar']){
            $empresaDTO = new EmpresaDTO();
            $empresaDTO->__setCNPJ($_POST['cnpj']);
            $empresaDTO->__setRazao($_POST['razao']);
            $empresaDTO->__setEndereco($_POST['endereco']);
            $empresaDTO->__setBairro($_POST['bairro']);
            $empresaDTO->__setCep($_POST['cep']);
            $empresaDTO->__setSituacao($_POST['situacao']);
            
            $empresaDAO = new EmpresaDAO($conexao);
            $empresaDAO->cadastrarEmpresa($empresaDTO);
        }

        header("Location: ../view/consultarEmpresa.php");
    }

   


?>