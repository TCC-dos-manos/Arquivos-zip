<?php
    //require_once 'conexao.php';
    
    class EmpresaDAO{
        public $conexao;

        public function __construct($conexao){
           $this->conexao = $conexao;
        }

        public function cadastrarEmpresa($empresaDTO){
            
            try{
                $sql = 'INSERT INTO empresa (cnpj, razao , endereco , bairro , cep, situacao) VALUES (:cnpj, :razao, :endereco , :bairro , :cep, :situacao)';
            
                $insert = $this->conexao->prepare($sql);

                $cnpj = $empresaDTO->__getCNPJ();
                $razao = $empresaDTO->__getRazao();
                $endereco = $empresaDTO->__getEndereco();
                $bairro = $empresaDTO->__getBairro();
                $cep = $empresaDTO->__getCep();
                $situacao = $empresaDTO->__getSituacao();

                $insert->bindValue(":cnpj",$cnpj);
                $insert->bindValue(":razao",$razao);
                $insert->bindValue(":endereco",$endereco);
                $insert->bindValue(":bairro",$bairro);
                $insert->bindValue(":cep",$cep);
                $insert->bindValue(":situacao", $situacao);

                if($insert->execute()){
                    echo "Empresa Cadastrado com Sucesso!!!!!";
                }else{
                    echo "Erro ao Cadastrar Empresa!!!!!";
                }

            }catch (PDOException $erro){

            }
            
        }
        
        public function consultarEmpresa($empresaDTO){
            try{

                $sql = 'SELECT * FROM empresa';
                $consulta = $this->conexao->prepare($sql);
                if($consulta->execute()){
                    if($consulta->rowcount() > 0){
                        $listaEmpresas = $consulta->fetchAll();
                        $empresaDTO->__setListaEmpresas($listaEmpresas);
                    }
                }else{
                    echo "Erro ao Consultar Empresas";
                }

            }catch(PDOException $erro){

            }

        }

        public function consultarId(int $cnpj){
            include_once '../model/DTO/EmpresaDTO.php';
        
            $sql = 'SELECT * FROM empresa WHERE cnpj = :cnpj';
            $consultaId = $this->conexao->prepare($sql);
            $consultaId->bindValue(":cnpj",$cnpj);
            $consultaId->execute();
        
            return $consultaId->fetchObject("EmpresaDTO");
        }

        public function excluirEmpresa($cnpj){
            try{

                $sql = 'DELETE FROM empresa WHERE cnpj = :cnpj';
                $delete = $this->conexao->prepare($sql);
                $delete->bindValue(":cnpj",$cnpj);
                $delete->execute();

            }catch(PDOException){

            }
        }

         public function alterarEmpresa($empresaDTO, $cnpj){
            try{

                $sql = 'UPDATE empresa SET razao=:razao, endereco=:endereco, bairro=:bairro, cep=:cep WHERE cnpj=:cnpj';
                $altera = $this->conexao->prepare($sql);

                $razao = $empresaDTO->__getRazao();
                $endereco = $empresaDTO->__getEndereco();
                $bairro = $empresaDTO->__getBairro();
                $cep = $empresaDTO->__getCep();
                $situacao = $empresaDTO->getSituacao();
                
                $altera->bindValue(":razao",$razao);
                $altera->bindValue(":endereco",$endereco);
                $altera->bindValue(":bairro",$bairro);
                $altera->bindValue(":cep",$cep);
                $altera->bindValue(":cnpj",$cnpj);
                $altera->bindValue(":situacao", $situacao);

                $altera->execute();

            }catch(PDOException){

            }
        }

       
        
    }
?>