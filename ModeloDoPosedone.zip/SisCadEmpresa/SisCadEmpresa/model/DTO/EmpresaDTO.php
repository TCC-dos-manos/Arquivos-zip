<?php
require_once '../model/DAO/EmpresaDAO.php';
    class EmpresaDTO{
        private $cnpj;
        private $razao;
        private $endereco;
        private $bairro;
        private $cep;
        private $situacao;
        private $listaEmpresa;

        public function __construct(){

        }

        public function __getCNPJ(){
            return $this->cnpj;
        }

        public function __setCNPJ($cnpj){
            return $this->cnpj = $cnpj;
        }

        public function __getRazao(){
            return $this->razao;
        }

        public function __setRazao($razao){
            return $this->razao = $razao;
        }

        public function __getEndereco(){
            return $this->endereco;
        }

        public function __setEndereco($endereco){
            return $this->endereco = $endereco;
        }

        public function __getBairro(){
            return $this->bairro;
        }

        public function __setBairro($bairro){
            $this->bairro = $bairro; 
        }

        public function __getCep(){
            return $this->cep;
        }

        public function __setCep($cep){
            $this->cep = $cep;
        }

        public function __getSituacao(){
            $this->situacao = $situacao;
        }

        public function __setSituacao($situacao){
            $this->situacao = $situacao;
        }

        public function __setListaEmpresas($listaEmpresa){
            $this->listaEmpresa = $listaEmpresa;
        }

        public function __getListaEmpresas(){
            return $this->listaEmpresa;
        }

        public function __getById(int $cnpj){

            $empresaDAO = new EmpresaDAO();

            $empresaDAO = $EmpresaDAO->consultarId((int) $_GET['cnpj'] );

            var_dump($empresaDAO);

        }
    }
?>