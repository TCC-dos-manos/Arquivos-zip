<?php
// 1. Sair da pasta controller (../) 
// 2. Entrar na model/dao/ e model/dto/
require_once '../model/dao/UsuarioDao.php'; 
require_once '../model/dto/UsuarioDto.php'; 

$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

$usuarioDao = new UsuarioDao();
$sucesso = $usuarioDao->validarLogin($email, $senha);

if ($sucesso) {
  if(($_POST['email'] == "admin@gmail.com") && ($_POST['senha'] == '1234')) {
  
  echo "<script>
            alert('Bem vindo adm');
            window.location.href='../admin/home.html'; // Vai para a página de administração
          </script>";

  } else {
    echo "<script>
            alert('Logado com sucesso!');
            window.location.href='../main/home.html'; // Volta para a raiz do projeto
          </script>";
          }
} else {
    echo "<script>
            alert('Usuário não existe ou senha incorreta.');
            window.location.href='../view/login.php'; // Volta para a tela de login
          </script>";
}
?>