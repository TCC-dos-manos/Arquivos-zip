<?php
    //aqui será a parte onde ficará o card do usuário 
    require_once "controller/ViewUserControl.php";  
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/card.css">
    <title>Warpfiy</title>
</head>
<body>


    <div class="profile">
        <img src="../assets/src/warpfiyLogo.png">
        <div> <h1> <?php echo $usuario['nome']; ?> <?php echo $usuario['email']; ?> </h1> </div>
    </div>

    
</body>
</html>