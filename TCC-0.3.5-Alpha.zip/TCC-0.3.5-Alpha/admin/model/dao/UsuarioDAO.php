<?php

  require_once __DIR__ . '/../Conexao.php';
  require_once __DIR__ . '/../dto/UsuarioDTO.php';

class UsuarioDAO {
  private $pdo = null;
  
   public function __construct() {
  $this->pdo = Conexao::getInstance();
 }


// 1. Busca um usuário específico para preencher o formulário de edição
public function buscarUsuarioPorID($id) {
   try {
       $sql = "SELECT nome, email FROM usuario WHERE id = :id";
       $stmt = $this->pdo->prepare($sql);
       $stmt->bindValue(':id', $id, PDO::PARAM_INT);
       $stmt->execute();
       return $stmt->fetch(PDO::FETCH_ASSOC); 
   } catch (PDOException $e) {
       return null;
   }  
}
}
?>