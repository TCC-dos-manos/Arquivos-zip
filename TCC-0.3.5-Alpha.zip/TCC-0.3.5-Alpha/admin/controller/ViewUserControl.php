<?php
require_once "model/dao/UsuarioDAO.php";
$usuarioDAO = new UsuarioDAO();
$usuario = $usuarioDAO->buscarUsuarioPorID($_GET['id']);
?>