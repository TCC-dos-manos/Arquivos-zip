<?php
    //aqui será a parte onde ficará o card do usuário 
    require_once "../controller/ListarUsuariosControl.php";  
?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/card.css">
    <title>Warpfiy</title>
</head>
<body>

    <?php foreach ($todosUsuarios as $usuario) { ?>

    <div class="profile">
    <img src="../assets/src/warpfiyLogo.png">
    <h1></h1>
    </div>

    <?php } ?>

    
</body>
</html>