<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Cadastro de Usuário</title>
        <link rel="stylesheet" href="../assets/css/style.css">
    </head>

<body> 

<h2>
   <a href="home.html" class="ab">Home</a>
   <a href="cadastroUsuario.php">Cadastro</a>
   <a href="login.php">Login</a>
   <a href=""><button class="perfil">Perfil</button></a>
</h2>

<center>
 
    <h1>Cadastro de Usuário</h1>
        <form action="../controller/CadastroUsuarioControl.php" method="POST" class="login">
  
<!-- Nome -->
   <label for="nome">Nome:</label><br>
      <input type="text" name="nome" required><br><br>
  
<!-- E-mail -->
   <label for="email">E-mail:</label><br>
      <input type="email" name="email" required><br><br>
  
<!-- Senha -->
   <label for="senha">Senha:</label><br>
      <input type="password" name="senha" required><br><br>
  
<!-- Botão de envio -->
   <input type="submit" value="Cadastrar">


   <br>

   <h2>
      <a href="ListarUsuarios.php">
         <button type="button" class = "loginbutton">Ver Usuarios Cadastrados</button>
      </a>

      <a href="login.php">
         <button type="button" class = "loginbutton">Login</button>
      </a>

   </h2>

      </form>

    </center>
</body>
</html>
