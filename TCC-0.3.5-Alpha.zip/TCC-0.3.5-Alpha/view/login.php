<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<h2><a href="home.html" class="">Home</a>  <a href="cadastroUsuario.php">Cadastro</a>    <a href="login.php">Login</a>  <a href=""><button class="perfil">Perfil</button></a> </h2>
<form action="../controller/loginControl.php" method="POST">
    <label for="email">E-mail:</label>
    <input type="email" name="email" id="email" required>

    <label for="senha">Senha:</label>
    <input type="password" name="senha" id="senha" required>

    <input type="submit" value="Logar">
</form>


    
</body>
</html>