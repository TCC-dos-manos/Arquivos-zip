/* Usando JQUERY */

$(document).ready(function() {
    $('#mobile-btn').on('click' , function () {
        $('#mobile-menu').toggleClass('active');
        $('#mobile-btn').find('i').toggleClass('fa-caret-right');
    });
});

document.addEventListener('DOMContentLoaded', () => {

    // ============================================================
    // FUNÇÃO GLOBAL PARA TOAST NOTIFICATIONS
    // ============================================================
    window.showToast = (message) => {
        const toast = document.createElement('div');
        toast.className = 'toast-notification';
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => { toast.remove(); }, 4000);
    };

    // ============================================================
    // 0. CARROSSEL PRINCIPAL
    // ============================================================
    const startAutoSlider = () => {
        const sliderImgs = document.querySelectorAll('.img-slider');
        const navBtns = document.querySelectorAll('.btn-nav');
        let current = 0;
        if (!sliderImgs.length) return;

        const changeSlide = (index) => {
            sliderImgs.forEach(img => img.classList.remove('on'));
            navBtns.forEach(btn => btn.classList.remove('on'));
            sliderImgs[index].classList.add('on');
            navBtns[index].classList.add('on');
            current = index;
        };

        document.getElementById('next-btn')?.addEventListener('click', () => changeSlide((current + 1) % sliderImgs.length));
        document.getElementById('prev-btn')?.addEventListener('click', () => changeSlide((current - 1 + sliderImgs.length) % sliderImgs.length));
        navBtns.forEach((btn, i) => btn.addEventListener('click', () => changeSlide(i)));
        setInterval(() => changeSlide((current + 1) % sliderImgs.length), 5000);
    };
    startAutoSlider();

    // ============================================================
    // 1. MINI-CARROSSEL DO CARD
    // ============================================================
    const miniSlider = document.querySelector('.mini-slider');
    if (miniSlider) {
        const imgs = miniSlider.querySelectorAll('.img-box');
        let current = 0;
        const updateMini = (index) => {
            imgs.forEach(img => img.classList.remove('on'));
            imgs[index].classList.add('on');
            current = index;
        };
        miniSlider.querySelector('.mini-next').onclick = (e) => {
            e.stopPropagation();
            updateMini((current + 1) % imgs.length);
        };
        miniSlider.querySelector('.mini-prev').onclick = (e) => {
            e.stopPropagation();
            updateMini((current - 1 + imgs.length) % imgs.length);
        };
    }

    // ============================================================
    // 2. SISTEMA DE ESTRELAS (abre ao clique, toast ao avaliar)
    // ============================================================
    const starWrapper = document.querySelector('.main-star-wrapper');
    if (starWrapper) {
        const stars = starWrapper.querySelectorAll('.star-options i');
        const avgDisp = starWrapper.querySelector('.rating-avg');
        const countDisp = starWrapper.querySelector('.rating-count');
        const starOptions = starWrapper.querySelector('.star-options');

        let ratings = JSON.parse(sessionStorage.getItem('w-ratings')) || [4.8, 5.0, 4.5, 4.7];
        let userRatingIdx = sessionStorage.getItem('w-user-rating-idx');

        const updateStarsVisual = (val) => {
            stars.forEach(s => {
                s.classList.toggle('active', parseInt(s.dataset.value) <= val);
            });
        };

        const updateData = () => {
            const avg = (ratings.reduce((a, b) => a + b, 0) / ratings.length).toFixed(1);
            avgDisp.innerText = avg;
            countDisp.innerText = `(${ratings.length})`;
            if (userRatingIdx !== null) updateStarsVisual(ratings[userRatingIdx]);
        };
        updateData();

        starWrapper.onclick = (e) => {
            e.stopPropagation();
            starOptions.style.display = starOptions.style.display === 'flex' ? 'none' : 'flex';
        };

        document.addEventListener('click', (e) => {
            if (!starWrapper.contains(e.target)) {
                starOptions.style.display = 'none';
            }
        });

        stars.forEach(s => {
            s.onmouseenter = () => {
                const val = parseInt(s.dataset.value);
                stars.forEach(st => st.classList.toggle('hover', parseInt(st.dataset.value) <= val));
            };
            s.onmouseleave = () => stars.forEach(st => st.classList.remove('hover'));

            s.onclick = (e) => {
                e.stopPropagation();
                const val = parseInt(s.dataset.value);
                if (userRatingIdx !== null) {
                    ratings[userRatingIdx] = val;
                } else {
                    ratings.push(val);
                    userRatingIdx = ratings.length - 1;
                    sessionStorage.setItem('w-user-rating-idx', userRatingIdx);
                }
                sessionStorage.setItem('w-ratings', JSON.stringify(ratings));
                updateData();
                starOptions.style.display = 'none';
                window.showToast('Avaliação Recebida! ⭐ Você avaliou com ' + val + ' estrelas.');
            };
        });
    }

    // ============================================================
    // 3. EFEITO FLIP + SINCRONIZAÇÃO VISUAL: BOTÕES <-> CARD
    // ============================================================
    //
    // Mapeamento (8 botões):
    //   Botão 0 "Título"      -> .tag-title h2
    //   Botão 1 "Tag"         -> .categoria-artistica
    //   Botão 2 "Perfil"      -> .profile-img
    //   Botão 3 "Imagem"      -> .card-img
    //   Botão 4 "Descrição"   -> .descricao
    //   Botão 5 "Avaliar"     -> .main-star-wrapper
    //   Botão 6 "Comentário"  -> .bottom-action (ícone de comentário)
    //   Botão 7 "Saiba Mais"  -> .saiba-mais
    //
    const explanationNodes = document.querySelectorAll('.explanation-node');
    const commentActionDiv = document.querySelector('#openComment').parentElement;

    const cardTargets = [
        document.querySelector('.tag-title h2'),           // 0: Título
        document.querySelector('.categoria-artistica'),     // 1: Tag
        document.querySelector('.profile-img'),             // 2: Perfil
        document.querySelector('.card-img'),                // 3: Imagem
        document.querySelector('.texto-descricao'),        // 4: Descrição
        document.querySelector('.main-star-wrapper'),       // 5: Avaliar
        commentActionDiv,                                   // 6: Comentário
        document.querySelector('.saiba-mais')               // 7: Saiba Mais
    ];

    // Tipo de efeito cinza por índice
    // text = muda cor do texto, element = filtro grayscale, btn = filtro grayscale
    const grayTypes = [
        'text',    // 0: Título
        'text',    // 1: Tag
        'element', // 2: Perfil
        'element', // 3: Imagem
        'text',    // 4: Descrição
        'btn',     // 5: Avaliar
        'btn',     // 6: Comentário
        'btn'      // 7: Saiba Mais
    ];

    let activeNodeIndex = -1;

    const clearAllHighlights = () => {
        explanationNodes.forEach(node => {
            node.classList.remove('selected');
        });
        cardTargets.forEach(target => {
            if (!target) return;
            target.classList.remove('card-element-grayed');
            target.classList.remove('card-text-grayed');
            target.classList.remove('card-btn-grayed');
        });
    };

    const applyHighlight = (index) => {
        const target = cardTargets[index];
        if (!target) return;

        const type = grayTypes[index];
        if (type === 'text') {
            target.classList.add('card-text-grayed');
        } else if (type === 'element') {
            target.classList.add('card-element-grayed');
        } else if (type === 'btn') {
            target.classList.add('card-btn-grayed');
        }
    };

    explanationNodes.forEach((node, index) => {
        node.addEventListener('click', () => {
            if (activeNodeIndex === index) {
                // Toggle off: desseleciona e remove flip
                clearAllHighlights();
                node.classList.remove('flipped');
                activeNodeIndex = -1;
            } else {
                // Limpa anterior
                clearAllHighlights();
                if (activeNodeIndex >= 0) {
                    explanationNodes[activeNodeIndex].classList.remove('flipped');
                }
                // Ativa novo
                node.classList.add('selected');
                node.classList.add('flipped');
                applyHighlight(index);
                activeNodeIndex = index;
            }
        });
    });

    // ============================================================
    // 4. MODAIS E LIGHTBOX
    // ============================================================
    const cModal = document.getElementById('commentModal');
    const sModal = document.getElementById('saibaMaisModal');
    const lBox = document.getElementById('lightbox');
    const lImg = document.getElementById('lightboxImg');
    let galleryImgs = [];
    let currentGalleryIdx = 0;
    let userCommented = false;

    // --- BOTÃO DE COMENTÁRIO DO CARD ---
    const openCommentBtn = document.getElementById('openComment');
    openCommentBtn.addEventListener('click', () => {
        if (userCommented) {
            document.getElementById('errorCommentModal').classList.add('active');
        } else {
            cModal.classList.add('active');
        }
    });

    // --- BOTÃO CANCELAR DO MODAL DE COMENTÁRIO ---
    document.getElementById('closeComment').addEventListener('click', () => {
        cModal.classList.remove('active');
    });

    // --- SAIBA MAIS ---
    document.getElementById('openSaibaMais').onclick = () => {
        updateModalComments();
        sModal.style.display = 'flex';
        galleryImgs = Array.from(sModal.querySelectorAll('.gallery-item img')).map(img => img.src);
    };

    document.getElementById('closeSaibaMais').onclick = () => {
        sModal.style.display = 'none';
    };

    // --- LIGHTBOX ---
    document.addEventListener('click', (e) => {
        if (e.target.closest('.gallery-item img')) {
            currentGalleryIdx = galleryImgs.indexOf(e.target.src);
            lImg.src = galleryImgs[currentGalleryIdx];
            lBox.style.display = 'flex';
        }
    });

    document.getElementById('closeLightbox').onclick = () => lBox.style.display = 'none';
    document.getElementById('prevLightbox').onclick = () => {
        currentGalleryIdx = (currentGalleryIdx - 1 + galleryImgs.length) % galleryImgs.length;
        lImg.src = galleryImgs[currentGalleryIdx];
    };
    document.getElementById('nextLightbox').onclick = () => {
        currentGalleryIdx = (currentGalleryIdx + 1) % galleryImgs.length;
        lImg.src = galleryImgs[currentGalleryIdx];
    };

    // ============================================================
    // 5. ENVIO DE COMENTÁRIO (único por card)
    // ============================================================
    document.getElementById('sendComment').onclick = () => {
        const text = document.getElementById('commentText').value;

        if (text.trim()) {
            let list = JSON.parse(sessionStorage.getItem('w-comments')) || [];
            list.push(text);
            sessionStorage.setItem('w-comments', JSON.stringify(list));
            document.getElementById('commentText').value = '';
            cModal.classList.remove('active');
            userCommented = true;

            // Ícone de comentário preenchido
            const commentIcon = document.getElementById('openComment');
            commentIcon.classList.add('commented');
            commentIcon.classList.remove('fa-regular');
            commentIcon.classList.add('fa-solid');

            window.showToast('Comentário Enviado! 💬 Seu feedback foi salvo.');
            updateModalComments();
        }
    };

    // ============================================================
    // 6. MODAL DE AVISO (comentário duplicado + botão de dúvida)
    // ============================================================
    const errorCommentModal = document.getElementById('errorCommentModal');
    const errorContent = errorCommentModal.querySelector('.error-content');

    const editHelpBtn = document.createElement('button');
    editHelpBtn.textContent = '❓ Como edito meu comentário?';
    editHelpBtn.style.cssText = 'margin-top: 10px; background: #f0f0f0; color: #333; border: none; padding: 10px 15px; border-radius: 8px; cursor: pointer; font-weight: 600; transition: all 0.3s ease; width: 100%;';
    editHelpBtn.onmouseover = () => { editHelpBtn.style.background = '#e0e0e0'; };
    editHelpBtn.onmouseout = () => { editHelpBtn.style.background = '#f0f0f0'; };
    editHelpBtn.onclick = () => {
        errorCommentModal.classList.remove('active');
        document.getElementById('editHelpModal').classList.add('active');
    };
    errorContent.appendChild(editHelpBtn);

    // ============================================================
    // 7. COMENTÁRIOS NO SAIBA MAIS + BOTÃO EDITAR -> ADM
    // ============================================================
    function updateModalComments() {
        const userCommentSection = document.getElementById('userCommentSection');
        let list = JSON.parse(sessionStorage.getItem('w-comments')) || [];

        if (list.length > 0) {
            userCommentSection.style.display = 'block';
            document.getElementById('userCommentText').textContent = list[list.length - 1];
        }
    }

    document.addEventListener('click', (e) => {
        if (e.target.id === 'editCommentBtn' || e.target.closest('#editCommentBtn')) {
            document.getElementById('admRequestModal').classList.add('active');
        }
    });

    // ============================================================
    // 8. TAGS CLICÁVEIS
    // ============================================================
    const tags = document.querySelectorAll('.categoria-artistica a');
    tags.forEach(tag => {
        tag.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('tagFilterModal').classList.add('active');
        });
    });

    // ============================================================
    // 9. PERFIL CRIATIVO v2
    // ============================================================
    const fModal = document.getElementById('funModal');
    window.showFun = (title, text, btns) => {
        document.getElementById('funTitle').innerText = title;
        document.getElementById('funText').innerHTML = text;
        document.getElementById('funBtns').innerHTML = btns;
        fModal.style.display = 'flex';
    };

    document.querySelector('.user-profile').onclick = () => {
        window.showFun("Conheça o Especialista",
            "Deseja ver o perfil detalhado do colaborador Perk?",
            '<button class="btn-fun btn-skip" onclick="window.showProfileV2()">Ver prévia do perfil</button>' +
            '<button class="btn-fun btn-skip" style="background:#7f1615" onclick="document.getElementById(\'funModal\').style.display=\'none\'">Fechar</button>');
    };

    window.showProfileV2 = () => {
        const profileHTML = '<div class="warpfiy-profile-v2" style="margin: 0 auto; position: relative;">' +
            '<button onclick="document.getElementById(\'funModal\').style.display=\'none\'" style="position: absolute; top: 15px; right: 15px; background: #7f1615; color: #fff; border: none; border-radius: 50%; width: 35px; height: 35px; cursor: pointer; z-index: 10; font-weight: bold;">✕</button>' +
            '<div class="v2-sidebar">' +
                '<img src="../assets/src/card/pfp/Netulin.png" style="width:140px; height:140px; border-radius:50%; border:5px solid rgba(255,255,255,0.3); margin-bottom:15px;">' +
                '<h2 style="margin:0; font-size: 24px;">Perk</h2>' +
                '<p style="opacity:0.9; font-size: 14px;">Colaborador Verificado</p>' +
                '<div style="margin-top:20px; display: flex; flex-wrap: wrap; justify-content: center;">' +
                    '<div class="v2-badge">🛡️ Segurança</div>' +
                    '<div class="v2-badge">💎 Elite</div>' +
                    '<div class="v2-badge">⭐ 4.9</div>' +
                '</div>' +
            '</div>' +
            '<div class="v2-main">' +
                '<h3 style="color:#7f1615; margin-top:0; font-size: 22px;">Biografia Profissional</h3>' +
                '<p style="color:#444; line-height:1.6; font-size: 15px; margin-bottom: 20px;">Especialista em design para eventos e identidades visuais. Atua na Warpfiy garantindo que cada card seja uma obra de arte única. Cumpre rigorosamente todos os requisitos de segurança, prazos e padrões de qualidade da plataforma.</p>' +
                '<h4 style="color:#7f1615; margin-bottom: 10px;">Regras de Negócio Aplicadas</h4>' +
                '<ul style="color:#555; font-size:14px; padding-left:20px; line-height: 1.8;">' +
                    '<li>Verificação de identidade e antecedentes concluída.</li>' +
                    '<li>Sistema de avaliações auditado pela comunidade.</li>' +
                    '<li>Suporte prioritário e garantia de entrega Warpfiy.</li>' +
                    '<li>Nível de experiência comprovado em projetos reais.</li>' +
                '</ul>' +
                '<div style="margin-top:30px; border-top: 1px solid #eee; padding-top: 20px;">' +
                    '<button class="btn-fun btn-skip" onclick="document.getElementById(\'funModal\').style.display=\'none\'">Voltar ao Tutorial</button>' +
                '</div>' +
            '</div>' +
        '</div>';
        window.showFun("", "", profileHTML);
    };

    document.querySelector('.btn-login').onclick = () =>
        window.showFun("Bem-vindo! 🚀", "Preparamos um tutorial interativo para você. Deseja pular e ir direto para o login?",
            '<button class="btn-fun btn-skip" onclick="document.getElementById(\'funModal\').style.display=\'none\'">Continuar Tutorial</button>' +
            '<button class="btn-fun btn-login-now">Logar Direto</button>');

    // ============================================================
    // 10. BOTÃO ME INTERESSEI E PERFIL NO MODAL SAIBA MAIS
    // ============================================================
    const meInteresseiBtnModal = document.getElementById('meInteresseiBtnModal');
    if (meInteresseiBtnModal) {
        meInteresseiBtnModal.onclick = () => {
            document.getElementById('meInteresseModal').style.display = 'flex';
        };
    }

    const openProfileFromModal = document.getElementById('openProfileFromModal');
    if (openProfileFromModal) {
        openProfileFromModal.onclick = () => {
            window.showProfileV2();
        };
    }

    // ============================================================
    // 11. SMOOTH SCROLL PARA NAVEGAÇÃO DO HEADER + LOGO
    // ============================================================
    const allScrollLinks = document.querySelectorAll('a[href^="#"]');
    allScrollLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href');
            if (targetId && targetId !== '#') {
                e.preventDefault();
                const targetEl = document.querySelector(targetId);
                if (targetEl) {
                    // Troca imediata do active no header ao clicar
                    const parentNavItem = link.closest('.nav-item[data-section]');
                    if (parentNavItem) {
                        document.querySelectorAll('.nav-item[data-section]').forEach(item => item.classList.remove('active'));
                        parentNavItem.classList.add('active');
                    }
                    const headerHeight = document.querySelector('header').offsetHeight;
                    const targetPosition = targetEl.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                    window.scrollTo({ top: targetPosition, behavior: 'smooth' });
                }
            }
        });
    });

    // ============================================================
    // 12. HEADER DINÂMICO: Intersection Observer
    // ============================================================
    const navItems = document.querySelectorAll('.nav-item[data-section]');
    const sections = [];

    navItems.forEach(item => {
        const sectionId = item.getAttribute('data-section');
        const section = document.getElementById(sectionId);
        if (section) sections.push({ navItem: item, section: section });
    });

    if (sections.length > 0) {
        const observerOptions = {
            root: null,
            rootMargin: '-80px 0px -20% 0px',
            threshold: 0.1
        };

        const observerCallback = (entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Remove active de todos os nav-items com data-section
                    navItems.forEach(item => item.classList.remove('active'));
                    // Encontra o nav-item correspondente e ativa
                    const match = sections.find(s => s.section === entry.target);
                    if (match) match.navItem.classList.add('active');
                }
            });
        };

        const observer = new IntersectionObserver(observerCallback, observerOptions);
        sections.forEach(s => observer.observe(s.section));
    }
});

// ============================================================
// FUNÇÃO GLOBAL: CONFIRMAR INTERESSE (toque divertido)
// ============================================================
window.confirmarInteresse = () => {
    document.getElementById('meInteresseModal').style.display = 'none';

    const frasesDivertidas = [
        "Seu chat com Perk está sendo preparado. Hora de negociar!",
        "Teletransportando você para a conversa... Segura o coração!",
        "Opa! O canal de comunicação foi aberto. Não esqueça de dizer 'Oi'!",
        "Tudo pronto! O Perk já está esperando seu 'olá' no chat privado.",
        "Missão cumprida! Você agora tem um canal direto com o especialista."
    ];

    const fraseAleatoria = frasesDivertidas[Math.floor(Math.random() * frasesDivertidas.length)];

    window.showFun("Conexão Estabelecida! ⚡",
        '<p>' + fraseAleatoria + '</p><p style="margin-top:10px; font-size:0.9rem; color:#666;">Lembre-se: este é apenas um tutorial interativo. No sistema real, você seria redirecionado agora!</p>',
        '<button class="btn-fun btn-skip" style="background:#7f1615" onclick="document.getElementById(\'funModal\').style.display=\'none\'">Entendido!</button>');
};
