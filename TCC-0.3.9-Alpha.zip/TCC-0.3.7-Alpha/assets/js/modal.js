const openModalButtons = document.querySelectorAll('.open-modal');

openModalButtons.forEach(button => {
    button.addEventListener('click', () => {
        const modalId = button.getAttribute('data-modal');
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.showModal();
        }
    });
});

const closeModalButtons = document.querySelectorAll('.close-modal');

closeModalButtons.forEach(button => {
    button.addEventListener('click', () => {
        const modalId = button.getAttribute('data-modal');
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.close();
        }
    });
});

// Botão para abrir outro modal (ex: "Ver Perfil" no pfp-modal abre previa-modal)
const openNestedModalButtons = document.querySelectorAll('[data-nested-modal]');

openNestedModalButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        const currentModalId = button.closest('dialog').id;
        const nestedModalId = button.getAttribute('data-nested-modal');
        
        // Fecha o modal atual
        const currentModal = document.getElementById(currentModalId);
        if (currentModal) {
            currentModal.close();
        }
        
        // Abre o próximo modal após um pequeno delay
        setTimeout(() => {
            const nestedModal = document.getElementById(nestedModalId);
            if (nestedModal) {
                nestedModal.showModal();
            }
        }, 100);
    });
});