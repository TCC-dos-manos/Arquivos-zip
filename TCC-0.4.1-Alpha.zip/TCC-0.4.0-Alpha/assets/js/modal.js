// ================================================== Modal Genérico ==================================================

const modalConfigs = {
    pularTutorial: {
        tagIcon: 'fa-solid fa-question',
        tagText: 'Já Conhece o site?',
        title: "Pular o Tutorial?",
        subtitle: "Tem certeza que deseja pular o tutorial que foi feito com muito carinho pela nossa equipe?",
        content: "Nele explicamos um pouco de como funcionam as interações principais do nosso site.",
        primaryBtnText: "Tenho Certeza",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            window.location.href = 'login.php';
        }
    },
    pularTutorialCadastro: {
        tagIcon: 'fa-solid fa-question',
        tagText: 'Certeza?',
        title: "Pular o Tutorial?",
        subtitle: "Tem certeza que deseja pular o tutorial que foi feito com muito carinho pela nossa equipe?",
        content: "Nele explicamos um pouco de como funcionam as interações principais do nosso site.",
        primaryBtnText: "Tenho Certeza",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            openModalWithConfig('irParaCadastro', 'colaborador');
        }
    },
    irParaCadastro: {
        tagIcon: 'fa-solid fa-user-plus',
        tagText: 'Cadastro',
        title: "Criar sua Conta?",
        subtitle: "Você será redirecionado para a página de cadastro.",
        content: "Lá você poderá se registrar como Colaborador (CPF) ou Organizador (CNPJ).",
        primaryBtnText: "Vamos lá!",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            window.location.href = 'cadastroUsuario.php';
        }
    },
    confirmarMensagem: {
        tagIcon: 'fa-solid fa-envelope',
        tagText: 'Confirmar',
        title: "Tem Certeza?",
        subtitle: "Tem certeza que deseja enviar a mensagem: ",
        content: "Esta Ação não poderá ser desfeita! E ela não terá relação com nenhum Card.",
        primaryBtnText: "Tenho Certeza",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            usuarioJaEnviouMensagemColab = true;
            openModalWithConfig('mensagemSucesso');
        }
    },
    mensagemSucesso: {
        tagIcon: 'fa-solid fa-envelope-circle-check',
        tagText: 'Enviada',
        title: "Sucesso!",
        subtitle: "Sua mensagem foi enviada com sucesso!",
        content: "O colaborador Perk receberá sua mensagem em breve. Mas lembre-se que isso é apenas um Tutorial!",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },
    mensagemColabJaEnviada: {
        tagIcon: 'fa-solid fa-lock',
        tagText: 'Acesso Privado',
        title: "Você já enviou uma mensagem!",
        subtitle: "Você será redirecionado à conversa privada com Perk.",
        content: "Em breve você poderia acessar o chat privado diretamente pelo seu painel. Mas como isso é apenas um tutorial, nada acontecerá por aqui!",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },
    confirmaAvaliacao: {
        tagIcon: 'fa-solid fa-triangle-exclamation',
        tagText: 'Atenção!',
        title: "Opa! Parece que você não pode comentar nesse Card",
        subtitle: "O Organizador apenas poderá comentar após confirmar que a negociação foi feita com o dono do Card.",
        content: "Porém como isso é um tutorial, clique em 'Liberar Acesso' para avaliar o serviço.",
        primaryBtnText: "Liberar Acesso",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            if (usuarioJaAvaliou) {
                openModalWithConfig('jaAvaliou');
            } else {
                document.getElementById('avaliar-modal').showModal();
            }
        }
    },
    pfpModal: {
        tagIcon: 'fa-solid fa-user',
        tagText: 'Perfil',
        title: "Conheça o Perfil do Colaborador",
        subtitle: "Você irá visualizar o perfil de Perk.",
        content: "Atenção! Este é apenas um preview do perfil do profissional pois é um tutorial, você poderá visualizar todas as informações ao logar no nosso site.",
        primaryBtnText: "Ver Perfil",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            document.getElementById('previa-modal').showModal();
        }
    },
    pfpModalOrg: {
        tagIcon: 'fa-solid fa-user',
        tagText: 'Perfil',
        title: "Conheça o Perfil do Organizador",
        subtitle: "Você irá visualizar o perfil de Otome Company.",
        content: "Atenção! Este é apenas um preview do perfil pois é um tutorial, você poderá visualizar todas as informações ao logar no nosso site.",
        primaryBtnText: "Ver Perfil",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            document.getElementById('organizador-modal').showModal();
        }
    },
    tagModal: {
        tagIcon: 'fa-solid fa-hashtag',
        tagText: 'Tags',
        title: "Como Funcionam as Tags?",
        subtitle: "Com elas você pode filtrar por cards com temas específicos.",
        content: "As tags são uma forma de facilitar sua vida. Caso isso não fosse um tutorial, você seria direcionado a uma página com cards/eventos que possuem a mesma tag.",
        primaryBtnText: "Entendi",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },
    editarMensagem: {
        tagIcon: 'fa-solid fa-pencil',
        tagText: 'Editar',
        title: "Atenção!",
        subtitle: "Você não pode editar o seu comentário a qualquer momento!",
        content: "Para que seu comentário seja editado, um administrador deverá avaliar antes se a edição faz sentido. Clique em 'Prosseguir' para enviar sua solicitação.",
        primaryBtnText: "Prosseguir",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            document.getElementById('solicitacao-editar').showModal();
        }
    },
    jaAvaliou: {
        tagIcon: 'fa-solid fa-circle-check',
        tagText: 'Avaliado!',
        title: "Você já avaliou este Card",
        subtitle: "Sua avaliação já foi registrada com sucesso.",
        content: "Você só pode avaliar um card uma vez. Caso queira alterar, solicite a um administrador clicando em 'Editar' no seu comentário dentro de 'Saiba Mais'.",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },
    meInteressei: {
        tagIcon: 'fa-solid fa-triangle-exclamation',
        tagText: 'Atenção!',
        title: "Registrar Interesse?",
        subtitle: "Tem certeza que deseja registrar seu interesse nesse card? Essa ação não pode ser desfeita!",
        content: "Uma solicitação de interesse será enviada ao Colaborador. Você poderá escrever uma mensagem direta. Dica: vá direto ao ponto.",
        primaryBtnText: "Estou Ciente",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            document.getElementById('me-interessei').showModal();
        }
    },
    jaInteressou: {
        tagIcon: 'fa-solid fa-circle-check',
        tagText: 'Interesse Registrado!',
        title: "Você já demonstrou interesse neste Card",
        subtitle: "Seu interesse já foi registrado com sucesso.",
        content: "Você só pode demonstrar interesse uma vez. O colaborador entrará em contato em breve!",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },
    eventoInteresse: {
        tagIcon: 'fa-solid fa-triangle-exclamation',
        tagText: 'Atenção!',
        title: "Registrar Interesse no Evento?",
        subtitle: "Tem certeza que deseja demonstrar interesse neste evento? Essa ação não pode ser desfeita!",
        content: "Uma solicitação será enviada ao Organizador. Você poderá escrever uma mensagem objetiva. Seja direto ao ponto.",
        primaryBtnText: "Estou Ciente",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            document.getElementById('evento-interesse-modal').showModal();
        }
    },
    confirmarMensagemOrg: {
        tagIcon: 'fa-solid fa-envelope',
        tagText: 'Confirmar',
        title: "Tem Certeza?",
        subtitle: "Tem certeza que deseja enviar a mensagem: ",
        content: "Esta Ação não poderá ser desfeita! E Ela não terá relação com nenhum Evento.",
        primaryBtnText: "Tenho Certeza",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            usuarioJaEnviouMensagemOrg = true;
            openModalWithConfig('mensagemSucessoOrg', 'organizador');
        }
    },
    mensagemSucessoOrg: {
        tagIcon: 'fa-solid fa-envelope-circle-check',
        tagText: 'Enviada',
        title: "Sucesso!",
        subtitle: "Sua mensagem foi enviada com sucesso!",
        content: "O organizador Otome Company receberá sua mensagem em breve. Lembre-se que isso é apenas um Tutorial!",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },
    mensagemOrgJaEnviada: {
        tagIcon: 'fa-solid fa-lock',
        tagText: 'Acesso Privado',
        title: "Você já enviou uma mensagem!",
        subtitle: "Você será redirecionado à conversa privada com Otome Company.",
        content: "Em breve você poderia acessar o chat privado diretamente pelo seu painel. Mas como isso é apenas um tutorial, nada acontecerá por aqui!",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },
};

// ─── Tema dinâmico: tokens por perfil ────────────────────────────────────────
//
// O banner já é controlado pelo CSS (.generic-modal--org no .modal-container-generic).
// Aqui controlamos via JS apenas o que o CSS não cobre: body bg, botão primário e secundário.

const TEMA = {
    colaborador: {
        bodyBg: '#fff5f0',
        primaryBg: 'linear-gradient(135deg, #7f1615 0%, #a87c6e 100%)',
        primaryShadow: '0 6px 18px rgba(127, 22, 21, 0.28)',
        primaryShadowHv: '0 10px 24px rgba(127, 22, 21, 0.40)',
        descColor: '#555',
    },
    organizador: {
        bodyBg: '#f0f5fc',
        primaryBg: 'linear-gradient(135deg, #0d2137 0%, #0f4c75 100%)',
        primaryShadow: '0 6px 18px rgba(15, 76, 117, 0.28)',
        primaryShadowHv: '0 10px 24px rgba(15, 76, 117, 0.42)',
        descColor: '#1a4a6e',
    },
};

let _lastGenericPerfil = 'colaborador';

function _aplicarTemaGenerico(perfil) {
    const container = document.querySelector('.modal-container-generic');
    const descP = document.querySelector('#generic-modal .modal-description p');
    if (!container) return;

    const t = TEMA[perfil] || TEMA.colaborador;

    // Classe CSS para o banner (gradient do topo)
    container.classList.toggle('generic-modal--org', perfil === 'organizador');

    // Body background e texto de descrição
    container.style.background = t.bodyBg;
    if (descP) descP.style.color = t.descColor;

    // O botão primário é re-tematizado após o clone, dentro de openModalWithConfig
    // (guardamos os tokens no closure via _temaAtivo)
    _temaAtivo = t;
}

// Token do tema atual — usado pelo clone do botão primário
let _temaAtivo = TEMA.colaborador;

// ─── openModalWithConfig ──────────────────────────────────────────────────────

function openModalWithConfig(configKey, perfil) {
    const config = modalConfigs[configKey];
    if (!config) {
        console.error(`Configuração de modal '${configKey}' não encontrada.`);
        return;
    }

    const temaAtual = perfil || _lastGenericPerfil || 'colaborador';
    _aplicarTemaGenerico(temaAtual);

    const genericModal = document.getElementById('generic-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalSubtitle = document.getElementById('modal-subtitle');
    const modalContent = document.getElementById('modal-content');
    const tagIcon = document.getElementById('modal-tag-icon');
    const tagText = document.getElementById('modal-tag-text');
    let primaryBtn = document.getElementById('modal-primary-btn');
    let secundaryBtn = document.getElementById('modal-secundary-btn');

    if (config.tagIcon) tagIcon.className = config.tagIcon;
    if (config.tagText) tagText.textContent = config.tagText;

    modalTitle.textContent = config.title;
    modalContent.textContent = config.content;

    if (configKey === 'confirmarMensagem') {
        const textArea = document.getElementById('colab-mensagem-textarea');
        const mensagemAtual = textArea ? textArea.value : '';
        modalSubtitle.innerHTML = config.subtitle + `"<span style="color:#fff">${mensagemAtual}</span>"?`;
    } else if (configKey === 'confirmarMensagemOrg') {
        const textArea = document.getElementById('org-mensagem-textarea');
        const mensagemAtual = textArea ? textArea.value : '';
        modalSubtitle.innerHTML = config.subtitle + `"<span style="color:#fff">${mensagemAtual}</span>"?`;
    } else {
        modalSubtitle.textContent = config.subtitle;
    }

    // ── Botão primário ──────────────────────────────────────────────────────
    if (!config.primaryBtnText || !config.primaryBtnText.trim()) {
        primaryBtn.style.display = 'none';
    } else {
        primaryBtn.style.display = '';
        primaryBtn.textContent = config.primaryBtnText;

        // Clona para evitar listeners duplicados
        const newPrimary = primaryBtn.cloneNode(true);
        primaryBtn.parentNode.replaceChild(newPrimary, primaryBtn);
        newPrimary.addEventListener('click', config.callback);

        // Aplica tema no clone (cloneNode não copia event handlers inline)
        const t = _temaAtivo;
        newPrimary.style.background = t.primaryBg;
        newPrimary.style.boxShadow = t.primaryShadow;
        newPrimary.onmouseenter = () => {
            newPrimary.style.boxShadow = t.primaryShadowHv;
            newPrimary.style.transform = 'translateY(-2px)';
        };
        newPrimary.onmouseleave = () => {
            newPrimary.style.boxShadow = t.primaryShadow;
            newPrimary.style.transform = '';
        };
    }

    // ── Botão secundário (X) ────────────────────────────────────────────────
    // Fica sempre no banner (fundo escuro), então cor branca serve para ambos os temas.
    if (!config.secundaryBtnText || !config.secundaryBtnText.trim()) {
        secundaryBtn.style.display = 'none';
    } else {
        secundaryBtn.style.display = '';
        secundaryBtn.textContent = config.secundaryBtnText;

        const newSecundary = secundaryBtn.cloneNode(true);
        secundaryBtn.parentNode.replaceChild(newSecundary, secundaryBtn);
        newSecundary.addEventListener('click', () => {
            if (config.secundaryCallback) config.secundaryCallback();
            genericModal.close();
        });
    }

    genericModal.showModal();
}

// Captura data-perfil do botão e repassa ao openModalWithConfig
document.querySelectorAll('.open-generic-modal').forEach(button => {
    button.addEventListener('click', () => {
        const perfil = button.getAttribute('data-perfil') || 'colaborador';
        _lastGenericPerfil = perfil;
        openModalWithConfig(button.getAttribute('data-config'), perfil);
    });
});

// ================================================== Abrir / Fechar modais simples ==================================================

document.querySelectorAll('.open-modal').forEach(button => {
    button.addEventListener('click', () => {
        const modal = document.getElementById(button.getAttribute('data-modal'));
        if (modal) modal.showModal();
    });
});

document.querySelectorAll('.close-modal').forEach(button => {
    button.addEventListener('click', () => {
        const modal = document.getElementById(button.getAttribute('data-modal'));
        if (modal) modal.close();
    });
});

// ================================================== Abas do Colaborador (previa-modal) ==================================================

document.querySelectorAll('.colab-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.colab-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.colab-tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        const target = document.getElementById(tab.dataset.tab);
        if (target) target.classList.add('active');
    });
});

const colabTextarea = document.getElementById('colab-mensagem-textarea');
const colabCount = document.getElementById('colab-mensagem-count');
if (colabTextarea && colabCount) {
    colabTextarea.addEventListener('input', () => {
        colabCount.textContent = `${colabTextarea.value.length} / 500`;
    });
}

const previaMod = document.getElementById('previa-modal');
if (previaMod) {
    previaMod.addEventListener('close', () => {
        document.querySelectorAll('.colab-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.colab-tab-content').forEach(c => c.classList.remove('active'));
        const firstTab = document.querySelector('.colab-tab');
        const firstContent = document.getElementById('colab-tab-perfil');
        if (firstTab) firstTab.classList.add('active');
        if (firstContent) firstContent.classList.add('active');
        if (colabTextarea) colabTextarea.value = '';
        if (colabCount) colabCount.textContent = '0 / 500';
    });
}

// ================================================== Abas do Organizador (organizador-modal) ==================================================

document.querySelectorAll('.org-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.org-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.org-tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        const target = document.getElementById(tab.dataset.tab);
        if (target) target.classList.add('active');
    });
});

const orgTextarea = document.getElementById('org-mensagem-textarea');
const orgCount = document.getElementById('org-mensagem-count');
if (orgTextarea && orgCount) {
    orgTextarea.addEventListener('input', () => {
        orgCount.textContent = `${orgTextarea.value.length} / 500`;
    });
}

// ================================================== Lightbox ==================================================

let lightboxImages = [];
let lightboxIndex = 0;
// FIX — guarda TODOS os dialogs abertos em ordem para reabri-los ao fechar o lightbox
let lightboxReturnStack = [];

const lightboxOverlay = document.getElementById('lightbox-overlay');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxCurrent = document.getElementById('lightbox-current');
const lightboxTotal = document.getElementById('lightbox-total');
const lightboxCloseBtn = document.getElementById('lightbox-close');
const lightboxPrevBtn = document.getElementById('lightbox-prev');
const lightboxNextBtn = document.getElementById('lightbox-next');

function abrirLightbox(imgs, index) {
    lightboxImages = imgs;
    lightboxIndex = index;
    atualizarLightbox();

    lightboxReturnStack = [];

    lightboxOverlay.showModal();
}

function fecharLightbox() {
    lightboxOverlay.close();
    lightboxReturnStack = [];
}

function atualizarLightbox() {
    lightboxImg.src = lightboxImages[lightboxIndex];
    lightboxCurrent.textContent = lightboxIndex + 1;
    lightboxTotal.textContent = lightboxImages.length;
}

function proximaImagem() {
    lightboxIndex = (lightboxIndex + 1) % lightboxImages.length;
    atualizarLightbox();
}

function imagemAnterior() {
    lightboxIndex = (lightboxIndex - 1 + lightboxImages.length) % lightboxImages.length;
    atualizarLightbox();
}

lightboxCloseBtn.addEventListener('click', fecharLightbox);
lightboxNextBtn.addEventListener('click', proximaImagem);
lightboxPrevBtn.addEventListener('click', imagemAnterior);

lightboxOverlay.addEventListener('click', (e) => {
    if (e.target === lightboxOverlay) fecharLightbox();
});

document.addEventListener('keydown', (e) => {
    if (!lightboxOverlay.open) return;
    if (e.key === 'ArrowRight') proximaImagem();
    if (e.key === 'ArrowLeft') imagemAnterior();
    if (e.key === 'Escape') fecharLightbox();
});

// Galeria do portfólio do Colaborador (previa-modal) — escopo restrito ao dialog pai
document.addEventListener('click', (e) => {
    const img = e.target.closest('.colab-gallery-grid img');
    if (!img) return;
    const scope = img.closest('dialog') || document;
    const todasImgs = Array.from(scope.querySelectorAll('.colab-gallery-grid img'));
    abrirLightbox(todasImgs.map(i => i.src), todasImgs.indexOf(img));
});

// Galeria do Saiba Mais (gallery-grid) — escopo restrito ao dialog pai
document.addEventListener('click', (e) => {
    const item = e.target.closest('.gallery-grid .gallery-item');
    if (!item) return;
    const scope = item.closest('dialog') || document;
    const items = Array.from(scope.querySelectorAll('.gallery-grid .gallery-item'));
    abrirLightbox(items.map(i => i.querySelector('img').src), items.indexOf(item));
});

// Galeria da Org (org-modal-galeria) — escopo restrito ao dialog pai
document.addEventListener('click', (e) => {
    const img = e.target.closest('.org-gallery-grid img');
    if (!img) return;
    const scope = img.closest('dialog') || document;
    const todasImgs = Array.from(scope.querySelectorAll('.org-gallery-grid img'));
    abrirLightbox(todasImgs.map(i => i.src), todasImgs.indexOf(img));
});

// ================================================== Modal Avaliar ==================================================

const notaLabels = ['', 'Muito ruim', 'Ruim', 'Decente', 'Legal', 'Excelente!'];
// condições
let notaSelecionada = 0;
let todasAsNotas = [];
let usuarioJaAvaliou = false;
let usuarioJaInteressou = false;
let usuarioJaEnviouMensagemOrg = false;
let usuarioJaEnviouMensagemColab = false;

const notaTexto = document.getElementById('avaliar-nota-texto');
const textarea = document.getElementById('avaliar-textarea');
const charCount = document.getElementById('avaliar-char-count');
const confirmarBtn = document.getElementById('confirmar-avaliacao');
const toast = document.getElementById('avaliar-toast');

function pintarEstrelas(val) {
    document.querySelectorAll('#modal-stars .modal-star').forEach(s => {
        const sv = parseInt(s.dataset.star);
        s.classList.toggle('fa-solid', sv <= val);
        s.classList.toggle('fa-regular', sv > val);
        s.classList.toggle('lit', sv <= val);
    });
}

document.getElementById('modal-stars').addEventListener('mouseover', (e) => {
    const star = e.target.closest('.modal-star');
    if (!star) return;
    pintarEstrelas(parseInt(star.dataset.star));
    notaTexto.textContent = notaLabels[parseInt(star.dataset.star)];
});

document.getElementById('modal-stars').addEventListener('mouseout', (e) => {
    const star = e.target.closest('.modal-star');
    if (!star) return;
    pintarEstrelas(notaSelecionada);
    notaTexto.textContent = notaSelecionada ? notaLabels[notaSelecionada] : '';
});

document.getElementById('modal-stars').addEventListener('click', (e) => {
    const star = e.target.closest('.modal-star');
    if (!star) return;
    notaSelecionada = parseInt(star.dataset.star);
    pintarEstrelas(notaSelecionada);
    notaTexto.textContent = notaLabels[notaSelecionada];
});

textarea.addEventListener('input', () => {
    const len = textarea.value.length;
    charCount.textContent = `${len} / 300`;
    charCount.classList.toggle('warn', len >= 270);
});

function calcularMedia() {
    if (!todasAsNotas.length) return 0;
    return todasAsNotas.reduce((a, b) => a + b, 0) / todasAsNotas.length;
}

function atualizarEstrelasSaibaMais(media) {
    document.querySelectorAll('#saiba-mais-stars .fa-star').forEach(star => {
        const sv = parseInt(star.dataset.star);
        star.classList.toggle('fa-solid', sv <= Math.round(media));
        star.classList.toggle('fa-regular', sv > Math.round(media));
    });
    const numero = document.getElementById('saiba-mais-rating-numero');
    if (numero) numero.innerHTML = `${media.toFixed(1)}<span>/5</span>`;
    const texto = document.getElementById('saiba-mais-rating-text');
    if (texto) texto.textContent = `${todasAsNotas.length} avaliação${todasAsNotas.length > 1 ? 'ões' : ''}`;
}

function adicionarComentarioSaibaMais(comentario, nota) {
    const userSection = document.getElementById('userCommentSection');
    const userText = document.getElementById('userCommentText');
    const userNota = document.getElementById('user-comment-nota');
    const ratingEl = document.getElementById('user-comment-rating');
    if (!userSection || !userText) return;
    if (nota) { userNota.textContent = nota; ratingEl.style.display = 'inline-flex'; }
    if (comentario) userText.textContent = comentario;
    userSection.style.display = 'block';
}

confirmarBtn.addEventListener('click', () => {
    if (notaSelecionada === 0) {
        notaTexto.textContent = '⚠ Selecione uma nota antes de continuar.';
        notaTexto.style.color = '#c0392b';
        setTimeout(() => { notaTexto.style.color = ''; notaTexto.textContent = ''; }, 2500);
        return;
    }
    todasAsNotas.push(notaSelecionada);
    usuarioJaAvaliou = true;
    const media = calcularMedia();
    atualizarEstrelasSaibaMais(media);
    adicionarComentarioSaibaMais(textarea.value.trim(), notaSelecionada);
    resetarModalAvaliar();
    document.getElementById('avaliar-modal').close();
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
});

function resetarModalAvaliar() {
    notaSelecionada = 0;
    pintarEstrelas(0);
    notaTexto.textContent = '';
    textarea.value = '';
    charCount.textContent = '0 / 300';
    charCount.classList.remove('warn');
}

document.getElementById('fecharAvaliarModal').addEventListener('click', resetarModalAvaliar);
document.getElementById('cancelarAvaliacaoBtn').addEventListener('click', resetarModalAvaliar);

// ================================================== Modal Editar Comentário ==================================================

const editarTextarea = document.getElementById('editar-textarea');
const editarCharCount = document.getElementById('editar-char-count');
const confirmarEditarBtn = document.getElementById('confirmar-editar');
const editarToast = document.getElementById('editar-toast');

editarTextarea.addEventListener('input', () => {
    editarCharCount.textContent = `${editarTextarea.value.length} / 300`;
});

confirmarEditarBtn.addEventListener('click', () => {
    document.querySelectorAll('dialog[open]').forEach(m => m.close());
    editarTextarea.value = '';
    editarCharCount.textContent = '0 / 300';
    editarToast.classList.add('show');
    setTimeout(() => editarToast.classList.remove('show'), 3000);
});

// ================================================== Modal Me Interessei (Card) ==================================================

const interesseTextarea = document.getElementById('interesse-textarea');
const interesseCharCount = document.getElementById('interesse-char-count');
const confirmarInteresseBtn = document.getElementById('confirmar-interesse');
const interesseToast = document.getElementById('interesse-toast');

interesseTextarea.addEventListener('input', () => {
    interesseCharCount.textContent = `${interesseTextarea.value.length} / 500`;
});

confirmarInteresseBtn.addEventListener('click', () => {
    document.querySelectorAll('dialog[open]').forEach(m => m.close());
    interesseTextarea.value = '';
    interesseCharCount.textContent = '0 / 500';
    usuarioJaInteressou = true;
    interesseToast.classList.add('show');
    setTimeout(() => interesseToast.classList.remove('show'), 3000);
});

document.getElementById('meInteresseiBtnModal').addEventListener('click', () => {
    if (usuarioJaInteressou) openModalWithConfig('jaInteressou');
});

// ================================================== Modal Me Interesso (Evento) ==================================================

const evInteresseTextarea = document.getElementById('ev-interesse-textarea');
const evInteresseCharCount = document.getElementById('ev-interesse-char-count');
const evConfirmarInteresseBtn = document.getElementById('ev-confirmar-interesse');
const evInteresseToast = document.getElementById('ev-interesse-toast');

if (evInteresseTextarea && evInteresseCharCount) {
    evInteresseTextarea.addEventListener('input', () => {
        evInteresseCharCount.textContent = `${evInteresseTextarea.value.length} / 500`;
    });
}

if (evConfirmarInteresseBtn) {
    evConfirmarInteresseBtn.addEventListener('click', () => {
        // FIX — fecha APENAS o modal de interesse do evento; o saiba-mais permanece aberto
        const evInteresseModal = document.getElementById('evento-interesse-modal');
        if (evInteresseModal) evInteresseModal.close();

        evInteresseTextarea.value = '';
        evInteresseCharCount.textContent = '0 / 500';
        evInteresseToast.classList.add('show');
        setTimeout(() => evInteresseToast.classList.remove('show'), 3000);
    });
}

// ================================================== Botão Enviar Mensagem Organizador ==================================================

document.getElementById('org-btn-enviar-mensagem')?.addEventListener('click', () => {
    if (usuarioJaEnviouMensagemOrg) {
        openModalWithConfig('mensagemOrgJaEnviada', 'organizador');
    } else {
        openModalWithConfig('confirmarMensagemOrg', 'organizador');
    }
});

// ================================================== Botão Enviar Mensagem Colaborador ==================================================

document.getElementById('colab-btn-enviar-mensagem')?.addEventListener('click', () => {
    if (usuarioJaEnviouMensagemColab) {
        openModalWithConfig('mensagemColabJaEnviada', 'colaborador');
    } else {
        openModalWithConfig('confirmarMensagem', 'colaborador');
    }
});