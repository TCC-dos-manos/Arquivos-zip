<?php
session_start();

require_once __DIR__ . "/../model/dto/UsuarioDTO.php";
require_once __DIR__ . "/../model/dao/UsuarioDAO.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura e limpeza de dados
    $acao         = trim($_POST["acao"] ?? "");
    $email         = trim($_POST["email"] ?? "");
    $senha         = $_POST["senha_hash"] ?? ""; // Senha pura vinda do formulário
    $ativo         = $_POST["ativo"] ?? 1;  // Padrão 1 (ativo) se não enviado
    $data_criacao  = date("Y-m-d H:i:s");   // Gera a data atual

    //valida se a ação foi passada para o controller
    if(empty($acao)) {
        echo "<script>alert('Tentativa ilegal de acesso ao sistema.'); window.history.back();</script>";
        exit; 
    }
    // Validação básica de campos obrigatórios
    if (empty($email) || empty($senha)) {
        echo "<script>alert('Por favor, preencha o e-mail e a senha.'); window.history.back();</script>";
        exit;
    }

    // Validação de formato de e-mail
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('O e-mail informado é inválido.'); window.history.back();</script>";
        exit;
    }
    try {
        if($acao == "cadastrar"){
        // Hash da senha para segurança (armazenado como senha_hash)
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

        // Instancia o DTO e popula com os dados conforme os métodos do seu UsuarioDTO
        $usuarioDTO = new UsuarioDTO();
        $usuarioDTO->setemail(htmlspecialchars($email));
        $usuarioDTO->setsenha_hash($senha_hash);
        $usuarioDTO->setativo((int)$ativo);
        $usuarioDTO->setdata_criacao($data_criacao);

        // Executa a operação no Banco de Dados através do DAO
        $usuarioDAO = new UsuarioDAO();
        $ok = $usuarioDAO->cadastrar($usuarioDTO);

        if ($ok) {
            if (!isset($_SESSION["usuario"])) {
                echo "<script>alert('Usuário cadastrado com sucesso!'); window.location='../login.php?msg=Cadastr realizado com sucesso! Faça login no sistema.';</script>";
            } else {
                echo "<script>alert('Usuário cadastrado com sucesso!'); window.location='../view/index.php';</script>";
            }
        } else {
            echo "<script>alert('Erro ao cadastrar usuário!'); window.history.back();</script>";
        }
    } 
    } catch (PDOException $e) {
        die("Favor contactar o Suporte e informar que ocorreu o seguinte Erro na inclusão do USUÁRIO: " . $e->getMessage());
        echo "<script>window.history.back();</script>";
    }

}
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  if(isset($_GET["acao"]) && $_GET["acao"]=="excluir" ){
    $id_exclusao = $_GET["id"]; 
    // Executa a operação no Banco de Dados através do DAO
    $usuarioDAO = new UsuarioDAO();
    $ok = $usuarioDAO->excluir($id_exclusao);
  }
}
