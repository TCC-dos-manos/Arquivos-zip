<?php
/**
 * AdminLoginControl.php — Controller de login exclusivo para Administradores
 *
 * POR QUE ESTE ARQUIVO EXISTE SEPARADO?
 *
 * Segurança em camadas (defense in depth): mesmo que alguém descubra
 * a URL da tela de admin e tente logar com uma conta de Colaborador
 * ou Organizador — com senha correta e tudo — este controller nega o acesso.
 * A verificação de papel é feita ANTES de criar a sessão, então nenhum dado
 * sensível chega ao cliente.
 *
 * DIFERENÇAS EM RELAÇÃO AO LoginControl.php:
 * 1. Só aceita e-mail como identificador (CPF/CNPJ são de usuários comuns)
 * 2. Verifica explicitamente se o papel é 'Administrador' antes de qualquer redirecionamento
 * 3. Registra uma tentativa de acesso não autorizado no log de auditoria (RN-20 / RF29)
 * 4. Redireciona sempre para o painel admin, nunca para dashboards de usuários comuns
 */

session_start();

// Bloqueia acesso direto à URL sem dados de formulário
if (!isset($_POST['email'])) {
    header("location: ../../view/admin/login.html");
    exit;
}

require_once __DIR__ . "/../model/dao/Conexao.php";

$email = trim($_POST['email'] ?? '');
$senha = $_POST['senha'] ?? '';

if (empty($email) || empty($senha)) {
    echo "<script>alert('Preencha e-mail e senha.'); window.history.back();</script>";
    exit;
}

try {
    $pdo = Conexao::getInstance();

    // Query idêntica à do professor — busca usuário com todos os dados de papel
    $sql = "SELECT u.*, u.id AS id_usuario,
                   p.*, p.id AS id_pessoa,
                   upapel.*, upapel.id AS id_usuario_papel,
                   papel.nome AS nome_papel
            FROM usuario u
            INNER JOIN pessoa p             ON u.id = p.usuario_id
            INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
            INNER JOIN papel                ON upapel.papel_id = papel.id
            WHERE u.email = :email
            LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':email', $email);
    $stmt->execute();
    $usuario = $stmt->fetch();

    if ($usuario) {

        // ── VERIFICAÇÃO DE PAPEL (a diferença central deste controller) ──────
        // Esta checagem acontece ANTES de verificar a senha, intencionalmente.
        // Se o papel não for Administrador, nem tentamos verificar a senha —
        // isso evita que um atacante confirme se a senha de um Colaborador
        // está correta ao tentar entrar pelo painel admin.
        if ($usuario['nome_papel'] !== 'Administrador') {

            // RN-20 / RF29: registra a tentativa de acesso não autorizado no log.
            // Esse registro é imutável e contém data, hora, e-mail tentado e IP.
            // TODO: substituir por uma chamada ao seu AuditoriaDAO quando ele existir.
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'desconhecido';
            $sqlLog = "INSERT INTO log_auditoria (data_hora, acao, autor_email, detalhes, ip)
                       VALUES (NOW(), 'tentativa_acesso_admin_negada', :email, :detalhes, :ip)";
            try {
                $stmtLog = $pdo->prepare($sqlLog);
                $stmtLog->execute([
                    'email'    => $email,
                    'detalhes' => "Papel '{$usuario['nome_papel']}' tentou acessar o painel admin.",
                    'ip'       => $ip
                ]);
            } catch (PDOException $eLog) {
                // Se o log falhar, não interrompe o fluxo — mas idealmente
                // você deve ser notificado sobre falhas no sistema de auditoria
            }

            // Mensagem genérica: não revelamos ao atacante que a conta existe
            echo "<script>alert('Acesso negado.'); window.location='../../view/admin/login.html';</script>";
            exit;
        }

        // Verifica se a conta admin está ativa
        if (!$usuario['ativo']) {
            echo "<script>alert('Conta administrativa inativa. Contate o suporte técnico.'); window.history.back();</script>";
            exit;
        }

        // Verifica a senha
        if (password_verify($senha, $usuario['senha_hash'])) {

            // ── 1. AUTENTICAÇÃO: monta a sessão do administrador ─────────────
            $_SESSION['usuario'] = [
                'id'          => $usuario['id_pessoa'],
                'id_usuario'  => $usuario['id_usuario'],
                'nome'        => empty($usuario['nome_social'])
                                    ? $usuario['nome_completo']
                                    : $usuario['nome_social'],
                'email'       => $usuario['email'],
                'papel'       => $usuario['nome_papel'],  // sempre 'Administrador' aqui
                'permissoes'  => []
            ];

            // ── 2. AUTORIZAÇÃO (RBAC): mesma lógica do professor ────────────
            $sqlPermissoes = "
                SELECT per.recurso, per.acao
                FROM usuario_papel up
                JOIN papel_permissao pp ON up.papel_id = pp.papel_id
                JOIN permissao per      ON pp.permissao_id = per.id
                WHERE up.usuario_id = :usuario_id
            ";
            $stmtPerm = $pdo->prepare($sqlPermissoes);
            $stmtPerm->execute(['usuario_id' => $usuario['id_usuario']]);
            $lista_permissoes = $stmtPerm->fetchAll();

            foreach ($lista_permissoes as $row) {
                $recurso = $row['recurso'];
                $acao    = $row['acao'];
                if (!isset($_SESSION['usuario']['permissoes'][$recurso])) {
                    $_SESSION['usuario']['permissoes'][$recurso] = [];
                }
                $_SESSION['usuario']['permissoes'][$recurso][] = $acao;
            }

            // ── 3. LOG DE ACESSO ADMIN (RN-20 / RF29) ───────────────────────
            // Todo acesso bem-sucedido ao painel admin é registrado.
            // Isso é o que torna o log "imutável na prática": o sistema
            // grava cada entrada e cada ação — um admin não consegue
            // "apagar o rastro" de ter entrado.
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'desconhecido';
            $sqlLog = "INSERT INTO log_auditoria (data_hora, acao, autor_email, detalhes, ip)
                       VALUES (NOW(), 'login_admin', :email, 'Login bem-sucedido no painel administrativo.', :ip)";
            try {
                $stmtLog = $pdo->prepare($sqlLog);
                $stmtLog->execute(['email' => $email, 'ip' => $ip]);
            } catch (PDOException $eLog) {
                // Falha no log não impede o login, mas deve ser monitorada
            }

            // ── 4. REDIRECIONAMENTO: sempre para o painel admin ──────────────
            header("Location: ../../view/admin/dashboard.php");
            exit;

        } else {
            echo "<script>alert('Senha incorreta.'); window.history.back();</script>";
        }

    } else {
        // Mensagem genérica — não confirmamos se o e-mail existe no banco
        echo "<script>alert('Credenciais inválidas.'); window.history.back();</script>";
    }

} catch (PDOException $e) {
    die("Erro interno. Tente novamente mais tarde.");
}