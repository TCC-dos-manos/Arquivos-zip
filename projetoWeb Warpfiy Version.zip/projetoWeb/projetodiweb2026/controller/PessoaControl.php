<?php
session_start();
if (isset($_SESSION["usuario"])) {
    $id_usuario_login = $_SESSION["usuario"]["id"];
} else
    $id_usuario_login = "";

require_once __DIR__ . "/../model/dto/UsuarioDTO.php";
require_once __DIR__ . "/../model/dto/PessoaDTO.php";

require_once __DIR__ . "/../model/dao/UsuarioDAO.php";
require_once __DIR__ . "/../model/dao/PessoaDAO.php";

/*
//var_dump(__DIR__);
var_dump(UsuarioDTO);
exit;
*/


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    //INSERE PRIMEIRO O USUÁRIO NA BASE 
    //var_dump($_POST);
    //exit;
    $email          = trim($_POST["email"] ?? "");
    $senha          = $_POST["senha_hash"] ?? ""; // Senha pura vinda do formulário
    $confirma_senha = $_POST["confirma_senha"] ?? "";
    $ativo          = $_POST["ativo"] ?? 1;  // Padrão 1 (ativo) se não enviado
    $data_criacao   = date("Y-m-d H:i:s");   // Gera a data atual

    $papel_id       = $_POST["papel_id"] ?? 3;  //3 = papel Cliente

    // Validação básica de campos obrigatórios
    if (empty($email) || empty($senha) || empty($confirma_senha)) {
        echo "<script>alert('Por favor, preencha o e-mail e a senha.'); window.history.back();</script>";
        exit;
    }

    if (!($senha === $confirma_senha)) {
        echo "<script>alert('Por favor, a senha e a confirmação da senha devem ser iguais.'); window.history.back();</script>";
        exit;
    }

    // Validação de formato de e-mail
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('O e-mail informado é inválido.'); window.history.back();</script>";
        exit;
    }

    // Hash da senha para segurança (armazenado como senha_hash)
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

    // Instancia o DTO e popula com os dados conforme os métodos do seu UsuarioDTO
    $usuarioDTO = new UsuarioDTO();
    $usuarioDTO->setemail(htmlspecialchars($email));
    $usuarioDTO->setsenha_hash($senha_hash);
    $usuarioDTO->setativo((int)$ativo);
    $usuarioDTO->setdata_criacao($data_criacao);

    // Executa a operação no Banco de Dados através do DAO
    $usuarioDAO = new UsuarioDAO();
    $id_usuario_inserido = $usuarioDAO->cadastrar($usuarioDTO);

    if (!$id_usuario_inserido) {
        echo "<script>alert('Ocorreu um erro na inclusão do Usuário! Contate a concessionária.'); window.history.back();</script>";
    }

    // Captura e limpeza de dados
    $usuario_id      = $id_usuario_inserido;
    $nome_completo   = trim($_POST["nome_completo"] ?? "");
    $nome_social     = trim($_POST["nome_social"] ?? "");
    $cpf             = trim($_POST["cpf"] ?? "");
    $rg              = trim($_POST["rg"] ?? "");
    $telefone_movel  = trim($_POST["telefone_movel"] ?? "");
    $telefone_fixo   = trim($_POST["telefone_fixo"] ?? "");
    $cep_end         = trim($_POST["cep_end"] ?? "");
    $logradouro_end  = trim($_POST["logradouro_end"] ?? "");
    $numero_end      = trim($_POST["numero_end"] ?? "");
    $complemento_end = trim($_POST["complemento_end"] ?? "");
    $bairro_end      = trim($_POST["bairro_end"] ?? "");
    $localidade_end  = trim($_POST["localidade_end"] ?? "");
    $uf_end          = trim($_POST["uf_end"] ?? "");

    // Validação básica de campos obrigatórios
    if (empty($nome_completo) || empty($cpf) || empty($usuario_id)) {
        echo "<script>alert('Por favor, preencha os campos obrigatórios (Nome, CPF e ID do Usuário).'); window.history.back();</script>";
        exit;
    }

    // Instancia o DTO e popula com os dados
    $pessoaDTO = new PessoaDTO();
    $pessoaDTO->setusuario_id($usuario_id);
    $pessoaDTO->setnome_completo(htmlspecialchars($nome_completo));
    $pessoaDTO->setnome_social(htmlspecialchars($nome_social));
    $pessoaDTO->setcpf(htmlspecialchars($cpf));
    $pessoaDTO->setrg(htmlspecialchars($rg));
    $pessoaDTO->settelefone_movel(htmlspecialchars($telefone_movel));
    $pessoaDTO->settelefone_fixo(htmlspecialchars($telefone_fixo));
    $pessoaDTO->setcep_end(htmlspecialchars($cep_end));
    $pessoaDTO->setlogradouro_end(htmlspecialchars($logradouro_end));
    $pessoaDTO->setnumero_end(htmlspecialchars($numero_end));
    $pessoaDTO->setcomplemento_end(htmlspecialchars($complemento_end));
    $pessoaDTO->setbairro_end(htmlspecialchars($bairro_end));
    $pessoaDTO->setlocalidade_end(htmlspecialchars($localidade_end));
    $pessoaDTO->setuf_end(htmlspecialchars($uf_end));


    // Executa a operação no Banco de Dados
    $pessoaDAO = new PessoaDAO();
    $id_pessoa_inserida = $pessoaDAO->cadastrar($pessoaDTO);

    //ASSOCIAR O USUÁRIO/PESSOA AO PAPEL INFORMADO
    $ok = $usuarioDAO->inserirUsuarioPapel($id_usuario_inserido, $papel_id);

    if ($ok) {
        if ($id_usuario_login) {
            echo "<script>alert('Dados pessoais cadastrados com sucesso!'); window.location='../public/index.php';</script>";
        } else {
            echo "<script>alert('Dados pessoais cadastrados com sucesso!'); window.location='../view/login-cadastro.php';</script>";
        }
    } else {
        echo "<script>alert('Erro ao cadastrar dados pessoais!'); window.history.back();</script>";
    }
}
