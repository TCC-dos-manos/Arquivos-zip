<?php
session_start();

require_once __DIR__ . "/../model/dto/MontadoraDTO.php";
require_once __DIR__ . "/../model/dao/MontadoraDAO.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Captura e limpeza de dados
    $acao         = trim($_POST["acao"] ?? "");
    $id           = $_POST["id"] ?? null; // Útil para edições futuras
    $nome         = trim($_POST["nome"] ?? "");
    $pais_origem  = trim($_POST["pais_origem"] ?? "");

    // Valida se a ação foi passada para o controller
    if (empty($acao)) {
        echo "<script>alert('Tentativa ilegal de acesso ao sistema.'); window.history.back();</script>";
        exit; 
    }

    // Validação básica de campos obrigatórios para cadastro
    if (empty($nome) || empty($pais_origem)) {
        echo "<script>alert('Por favor, preencha o nome e o país de origem.'); window.history.back();</script>";
        exit;
    }

    try {
        if ($acao == "cadastrar") {
            // Instancia o DTO e popula com os dados da montadora
            $montadoraDTO = new MontadoraDTO();
            $montadoraDTO->setnome(htmlspecialchars($nome));
            $montadoraDTO->setpais_origem(htmlspecialchars($pais_origem));

            // Executa a operação no Banco de Dados através do DAO
            $montadoraDAO = new MontadoraDAO();
            $ok = $montadoraDAO->cadastrar($montadoraDTO);

            if ($ok) {
                echo "<script>alert('Montadora cadastrada com sucesso!'); window.location='../view/listar_montadoras.php';</script>";
            } else {
                echo "<script>alert('Erro ao cadastrar montadora!'); window.history.back();</script>";
            }
        } 
    } catch (PDOException $e) {
        die("Favor contactar o Suporte e informar que ocorreu o seguinte Erro na operação de MONTADORA: " . $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET["acao"]) && $_GET["acao"] == "excluir") {
        $id_exclusao = $_GET["id"]; 
        
        if (!empty($id_exclusao)) {
            // Executa a operação no Banco de Dados através do DAO
            $montadoraDAO = new MontadoraDAO();
            $ok = $montadoraDAO->excluir($id_exclusao);

            if ($ok) {
                echo "<script>alert('Montadora excluída com sucesso!'); window.location='../view/listar_montadoras.php';</script>";
            } else {
                echo "<script>alert('Erro ao excluir montadora!'); window.history.back();</script>";
            }
        }
    }
}