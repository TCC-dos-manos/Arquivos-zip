<?php
session_start();

// Remove todos os dados da sessão
$_SESSION = [];

// Destroi a sessão
session_destroy();

// Redireciona para a página de login
header("Location: ../view/login.php");
exit;
