<?php
/**
 * LoginControl.php — Controller de login para Colaborador e Organizador
 *
 * DIFERENÇAS EM RELAÇÃO AO ORIGINAL DO PROFESSOR:
 * 1. Aceita três tipos de identificador: e-mail, CPF ou CNPJ (RF02)
 * 2. Bloqueia o acesso ao Administrador por esta rota (ele tem porta própria)
 * 3. Os papéis do switch de redirecionamento foram atualizados para o Warpfiy:
 *    Colaborador → dashboard do colaborador
 *    Organizador → dashboard do organizador
 * 4. O resto da lógica (password_verify, RBAC, sessão) é idêntico ao professor
 *    — não havia motivo para reinventar o que já funciona bem.
 */

session_start();

// Se não veio nenhum dado de formulário, não há nada para processar
if (!isset($_POST['documento'])) {
    header("location: ../view/login.html");
    exit;
}

require_once __DIR__ . "/../model/dao/Conexao.php";

// Recebe os campos enviados pelo formulário
$documento      = trim($_POST['documento'] ?? '');
$tipo_documento = $_POST['tipo_documento'] ?? ''; // 'email', 'cpf' ou 'cnpj'
$senha          = $_POST['senha'] ?? '';

// Validação mínima: os três campos são obrigatórios
if (empty($documento) || empty($tipo_documento) || empty($senha)) {
    echo "<script>alert('Preencha todos os campos.'); window.history.back();</script>";
    exit;
}

// Remove a formatação visual (pontos, traços, barras) do CPF/CNPJ antes de buscar no banco.
// O banco armazena apenas os dígitos, mas o JS pode ter adicionado máscara visual.
if ($tipo_documento !== 'email') {
    $documento = preg_replace('/\D/', '', $documento);
}

// Monta a cláusula WHERE dinamicamente conforme o tipo de documento recebido.
// Isso evita a necessidade de três controllers separados ou um IF gigante no SQL.
switch ($tipo_documento) {
    case 'email':
        $coluna_busca = 'u.email';
        break;
    case 'cpf':
        // CPF fica na tabela `pessoa`, não em `usuario`
        // por isso o alias é 'p.cpf'
        $coluna_busca = 'p.cpf';
        break;
    case 'cnpj':
        // CNPJ também fica em `pessoa` (ou em uma tabela de empresa,
        // dependendo de como você modelar o banco do Warpfiy)
        $coluna_busca = 'p.cnpj';
        break;
    default:
        // Tipo desconhecido — alguém adulterou o formulário no navegador
        echo "<script>alert('Tipo de documento inválido.'); window.history.back();</script>";
        exit;
}

try {
    $pdo = Conexao::getInstance();

    // A query é a mesma do professor, só a cláusula WHERE muda conforme o tipo.
    // Usamos um placeholder :documento genérico para o PDO — o nome não importa,
    // o que importa é que $coluna_busca define em qual coluna comparar.
    $sql = "SELECT u.*, u.id AS id_usuario,
                   p.*, p.id AS id_pessoa,
                   upapel.*, upapel.id AS id_usuario_papel,
                   papel.nome AS nome_papel
            FROM usuario u
            INNER JOIN pessoa p       ON u.id = p.usuario_id
            INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
            INNER JOIN papel          ON upapel.papel_id = papel.id
            WHERE {$coluna_busca} = :documento
            LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':documento', $documento);
    $stmt->execute();
    $usuario = $stmt->fetch();

    if ($usuario) {

        // BARREIRA DE SEGURANÇA: o Administrador não pode entrar por esta rota.
        // Mesmo que alguém com papel Administrador tente logar aqui, é bloqueado.
        // O admin tem seu próprio controller: AdminLoginControl.php
        if ($usuario['nome_papel'] === 'Administrador') {
            echo "<script>alert('Acesso não permitido por esta rota. Use o painel administrativo.'); window.history.back();</script>";
            exit;
        }

        // Verifica se a conta está ativa (RN-01 implícito: contas suspensas não entram)
        if (!$usuario['ativo']) {
            echo "<script>alert('Conta inativa. Entre em contato com o suporte.'); window.history.back();</script>";
            exit;
        }

        // Verifica a senha usando o hash seguro (RNF02)
        if (password_verify($senha, $usuario['senha_hash'])) {

            // ── 1. AUTENTICAÇÃO: monta a sessão do usuário ──────────────────
            $_SESSION['usuario'] = [
                'id'          => $usuario['id_pessoa'],
                'id_usuario'  => $usuario['id_usuario'],
                'nome'        => empty($usuario['nome_social'])
                                    ? $usuario['nome_completo']
                                    : $usuario['nome_social'],
                'email'       => $usuario['email'],
                'papel'       => $usuario['nome_papel'],
                'permissoes'  => []
            ];

            // ── 2. AUTORIZAÇÃO (RBAC): busca as permissões do papel ─────────
            // Essa query é idêntica à do professor — o RBAC do Warpfiy segue
            // a mesma estrutura de tabelas: papel → papel_permissao → permissao
            $sqlPermissoes = "
                SELECT per.recurso, per.acao
                FROM usuario_papel up
                JOIN papel_permissao pp ON up.papel_id = pp.papel_id
                JOIN permissao per      ON pp.permissao_id = per.id
                WHERE up.usuario_id = :usuario_id
            ";
            $stmtPerm = $pdo->prepare($sqlPermissoes);
            $stmtPerm->execute(['usuario_id' => $usuario['id_usuario']]);
            $lista_permissoes = $stmtPerm->fetchAll();

            // ── 3. ESTRUTURAÇÃO: monta o array [recurso][acao] na sessão ────
            // Exemplo: $_SESSION['usuario']['permissoes']['card']['criar'] = true
            foreach ($lista_permissoes as $row) {
                $recurso = $row['recurso'];
                $acao    = $row['acao'];
                if (!isset($_SESSION['usuario']['permissoes'][$recurso])) {
                    $_SESSION['usuario']['permissoes'][$recurso] = [];
                }
                $_SESSION['usuario']['permissoes'][$recurso][] = $acao;
            }

            // ── 4. REDIRECIONAMENTO conforme o papel (RN-01) ─────────────────
            // Os papéis do Warpfiy são: Colaborador, Organizador, Administrador.
            // O Administrador nunca chega até aqui (foi barrado acima),
            // mas o default o redireciona para segurança caso algo inesperado ocorra.
            switch ($_SESSION['usuario']['papel']) {
                case 'Colaborador':
                    header("Location: ../view/colaborador/dashboard.php");
                    break;
                case 'Organizador':
                    header("Location: ../view/organizador/dashboard.php");
                    break;
                default:
                    // Papel desconhecido — desloga e volta para o início
                    session_destroy();
                    header("Location: ../view/login.html?erro=papel_invalido");
            }
            exit;

        } else {
            echo "<script>alert('Senha incorreta. Verifique e tente novamente.'); window.history.back();</script>";
        }

    } else {
        echo "<script>alert('Nenhuma conta encontrada com este documento.'); window.history.back();</script>";
    }

} catch (PDOException $e) {
    // Em produção, substitua o die() por um log silencioso + mensagem genérica
    die("Erro interno. Tente novamente mais tarde. [" . $e->getMessage() . "]");
}