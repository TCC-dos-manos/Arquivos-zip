<?php
// logout.php
session_start();
session_unset(); // Limpa as variáveis da sessão
session_destroy(); // Destrói a sessão
header("Location: index.php"); // Manda de volta pra vitrine pública
exit;