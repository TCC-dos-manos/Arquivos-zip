<?php
// processa_login.php
session_start();
require_once 'conexao.php';

$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

if (empty($email) || empty($senha)) {
    die("Email e senha são obrigatórios."); // Em um cenário real, redirecionaria com erro
}

// 1. AUTENTICAÇÃO: Busca o usuário e os dados da pessoa
$sqlUser = "
    SELECT u.id, u.senha_hash, u.ativo, p.nome_social, p.nome_completo 
    FROM usuario u
    JOIN pessoa p ON u.id = p.usuario_id
    WHERE u.email = :email
";
$stmt = $pdo->prepare($sqlUser);
$stmt->execute(['email' => $email]);
$usuario = $stmt->fetch();

// Verifica se o usuário existe, está ativo e se a senha bate
if ($usuario && $usuario['ativo'] == 1 && password_verify($senha, $usuario['senha_hash'])) {
    
    // Inicia a estrutura da sessão
    $_SESSION['usuario'] = [
        'id' => $usuario['id'],
        'nome' => $usuario['nome_social'] ?? $usuario['nome_completo'],
        'permissoes' => [] // Array vazio que será populado abaixo
    ];

    // 2. AUTORIZAÇÃO (RBAC): Busca as permissões baseadas nos papéis
    $sqlPermissoes = "
        SELECT per.recurso, per.acao
        FROM usuario_papel up
        JOIN papel_permissao pp ON up.papel_id = pp.papel_id
        JOIN permissao per ON pp.permissao_id = per.id
        WHERE up.usuario_id = :usuario_id
    ";
    $stmtPerm = $pdo->prepare($sqlPermissoes);
    $stmtPerm->execute(['usuario_id' => $usuario['id']]);
    
    $lista_permissoes = $stmtPerm->fetchAll();

    // 3. ESTRUTURAÇÃO: Monta o array hierárquico [recurso][acao]
    foreach ($lista_permissoes as $row) {
        $recurso = $row['recurso'];
        $acao = $row['acao'];
        
        // Se o recurso ainda não existe no array, cria
        if (!isset($_SESSION['usuario']['permissoes'][$recurso])) {
            $_SESSION['usuario']['permissoes'][$recurso] = [];
        }
        
        // Adiciona a ação dentro do recurso
        $_SESSION['usuario']['permissoes'][$recurso][] = $acao;
    }

    // Login com sucesso! Vai para a vitrine
    header("Location: index.php");
    exit;

} else {
    // Falha na autenticação
    die("Usuário inativo, e-mail ou senha incorretos.");
}
?>