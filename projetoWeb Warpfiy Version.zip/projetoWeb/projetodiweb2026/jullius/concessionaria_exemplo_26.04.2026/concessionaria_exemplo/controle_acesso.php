<?php

// Garante que a sessão está ativa antes de verificar as permissões
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// AUTENTICAÇÃO (AuthN) - Identidade
// O usuário provou quem ele é?
function esta_autenticado() {
    return isset($_SESSION['usuario']['id']);
}

// AUTORIZAÇÃO (AuthZ) - RBAC
// O usuário logado tem permissão para esta ação neste recurso?
function esta_autorizado($recurso, $acao) {
    if (!esta_autenticado()) {
        return false;
    }

    $permissoes = $_SESSION['usuario']['permissoes'];

    // 1. Autorização, O acesso "Super-usuário" que tem acesso total
    if (isset($permissoes['*']) && in_array('*', $permissoes['*'])) {
        return true;
    }

    // 2. Autorização, o usuario tem a permissão exigida ("Recurso + Ação") ?
    if (isset($permissoes[$recurso]) && in_array($acao, $permissoes[$recurso])) {
        return true;
    }

    return false;
}
?>