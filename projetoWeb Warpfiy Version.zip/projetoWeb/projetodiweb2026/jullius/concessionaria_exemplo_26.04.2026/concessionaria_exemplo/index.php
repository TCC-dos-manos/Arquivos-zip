<?php
// index.php - A Vitrine Pública e Painel RBAC
require_once 'conexao.php';
require_once 'controle_acesso.php';

// Busca carros que ainda não foram vendidos para exibir na vitrine
$sqlVitrine = "
SELECT 
     m.nome AS modelo,
     v.cor,
        v.id, v.preco_venda, v.oculta_preco, v.url_foto, 
        m.versao, m.ano, 
        mo.nome AS marca
    FROM veiculo v
    JOIN modelo m ON v.modelo_id = m.id
    JOIN montadora mo ON m.montadora_id = mo.id
    WHERE v.id NOT IN (SELECT veiculo_id FROM venda WHERE valor_final IS NOT NULL)
    order by v.data_compra;
";
$stmt = $pdo->query($sqlVitrine);
$carros_disponiveis = $stmt->fetchAll();

// A MÁGICA AQUI: O PHP embaralha o array! Caso queira que a cada acesso altere a ordem
shuffle($carros_disponiveis);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marreteirus</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 0; padding: 0; }
        
        /* Cabeçalho */
        header { background-color: #155f47; color: white; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; }
        header h1 { margin: 0; font-size: 24px; }
        .auth-area a { color: #fff; text-decoration: none; background-color: #e74c3c; padding: 8px 15px; border-radius: 4px; font-weight: bold; }
        .auth-area a:hover { background-color: #c0392b; }
        .saudacao { margin-right: 15px; font-size: 16px; }

        /* Grid de Veículos */
        .container { max-width: 1200px; margin: 30px auto; padding: 0 15px; }
        .grid-carros { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
        
        /* Cards */
        .card { background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center; padding-bottom: 15px; }
        .card img { width: 100%; height: 180px; object-fit: cover; border-bottom: 3px solid #0bc49f97; }
        .card h3 { margin: 15px 0 5px; color: #333; }
        .card p.detalhes { color: #777; font-size: 14px; margin: 0 0 15px; }
        .preco-liberado { color: #27ae60; font-size: 22px; font-weight: bold; margin: 10px 0; }
        .preco-oculto { color: #f39c12; font-size: 18px; font-weight: bold; font-style: italic; margin: 10px 0; cursor: help; }

        /* Painel Dinâmico RBAC */
        .painel-rbac { max-width: 1160px; margin: 20px auto; padding: 20px; border-radius: 8px; background-color: #fff; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-left: 5px solid #3498db; }
        .painel-rbac h2 { margin-top: 0; color: #2980b9; font-size: 20px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
        .tabela-vendas { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .tabela-vendas th, .tabela-vendas td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        .tabela-vendas th { background-color: #f8f9fa; }

        /* Rodapé Profissional */
        .rodape-prof {
            background-color: #155f47;
            color: #ecf0f1;
            text-align: center;
            padding: 25px 15px;
            margin-top: 50px;
            font-family: Arial, sans-serif;
            line-height: 1.6;
        }
        .rodape-prof p {
            margin: 5px 0;
            font-size: 15px;
        }
        .rodape-destaque {
            font-weight: bold;
            color: #f1c40f; /* Um tom de dourado que destaca no verde */
            font-size: 16px;
        }
        .rodape-direitos {
            font-size: 13px;
            margin-top: 15px;
            color: #bdc3c7;
            font-style: italic;
        }
    </style>
</head>
<body>

    <header>
        <h1>Marreteirus - Seminovos</h1>
        
        <div class="auth-area">
            <?php if (esta_autenticado()): ?>
                <span class="saudacao">Olá, <?= htmlspecialchars($_SESSION['usuario']['nome']) ?>!</span>
                <a href="logout.php" style="background-color: #7f8c8d;">Sair</a>
            <?php else: ?>
                <a href="login.php">Entrar</a>
            <?php endif; ?>
        </div>
    </header>

    <?php 
    // =================================================================
    // PAINEL RBAC: ISOLAMENTO DE DADOS BASEADO EM PERMISSÃO (AuthZ)
    // =================================================================
    if (esta_autenticado()): 
        echo '<div class="painel-rbac">';
        $usuario_id = $_SESSION['usuario']['id'];

        // 1. VISÃO DO GERENTE (Pode ler tudo)
        if (esta_autorizado('venda', 'ler_tudo')) {
            echo "<h2>Painel Gerencial: Todas as Negociações da Loja</h2>";
            $sql = "SELECT v.id, m.nome as carro, ve.preco_venda, p_cli.nome_social as cliente, p_vend.nome_social as vendedor 
                    FROM venda v 
                    JOIN veiculo ve ON v.veiculo_id = ve.id 
                    JOIN modelo m ON ve.modelo_id = m.id
                    JOIN pessoa p_cli ON v.pessoa_id_cliente = p_cli.id
                    JOIN pessoa p_vend ON v.pessoa_id_vendedor = p_vend.id";
            
            $stmt = $pdo->query($sql);
            $vendas = $stmt->fetchAll();

            echo "<table class='tabela-vendas'><tr><th>ID</th><th>Veículo</th><th>Valor Base</th><th>Cliente</th><th>Vendedor</th></tr>";
            foreach ($vendas as $v) {
                echo "<tr><td>#{$v['id']}</td><td>{$v['carro']}</td><td>R$ " . number_format($v['preco_venda'], 2, ',', '.') . "</td><td>{$v['cliente']}</td><td>{$v['vendedor']}</td></tr>";
            }
            echo "</table>";
        } 
        // 2. VISÃO DO VENDEDOR (Lê apenas as próprias vendas)
        elseif (esta_autorizado('venda', 'ler_proprio_vendedor')) {
            echo "<h2>Meu Painel: Minhas Vendas em Andamento</h2>";
            $sql = "SELECT v.id, m.nome as carro, ve.preco_venda, p_cli.nome_social as cliente
                    FROM venda v 
                    JOIN veiculo ve ON v.veiculo_id = ve.id 
                    JOIN modelo m ON ve.modelo_id = m.id
                    JOIN pessoa p_cli ON v.pessoa_id_cliente = p_cli.id
                    JOIN pessoa p_vend ON v.pessoa_id_vendedor = p_vend.id
                    WHERE p_vend.usuario_id = :uid";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['uid' => $usuario_id]);
            $vendas = $stmt->fetchAll();

            echo "<table class='tabela-vendas'><tr><th>ID Venda</th><th>Veículo</th><th>Valor Base</th><th>Seu Cliente</th></tr>";
            foreach ($vendas as $v) {
                echo "<tr><td>#{$v['id']}</td><td>{$v['carro']}</td><td>R$ " . number_format($v['preco_venda'], 2, ',', '.') . "</td><td>{$v['cliente']}</td></tr>";
            }
            echo "</table>";
        }
        // 3. VISÃO DO CLIENTE (Lê apenas as próprias compras)
        elseif (esta_autorizado('venda', 'ler_proprio_cliente')) {
            echo "<h2>Minha Garagem: Pedidos e Compras</h2>";
            $sql = "SELECT v.id, m.nome as carro, ve.preco_venda, p_vend.nome_social as vendedor
                    FROM venda v 
                    JOIN veiculo ve ON v.veiculo_id = ve.id 
                    JOIN modelo m ON ve.modelo_id = m.id
                    JOIN pessoa p_cli ON v.pessoa_id_cliente = p_cli.id
                    JOIN pessoa p_vend ON v.pessoa_id_vendedor = p_vend.id
                    WHERE p_cli.usuario_id = :uid";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['uid' => $usuario_id]);
            $vendas = $stmt->fetchAll();

            echo "<table class='tabela-vendas'><tr><th>Pedido</th><th>Veículo</th><th>Valor Base</th><th>Seu Atendimento</th></tr>";
            foreach ($vendas as $v) {
                echo "<tr><td>#{$v['id']}</td><td>{$v['carro']}</td><td>R$ " . number_format($v['preco_venda'], 2, ',', '.') . "</td><td>Atendido por: {$v['vendedor']}</td></tr>";
            }
            echo "</table>";
        }
        echo '</div>'; 
    endif; 
    ?>

    <div class="container">
        <h2>Veículos Disponíveis</h2>
        <div class="grid-carros">
            <?php foreach ($carros_disponiveis as $carro): ?>
                <div class="card">
                    <img src="<?= htmlspecialchars($carro['url_foto']) ?>" alt="Foto do veículo <?= htmlspecialchars($carro['cor'] . ' ' . $carro['ano']) ?>" title="<?= htmlspecialchars($carro['cor'] . ' ' . $carro['ano']) ?>">
                    
                    <h3><?= htmlspecialchars($carro['marca'] . ' ' . $carro['modelo']) ?></h3>
                    <p class="detalhes"><?= htmlspecialchars($carro['versao'] . ' - ' . $carro['ano']) ?></p>
                    
                    <?php if ($carro['oculta_preco'] == 1 && !esta_autenticado()): ?>
                        <p class="preco-oculto" title="Faça login no sistema ou fale com um vendedor para visualizar o valor deste super esportivo.">Faça login para ver</p>
                    <?php else: ?>
                        <p class="preco-liberado">R$ <?= number_format($carro['preco_venda'], 2, ',', '.') ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <footer class="rodape-prof">

        <p >MODELAGEM DE DADOS APLICADA: <br>SISTEMA COM AUTENTICAÇÃO E AUTORIZAÇÃO (RBAC)</p>
        <p class="rodape-destaque">Desenvolvido por Professor Júllios Félix</p>
        <p>Escola Técnica de Ceilândia</p>
        <p>Banco de Dados II &bull; Módulo III &bull; 2026, 1º Semestre</p>
        <p class="rodape-direitos">Todos os direitos são livres, só informe a fonte.</p>
    </footer>
</body>
</html>