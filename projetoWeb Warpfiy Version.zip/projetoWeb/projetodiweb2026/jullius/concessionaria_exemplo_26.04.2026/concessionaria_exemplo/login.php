<?php
// login.php
session_start();

// Se o usuário já estiver logado, manda pra vitrine
if (isset($_SESSION['usuario']['id'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Marreteirus Seminovos</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            background-color: #f4f4f9; 
            display: flex; 
            flex-direction: column; /* Organiza os itens em coluna */
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
        }
        .login-box { 
            background: white; 
            padding: 30px; 
            border-radius: 8px; 
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); 
            width: 100%; 
            max-width: 400px; 
        }
        .login-box h2 { text-align: center; color: #155f47; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; color: #333; font-weight: bold; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; background-color: #155f47; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; margin-top: 10px; }
        button:hover { background-color: #0e4432; }
        .voltar { display: block; text-align: center; margin-top: 15px; color: #7f8c8d; text-decoration: none; font-size: 14px; }
        .voltar:hover { text-decoration: underline; }
        .erro-msg { background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 15px; text-align: center; border: 1px solid #f5c6cb; }
        
        /* Estilo da cola para testes */
        .credenciais-teste {
            margin-top: 25px;
            color: #7f8c8d; /* Cinza */
            font-size: 14px;
            text-align: center;
            line-height: 1.8;
        }
        .credenciais-teste b {
            color: #555;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h2>Acesso ao Sistema</h2>
        
        <?php if (isset($_GET['erro'])): ?>
            <div class="erro-msg">E-mail ou senha incorretos.</div>
        <?php endif; ?>

        <form action="processa_login.php" method="POST">
            <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" required placeholder="ex: gerente@carta.com.br">
            </div>
            
            <div class="form-group">
                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha" required placeholder="Digite sua senha">
            </div>
            
            <button type="submit">Entrar</button>
        </form>

        <a href="index.php" class="voltar">&larr; Voltar para a Vitrine</a>
    </div>

    <div class="credenciais-teste">
        <b>Contas de Teste (Senha: 123456)</b><br>
        gerente@carta.com.br - Carlos - Gerente<br>
        vendedor@hotmail.com - Maria - Vendedora <br>
        vendedor.segundo@gmail.com - Jose - Vendedor<br>
        cliente.jf@gmail.com - Leticia - Cliente <br>
    </div>

    <div style="text-align: center; margin-top: 20px; font-size: 12px; color: #aaa; padding: 10px; border-top: 1px dashed #ccc;">
        <b>Curiosidade para a turma:</b> O hash gerado neste exato milissegundo para '123456' é:<br>
        <code style="background: #eee; padding: 2px 5px; border-radius: 3px; color: #e74c3c; display: inline-block; margin-top: 5px;">
            <?php echo password_hash('123456', PASSWORD_DEFAULT); ?>
        </code>
    </div>

</body>
</html>