<?php
session_start();

// Verifica se é um gerente autenticado
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['perfil'] !== 'gerente') {
    header("Location: ../login.php"); // Corrigido o caminho
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Painel do Gerente</title>
    <!-- CSS específico para gerente -->
    <link rel="stylesheet" href="../../assets/css/gerente.css"> <!-- Corrigido -->
</head>

<body>
    <header class="topo">
        <div class="container-header">
            <span class="bem-vindo">
                Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario']['nome']) . " (" . htmlspecialchars($_SESSION['usuario']['papel']) . ")"; ?>
            </span>
            <a href="../../controller/LogoutControl.php">Sair</a>
        </div>
    </header>

    <main class="container">
        <h1>Painel do Gerente</h1>
        <p>Aqui você pode acompanhar operações e gerar relatórios de desempenho.</p>


        <div class="form-card" style="text-align: center;">
            <i class="fas fa-users fa-3x" style="color: #007bff;"></i>
            <h2 style="margin-top: 15px;">Gerenciar Usuários</h2>
            <p>Visualize, edite ou exclua contas de usuários cadastrados.</p>
            <a href="../cadastroUsuario.php">Incluir Usuário </a>
            <a class="btn" href="usuarios.php">Listar</a>
        </div>


    </main>
</body>

</html>