<?php
session_start();
$papel_usuario_login = $_SESSION["usuario"]["papel"] ?? "";
$pode_escolher_papel = in_array($papel_usuario_login, ['Administrador']);

// Verifica se veio ?tela=cadastro na URL — assim links externos podem
// abrir direto no painel de cadastro sem o usuário precisar clicar em nada.
// Exemplo: <a href="login-cadastro.php?tela=cadastro">Cadastre-se</a>
$abrir_cadastro = isset($_GET['tela']) && $_GET['tela'] === 'cadastro';
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warpfiy — Entrar ou Cadastrar</title>
    <link rel="stylesheet" href="../assets/css/login-cadastro.css">
</head>

<body>

    <a href="../public/index.php" class="btn-voltar">← Início</a>

    <!--
        A classe "ativo" no container é o interruptor principal.
        Sem .ativo → painel de login visível.
        Com .ativo → painel de cadastro visível.
        O PHP já adiciona .ativo aqui se ?tela=cadastro vier na URL.
    -->
    <div class="container-login-cadastro <?= $abrir_cadastro ? 'ativo' : '' ?>" id="container">

        <!-- ── PAINEL CADASTRO ─────────────────────────── -->
        <div class="painel registro">
            <form action="../controller/PessoaControl.php" method="POST" id="formCadastro">
                <h1>Criar Conta</h1>
                <span class="subtitulo">Preencha seus dados para se registrar.</span>

                <input type="hidden" name="acao" value="cadastrar">
                <input type="hidden" name="ativo" value="1">
                <input type="hidden" name="papel_id" id="papel_id" value="">

                <input type="text" name="nome_completo" placeholder="Nome completo *" required>
                <input type="text" name="nome_social" placeholder="Nome social (opcional)">
                <input type="text" name="cpf" placeholder="CPF — Colaborador" id="cpf">
                <input type="text" name="cnpj" placeholder="CNPJ — Organizador" id="cnpj">
                <input type="text" name="telefone_movel" placeholder="Celular">
                <input type="text" name="cep_end" placeholder="CEP" id="cep_end">
                <input type="text" name="logradouro_end" placeholder="Logradouro" id="logradouro_end">
                <input type="text" name="numero_end" placeholder="Número">
                <input type="text" name="complemento_end" placeholder="Complemento">
                <input type="text" name="bairro_end" placeholder="Bairro" id="bairro_end">
                <input type="text" name="localidade_end" placeholder="Cidade" id="localidade_end">
                <input type="text" name="uf_end" placeholder="UF" id="uf_end" maxlength="2">
                <input type="email" name="email" placeholder="E-mail *" required>
                <input type="password" name="senha_hash" placeholder="Senha *" required id="senha_hash">
                <input type="password" name="confirma_senha" placeholder="Confirmar senha *" required
                    id="confirma_senha">
                <small id="msg_senha" style="display:none;">As senhas não coincidem.</small>

                <?php if ($pode_escolher_papel): ?>
                    <select name="perfil">
                        <option value="2">Organizador</option>
                        <option value="3" selected>Colaborador</option>
                    </select>
                <?php endif; ?>

                <button type="submit">Criar conta</button>
            </form>
        </div>

        <!-- ── PAINEL LOGIN ────────────────────────────── -->
        <div class="painel logar">
            <form action="../controller/LoginControl.php" method="POST" id="formLogin">
                <h1>Entrar</h1>
                <span class="subtitulo">Bem-vindo de volta.</span>

                <input type="text" name="documento" placeholder="E-mail, CPF ou CNPJ" required id="documento">
                <input type="hidden" name="tipo_documento" id="tipo_documento">
                <span id="tipo-detectado" class="tipo-hint"></span>

                <input type="password" name="senha" placeholder="Senha" required>

                <a href="recuperar-senha.php" class="link-esqueci">Esqueceu sua senha?</a>
                <button type="submit">Entrar</button>
            </form>
        </div>

        <!-- ── PAINEL LATERAL ANIMADO ──────────────────── -->
        <div class="ativar-container">
            <div class="ativar">

                <!-- Aparece quando está no cadastro → botão volta pro login -->
                <div class="ativar-painel ativar-esquerda">
                    <h1>Olá, de novo!</h1>
                    <p>Já tem uma conta? Entre e continue de onde parou.</p>
                    <button id="btn-ir-login">Entrar</button>
                </div>

                <!-- Aparece quando está no login → botão vai pro cadastro -->
                <div class="ativar-painel ativar-direita">
                    <h1>Bem-vindo ao Warpfiy!</h1>
                    <p>Conectando talentos e eventos. Cadastre-se e faça parte.</p>
                    <button id="btn-ir-cadastro">Cadastrar</button>
                </div>

            </div>
        </div>

    </div><!-- fim #container -->

    <script src="../assets/js/validacoes.js"></script>
    <script src="../assets/js/login-cadastro.js"></script>

</body>

</html>