<?php
session_start();
require_once '../../model/dao/UsuarioDAO.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['papel'] !== 'Gerente') {
    header("Location: ../login.php");
    exit;
}

$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: usuarios.php");
    exit;
}

$usuarioDAO = new UsuarioDAO();
$usuario = $usuarioDAO->buscarPorId($id);

if (!$usuario) {
    echo "Usuário não encontrado.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Editar Usuário</title>
    <link rel="stylesheet" href="../../assets/css/style.css"> <!-- Aplicando o novo estilo -->
</head>

<body>
    <header>
        <span style="float: left; font-weight: bold;">
            Editar Usuário
        </span>
        <a href="../../controller/LogoutControl.php">Sair</a>
    </header>

    <div class="container">
        <h1>Editar Usuário</h1>
        <p>Atualize as informações abaixo e clique em "Salvar Alterações".</p>

        <form action="../../controller/UsuarioControl.php" method="POST" class="form-card">
            <input type="hidden" name="id" value="<?= $usuario['id'] ?>">

            <label>Nome:</label>
            <input type="text" name="nome" value="<?= htmlspecialchars($usuario['nome']) ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($usuario['email']) ?>" required>

            <label>Perfil:</label>
            <select name="perfil" required>
                <option value="cliente" <?= $usuario['perfil'] === 'cliente' ? 'selected' : '' ?>>Cliente</option>
                <option value="gerente" <?= $usuario['perfil'] === 'gerente' ? 'selected' : '' ?>>Gerente</option>
                <option value="admin" <?= $usuario['perfil'] === 'admin' ? 'selected' : '' ?>>Admin</option>
            </select>

            <button type="submit" name="acao" value="atualizar" class="btn">Salvar Alterações</button>
            <a href="usuarios.php" class="btn" style="background-color: #6c757d; margin-left: 10px;">Cancelar</a>
        </form>
    </div>
</body>

</html>