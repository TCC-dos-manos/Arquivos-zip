<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['papel'] !== 'Gerente') {
    header("Location: ../../public/index.php");
    exit;
}

$id_pessoa_login = $_SESSION['usuario']["pessoa_id"]  ?? null;;
$id_usuario_login = $_SESSION['usuario']["usuario_id"]  ?? null;;
$id_papel_login = $_SESSION['usuario']['papel']  ?? null;;

if (!$id_usuario_login) {
    header("Location: ../../public/index.php");
    exit;
}



?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Inclusão de Pessoa/Usuário</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>

<body>
    <header>
        <a href="../../controller/logoutControl.php">Login</a>
        <a href="../public/index.php">Início</a>
    </header>

    <div class="container">
        <h1>Cadastro de Pessoa/Usuário</h1>
        <p>Preencha os dados abaixo para incluir uma Pessoa e configurar um Usuário para acesso.</p>

        <form id="formCadastro" action="../controller/PessoaControl.php" method="POST" class="form-card">
            <label>Nome Completo:</label>
            <input type="text" name="nome_completo" required>
            <label>Nome Social (deixar em branco se não for o caso):</label>
            <input type="text" name="nome_social">
            <label>CPF:</label>
            <input type="text" name="cpf" required>
            <label>RG:</label>
            <input type="text" name="rg" required>

            <label>Telefone Móvel:</label>
            <input type="text" id="telefone_movel" name="telefone_movel">
            <label>Telefone Fixo:</label>
            <input type="text" id="telefone_fixo" name="telefone_fixo">
            <label>CEP:</label>
            <input type="text" id="cep_end" name="cep_end">
            <label>Endereço:</label>
            <input type="text" id="logradouro_end" name="logradouro_end">

            <label>Número:</label>
            <input type="text" id="numero_end" name="numero_end">

            <label>Complemento:</label>
            <input type="text" id="complemento_end" name="complemento_end">

            <label>Bairro:</label>
            <input type="text" id="bairro_end" name="bairro_end">

            <label>Cidade:</label>
            <input type="text" id="localidade_end" name="localidade_end">

            <label>UF:</label>
            <input type="text" id="uf_end" name="uf_end">

            <!-- campos para o cadastro de usuário -->
            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Senha:</label>
            <input type="password" id="senha" name="senha" required>

            <label>Repita a Senha:</label>
            <input type="password" id="confirma_senha" name="confirma_senha" required>
            <small id="msg_senha" style="color:red; display:none;">As senhas não coincidem.</small>

            <!-- este trecho é destinado a escolha do Papel do Usuário associado à inclusão -->
            <label>Papel:</label>
            <select name="papel">
                <option value="cliente">Cliente</option>
                <option value="gerente">Gerente</option>
                <option value="admin">Admin</option>
            </select>
            -->
            <!-- papel_id = 3 -> Id do papel Cliente -->
            <input type="hidden" name="papel_id" value="3">
            <!-- ativo = 1 -> Todo usuário se inclui como ATIVO no sistema -->
            <input type="hidden" name="ativo" value="1">

            <input type="submit" value="Cadastrar" class="btn">
        </form>
    </div>

    <script src="../assets/js/validacoes.js"></script>
</body>

</html>