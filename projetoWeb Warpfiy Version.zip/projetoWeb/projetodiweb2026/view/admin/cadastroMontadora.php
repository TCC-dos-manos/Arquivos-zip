<?php
session_start();
// Verifica se o usuário está logado para capturar informações de sessão
if (isset($_SESSION["usuario"]) && ($_SESSION["usuario"]["papel"] == "Gerente" || $_SESSION["usuario"]["papel"] == "Administrador") ) {
    $id_usuario_login = $_SESSION["usuario"]["id"];
    $papel_usuario_login = $_SESSION["usuario"]["papel"];
} else {
  //SE  
  header("location: public/index.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastro de Montadora</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <header>
        <?php
        
            echo '<a href="../controller/LogoutControl.php">Sair</a>';
        
        ?>
        <a href="../public/index.php">Início</a>
    </header>

    <div class="container">
        <h1>Cadastro de Montadora</h1>
        <p>Preencha os dados abaixo para registrar uma nova montadora.</p>

        <form id="formCadastroMontadora" action="../../controller/MontadoraControl.php" method="POST" class="form-card">
            
            <!-- O CAMPO acao será usado no controller para definir o comando CRUD -->
            <input type="hidden" name="acao" value="cadastrar">

            <label>Nome da Montadora:</label>
            <input type="text" name="nome" required placeholder="Ex: Volkswagen, Toyota...">

            <label>País de Origem:</label>
            <input type="text" name="pais_origem" required placeholder="Ex: Alemanha, Japão...">
            <input type="submit" value="Cadastrar Montadora" class="btn">
        </form>
    </div>

</body>

</html>