<?php
session_start();

if (!isset($_SESSION['usuario']) || !(strpos('Administrador Gerente', $_SESSION['usuario']['papel']) > 0)) {
//    header("Location: ../login.php");
//    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Painel do Administrador</title>
    <link rel="stylesheet" href="../../assets/css/style.css"> <!-- Aplicando o estilo global -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <header>
        <span style="float: left; font-weight: bold;">
            Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario']['nome']) . " (" . htmlspecialchars($_SESSION['usuario']['papel']) . ")"; ?>
        </span>
        <a href="../../controller/LogoutControl.php">Sair</a>
    </header>

    <div class="container">
        <h1>Painel do Administrador</h1>
        <p>Aqui você pode gerenciar usuários, visualizar relatórios e configurar o sistema.</p>

        <div class="form-card" style="text-align: center;">
            <i class="fas fa-users fa-3x" style="color: #007bff;"></i>
            <h2 style="margin-top: 15px;">Gerenciar Usuários</h2>
            <p>Visualize, edite ou exclua contas de usuários cadastrados.</p>
            <a href="../cadastroUsuario.php">Incluir Usuário </a>
            <a class="btn" href="usuarios.php">Listar</a>
        </div>
    </div>
</body>

</html>