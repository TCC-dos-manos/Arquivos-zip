<?php
session_start();
require_once '../../model/dao/UsuarioDAO.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['perfil'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: usuarios.php");
    exit;
}

$id = (int)$_GET['id'];
$usuarioDAO = new UsuarioDAO();

if ($usuarioDAO->excluir($id)) {
    header("Location: usuarios.php?msg=usuario_excluido");
} else {
    header("Location: usuarios.php?msg=erro_excluir");
}
exit;
