<?php
session_start();
require_once '../../model/dao/UsuarioDAO.php';
require_once '../../model/dto/UsuarioDTO.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['perfil'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: usuarios.php");
    exit;
}

$usuarioDAO = new UsuarioDAO();
$id = (int)$_GET['id'];
$dados = $usuarioDAO->buscarPorId($id);

if ($dados) {
    $usuarioDTO = new UsuarioDTO();
    $usuarioDTO->setId($id);
    $usuarioDTO->setNome($dados['nome']);
    $usuarioDTO->setEmail($dados['email']);
    $usuarioDTO->setPerfil($dados['perfil']);
    $usuarioDTO->setTelefone($dados['telefone']);
    $usuarioDTO->setSenha("123"); // Nova senha padrão

    $usuarioDAO->atualizarSenha($usuarioDTO); // Ver próximo passo
}

header("Location: usuarios.php?msg=senha_resetada");
exit;
