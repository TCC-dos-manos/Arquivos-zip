<?php
session_start();
require_once '../../model/dao/UsuarioDAO.php';

// Verifica se o usuário está logado e se o perfil é 'admin'
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['pepel'] !== 'Administrador') {
    //header("Location: ../login.php");
    //exit;
}

// Verifica se existe pesquisa e ajusta a busca
$pesquisa = isset($_GET['pesquisa']) ? $_GET['pesquisa'] : '';
$usuarioDAO = new UsuarioDAO();

// Se pesquisa for informada, utiliza a função de pesquisa. Caso contrário, lista todos os usuários.
$usuarios = $usuarioDAO->listarComPesquisa($pesquisa, 0, 100);  // Paginação com offset e limit
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Usuários</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <header>
        <a href="home_admin.php">← Voltar</a>
        <a href="../../controller/LogoutControl.php">Sair</a>
    </header>

    <div class="container">
        <h1>Gerenciar Usuários</h1>
        <p>Visualize, edite ou exclua os usuários cadastrados no sistema.</p>

        <!-- Mensagem de sucesso -->
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'senha_resetada'): ?>
            <p style="color: green; font-weight: bold;">Senha resetada com sucesso para senha padrão.</p>
        <?php endif; ?>

        <!-- Campo de pesquisa -->
        <form method="GET" action="usuarios.php">
            <input type="text" name="pesquisa" placeholder="Pesquisar por nome ou email" value="<?= htmlspecialchars($pesquisa) ?>">
            <button type="submit" class="btn">Pesquisar</button>
        </form>

        <!-- Tabela de usuários -->
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Papel</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0; // Variável para alternar as cores das linhas
                foreach ($usuarios as $usuario):
                    // Alternar a classe de linha (cores alternadas)
                    $linhaClasse = $i % 2 == 0 ? 'linha-par' : 'linha-impar';
                    $i++;
                ?>
                    <tr class="<?= $linhaClasse ?>">
                        <?php $nome_lista = empty($usuario['nome_social'])?$usuario['nome_completo']:$usuario['nome_social']; ?>
                        <td><?= htmlspecialchars($nome_lista) ?></td>
                        <td><?= htmlspecialchars($usuario['email']) ?></td>
                        <td><?= htmlspecialchars($usuario['nome_papel']) ?></td>
                        <td>
                            <div class="acoes">
                                <!-- Alterando para botões com a classe .btn -->
                                <a href="editar_usuario.php?id=<?= $usuario['id'] ?>" class="btn">Editar</a>
                                <a href="resetar_senha.php?id=<?= $usuario['id'] ?>" class="btn" 
                                   onclick="return confirm('Tem certeza que deseja resetar a senha para \"123\"?')">Resetar Senha</a>
                                <a href="excluir_usuario.php?id=<?= $usuario['id'] ?>" class="btn" 
                                   onclick="return confirm('Tem certeza que deseja excluir este usuário?')">Excluir</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
