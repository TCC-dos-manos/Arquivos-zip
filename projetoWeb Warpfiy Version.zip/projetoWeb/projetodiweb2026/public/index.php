<?php
session_start();
//print_r($_SESSION["usuario"]);
if (isset($_SESSION["usuario"])) {
    $id_usuario_login = $_SESSION["usuario"]["id"];
    $papel_usuario_login = $_SESSION["usuario"]["papel"];
} else {
    $id_usuario_login = "";
    $papel_usuario_login = "";
}

switch ($papel_usuario_login) {
    case 'Gerente':
        header("Location: ../view/gerente/home_gerente.php");
        break;
    case 'Administrador':
        header("Location: ../view/admin/home_admin.php");
        break;
    case 'Vendedor':
        header("Location: ../view/vendedor/home_vendedor.php");
        break;
    case 'Cliente':
        header("Location: ../view/cliente/home_cliente.php");
        break;
    case 'Suporte':
        header("Location: ../view/suporte/home_suporte.php");
        break;
         
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Bem-vindo ao Meu Projeto</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        header {
            background: #333;
            color: #fff;
            padding: 15px;
            text-align: right;
        }

        header a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            margin-left: 20px;
        }

        .container {
            margin-top: 100px;
        }

        h1 {
            color: #333;
        }

        p {
            color: #555;
            font-size: 18px;
        }

        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.3s;
        }

        .btn:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>
    <header>
        <a href="../view/login-cadastro.php">Login</a>
    </header>

    <div class="container">
        <h1>Bem-vindo ao PROJETO DIEWB</h1>
        <p>
            Esta é a tela inicial do seu projeto.
            Modifique este layout para personalizar o sistema conforme suas necessidades.
        </p>
        <a href="../view/login-cadastro.php" class="btn">Fazer Cadastro</a>

    </div>
</body>

</html>