<?php
class UsuarioDTO
{
    private $id;
    private $email;
    private $senha_hash;
    private $ativo;
    private $data_criacao;

    // Getters e Setters
    public function getid()
    {
        return $this->id;
    }
    public function setid($id)
    {
        $this->id = $id;
    }

    public function getemail()
    {
        return $this->email;
    }
    public function setemail($email)
    {
        $this->email = $email;
    }

    public function getsenha_hash()
    {
        return $this->senha_hash;
    }
    public function setsenha_hash($senha_hash)
    {
        $this->senha_hash = $senha_hash;
    }

    public function getativo()
    {
        return $this->ativo;
    }
    public function setativo($ativo)
    {
        $this->ativo = $ativo;
    }

    public function getdata_criacao()
    {
        return $this->data_criacao;
    }
    public function setdata_criacao($data_criacao)
    {
        $this->data_criacao = $data_criacao;
    }
}
