<?php
class MontadoraDTO {
    private $id;
    private $nome;
    private $pais_origem;

    // Getters e Setters

    public function getid() {
        return $this->id;
    }
    public function setid($id) {
        $this->id = $id;
    }

    public function getnome() {
        return $this->nome;
    }
    public function setnome($nome) {
        $this->nome = $nome;
    }

    public function getpais_origem() {
        return $this->pais_origem;
    }
    public function setpais_origem($pais_origem) {
        $this->pais_origem = $pais_origem;
    }
}