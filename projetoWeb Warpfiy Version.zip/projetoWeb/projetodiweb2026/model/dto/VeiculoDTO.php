<?php
class VeiculoDTO {
    private $id;
    private $modelo_id;
    private $chassi;
    private $cor;
    private $preco_compra;
    private $preco_venda;
    private $data_compra;
    private $oculta_preco;
    private $url_foto;

    // Getters e Setters

    public function getid() {
        return $this->id;
    }
    public function setid($id) {
        $this->id = $id;
    }

    public function getmodelo_id() {
        return $this->modelo_id;
    }
    public function setmodelo_id($modelo_id) {
        $this->modelo_id = $modelo_id;
    }

    public function getchassi() {
        return $this->chassi;
    }
    public function setchassi($chassi) {
        $this->chassi = $chassi;
    }

    public function getcor() {
        return $this->cor;
    }
    public function setcor($cor) {
        $this->cor = $cor;
    }

    public function getpreco_compra() {
        return $this->preco_compra;
    }
    public function setpreco_compra($preco_compra) {
        $this->preco_compra = $preco_compra;
    }

    public function getpreco_venda() {
        return $this->preco_venda;
    }
    public function setpreco_venda($preco_venda) {
        $this->preco_venda = $preco_venda;
    }

    public function getdata_compra() {
        return $this->data_compra;
    }
    public function setdata_compra($data_compra) {
        $this->data_compra = $data_compra;
    }

    public function getoculta_preco() {
        return $this->oculta_preco;
    }
    public function setoculta_preco($oculta_preco) {
        $this->oculta_preco = $oculta_preco;
    }

    public function geturl_foto() {
        return $this->url_foto;
    }
    public function seturl_foto($url_foto) {
        $this->url_foto = $url_foto;
    }
}