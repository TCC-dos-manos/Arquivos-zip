<?php
class ModeloDTO {
    private $id;
    private $nome;
    private $versao;
    private $ano;
    private $montadora_id;

    // Getters e Setters

    public function getid() {
        return $this->id;
    }
    public function setid($id) {
        $this->id = $id;
    }

    public function getnome() {
        return $this->nome;
    }
    public function setnome($nome) {
        $this->nome = $nome;
    }

    public function getversao() {
        return $this->versao;
    }
    public function setversao($versao) {
        $this->versao = $versao;
    }

    public function getano() {
        return $this->ano;
    }
    public function setano($ano) {
        $this->ano = $ano;
    }

    public function getmontadora_id() {
        return $this->montadora_id;
    }
    public function setmontadora_id($montadora_id) {
        $this->montadora_id = $montadora_id;
    }
}