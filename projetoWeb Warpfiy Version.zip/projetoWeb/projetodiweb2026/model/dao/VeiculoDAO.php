<?php
require_once "Conexao.php";
require_once __DIR__ . "/../dto/VeiculoDTO.php";

class VeiculoDAO
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }

    // Cadastra um novo veículo
    public function cadastrar(VeiculoDTO $veiculo)
    {
        $sql = "INSERT INTO veiculo (
                    modelo_id, chassi, cor, preco_compra, preco_venda, 
                    data_compra, oculta_preco, url_foto
                ) VALUES (
                    :modelo_id, :chassi, :cor, :preco_compra, :preco_venda, 
                    :data_compra, :oculta_preco, :url_foto
                )";

        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":modelo_id", $veiculo->getmodelo_id(), PDO::PARAM_INT);
        $stmt->bindValue(":chassi", $veiculo->getchassi());
        $stmt->bindValue(":cor", $veiculo->getcor());
        $stmt->bindValue(":preco_compra", $veiculo->getpreco_compra());
        $stmt->bindValue(":preco_venda", $veiculo->getpreco_venda());
        $stmt->bindValue(":data_compra", $veiculo->getdata_compra());
        $stmt->bindValue(":oculta_preco", $veiculo->getoculta_preco(), PDO::PARAM_INT);
        $stmt->bindValue(":url_foto", $veiculo->geturl_foto());

        $stmt->execute();
        
        // Retorna o ID gerado para o veículo
        return $this->pdo->lastInsertId();
    }

    // Lista todos os veículos com informações do modelo e montadora
    public function listar()
    {
        $sql = "SELECT v.*, m.nome as nome_modelo, mon.nome as nome_montadora 
                FROM veiculo v
                INNER JOIN modelo m ON v.modelo_id = m.id
                INNER JOIN montadora mon ON m.montadora_id = mon.id
                ORDER BY v.id DESC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lista veículos com pesquisa por chassi ou modelo
    public function listarComPesquisa($pesquisa, $offset = 0, $limit = 100)
    {
        $sql = "SELECT v.*, m.nome as nome_modelo 
                FROM veiculo v
                INNER JOIN modelo m ON v.modelo_id = m.id
                WHERE v.chassi LIKE :pesquisa OR m.nome LIKE :pesquisa
                ORDER BY v.id DESC 
                LIMIT :offset, :limit";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':pesquisa', '%' . $pesquisa . '%');
        $stmt->bindValue(':offset', (int) $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Busca um veículo pelo ID
    public function buscarPorId($id)
    {
        $sql = "SELECT * FROM veiculo WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Atualiza os dados de um veículo
    public function atualizar(VeiculoDTO $veiculo)
    {
        $sql = "UPDATE veiculo SET 
                    modelo_id = :modelo_id, 
                    chassi = :chassi, 
                    cor = :cor, 
                    preco_compra = :preco_compra, 
                    preco_venda = :preco_venda, 
                    data_compra = :data_compra, 
                    oculta_preco = :oculta_preco, 
                    url_foto = :url_foto
                WHERE id = :id";

        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":modelo_id", $veiculo->getmodelo_id(), PDO::PARAM_INT);
        $stmt->bindValue(":chassi", $veiculo->getchassi());
        $stmt->bindValue(":cor", $veiculo->getcor());
        $stmt->bindValue(":preco_compra", $veiculo->getpreco_compra());
        $stmt->bindValue(":preco_venda", $veiculo->getpreco_venda());
        $stmt->bindValue(":data_compra", $veiculo->getdata_compra());
        $stmt->bindValue(":oculta_preco", $veiculo->getoculta_preco(), PDO::PARAM_INT);
        $stmt->bindValue(":url_foto", $veiculo->geturl_foto());
        $stmt->bindValue(":id", $veiculo->getid(), PDO::PARAM_INT);

        return $stmt->execute();
    }

    // Exclui um veículo pelo ID
    public function excluir($id)
    {
        $sql = "DELETE FROM veiculo WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}