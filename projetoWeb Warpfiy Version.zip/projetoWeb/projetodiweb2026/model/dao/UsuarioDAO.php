<?php
require_once "Conexao.php";
require_once __DIR__ . "/../dto/UsuarioDTO.php";

class UsuarioDAO
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }

    // Cadastra um novo usuário
    public function cadastrar(UsuarioDTO $usuario)
    {
        $sql = "INSERT INTO usuario (email, senha_hash, ativo, data_criacao) 
                VALUES (:email, :senha_hash, :ativo, :data_criacao)";
        $stmt = $this->pdo->prepare($sql);
        //$stmt->bindValue(":nome", $usuario->getNome());
        $stmt->bindValue(":email", $usuario->getemail());
        // Salva a senha que já está hashada
        $stmt->bindValue(":senha_hash", $usuario->getsenha_hash());
        $stmt->bindValue(":ativo", $usuario->getativo());
        $stmt->bindValue(":data_criacao", $usuario->getdata_criacao());

        $stmt->execute();
        //após inserir o USUARIO, retorno o ID que o banco gerou para o registro
        //esse ID será usado na inclusão dos dados da PESSOA
        return $this->pdo->lastInsertId();
    }

    // Lista todos os usuários
    public function listar()
    {
        $sql = "SELECT u.*,u.id as id_usuario,
           p.*,p.id as id_pessoa,upapel.*,
           papel.nome as nome_papel,
           upapel.id as id_usuario_papel 
           FROM usuario u 
           INNER JOIN pessoa p ON u.id = p.usuario_id
           INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
           INNER JOIN papel ON upapel.papel_id = papel.id
           ORDER BY p.nome ASC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lista usuários com pesquisa e paginação
    public function listarComPesquisa($pesquisa, $offset = 0, $limit = 100)
    {
        $sql = "SELECT u.*,u.id as id_usuario,
           p.*,p.id as id_pessoa,upapel.*,
           papel.nome as nome_papel,
           upapel.id as id_usuario_papel 
           FROM usuario u 
           INNER JOIN pessoa p ON u.id = p.usuario_id
           INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
           INNER JOIN papel ON upapel.papel_id = papel.id
           WHERE p.nome_completo LIKE :pesquisa OR u.email LIKE :pesquisa
                 OR p.nome_social LIKE :pesquisa
           ORDER BY p.nome_completo ASC 
           LIMIT :offset, :limit";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':pesquisa', '%' . $pesquisa . '%');
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Conta o número total de usuários com base na pesquisa
    public function contarUsuariosComPesquisa($pesquisa)
    {
        $sql = "SELECT COUNT(*) 
                FROM usuario u, pessoa p
                INNER JOIN u.id = pessoa.usuario_id
                WHERE p.nome_completo LIKE :pesquisa OR u.email LIKE :pesquisa
                     OR p.nome_social LIKE :pesquisa ";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':pesquisa', '%' . $pesquisa . '%');
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    // Busca um usuário pelo ID
    public function buscarPorId($id)
    {
        $sql = "SELECT u.*,u.id as id_usuario,
           p.*,p.id as id_pessoa,upapel.*,
           papel.nome as nome_papel,
           upapel.id as id_usuario_papel 
           FROM usuario u 
           INNER JOIN pessoa p ON u.id = p.usuario_id
           INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
           INNER JOIN papel ON upapel.papel_id = papel.id 
           WHERE u.id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Busca um usuário pelo email
    public function buscarPorEmail($email)
    {
        // Corrigido nome da tabela para 'usuario'
        $sql = "SELECT u.*,u.id as id_usuario,
           p.*,p.id as id_pessoa,upapel.*,
           papel.nome as nome_papel,
           upapel.id as id_usuario_papel 
           FROM usuario u 
           INNER JOIN pessoa p ON u.id = p.usuario_id
           INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
           INNER JOIN papel ON upapel.papel_id = papel.id 
         WHERE u.email = :email";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':email', $email);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Atualiza um usuário pelo ID
    // Não se atualiza a senha_hash juntamente com os demais dados
    // Devemos atualizar o email e o ativo (1 = true, 0 = false)
    public function atualizar(UsuarioDTO $usuario)
    {
        $sql = "UPDATE usuario 
                SET email = :email, ativo = :ativo 
                WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);

        $stmt->bindValue(":email", $usuario->getemail());
        $stmt->bindValue(":ativo", $usuario->getativo());
        $stmt->bindValue(":id", $usuario->getid(), PDO::PARAM_INT);

        return $stmt->execute();
    }

    // Atualiza um usuário pelo ID
    public function alterarSenha($id_usuario, $senha_hash)
    {
        $sql = "UPDATE usuario 
                SET senha_hash = :senha_hash 
                WHERE id = :id_usuario";
        $stmt = $this->pdo->prepare($sql);

        $stmt->bindValue(":senha_hash", $senha_hash);
        $stmt->bindValue(":id", $id_usuario, PDO::PARAM_INT);

        return $stmt->execute();
    }

    // Exclui um usuário pelo ID
    public function excluir($id)
    {
        //fazer pesquisa verificando se existe algum registro
        //nas tabelas associadas - não deixar excluir
        $sql = "DELETE FROM usuario WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    // INSERE O PAPEL DO USUÁRIO NA TABELA DE RELACIONAMENTO
    public function inserirUsuarioPapel($usuario_id, $papel_id)
    {
        $data_inicio   = date("Y-m-d H:i:s");
        $sql = "INSERT INTO usuario_papel(usuario_id, papel_id, data_inicio) 
                VALUES (:usuario_id, :papel_id, :data_inicio) ";
        $stmt = $this->pdo->prepare($sql);

        $stmt->bindValue(":usuario_id", $usuario_id, PDO::PARAM_INT);
        $stmt->bindValue(":papel_id", $papel_id, PDO::PARAM_INT);
        $stmt->bindValue(":data_inicio", $data_inicio);

        return $stmt->execute();
        // $this->pdo->lastInsertId();

    }

    // Reseta a senha do usuário para "123456"

    public function resetarSenha($id)
    {
        $novaSenha = password_hash("123456", PASSWORD_DEFAULT);  // Senha padrão
        $sql = "UPDATE usuario SET senha_hash = :novaSenha WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":novaSenha", $novaSenha);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);

        $stmt->execute();
        // Retorna o ID gerado pelo banco de dados
        //return $this->pdo->lastInsertId();
    }

    public function estaAutorizado($id,$recurso,$acao,$arrayPermissoes)
    {
        
    
    $novaSenha = password_hash("123456", PASSWORD_DEFAULT);  // Senha padrão
        $sql = "UPDATE usuario SET senha_hash = :novaSenha WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":novaSenha", $novaSenha);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);

        $stmt->execute();
        // Retorna o ID gerado pelo banco de dados
        //return $this->pdo->lastInsertId();
    }
    
}
