
<?php
require_once "Conexao.php";
require_once __DIR__ . "/../dto/PessoaDTO.php";

class PessoaDAO
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }

    // Cadastra uma nova pessoa
    public function cadastrar(PessoaDTO $pessoa)
    {
        $sql = "INSERT INTO pessoa (
                    usuario_id, nome_completo, nome_social, cpf, rg, 
                    telefone_movel, telefone_fixo, cep_end, logradouro_end, 
                    numero_end, complemento_end, bairro_end, localidade_end, uf_end
                ) VALUES (
                    :usuario_id, :nome_completo, :nome_social, :cpf, :rg, 
                    :telefone_movel, :telefone_fixo, :cep_end, :logradouro_end, 
                    :numero_end, :complemento_end, :bairro_end, :localidade_end, :uf_end
                )";

        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":usuario_id", $pessoa->getusuario_id());
        $stmt->bindValue(":nome_completo", $pessoa->getnome_completo());
        $stmt->bindValue(":nome_social", $pessoa->getnome_social());
        $stmt->bindValue(":cpf", $pessoa->getcpf());
        $stmt->bindValue(":rg", $pessoa->getrg());
        $stmt->bindValue(":telefone_movel", $pessoa->gettelefone_movel());
        $stmt->bindValue(":telefone_fixo", $pessoa->gettelefone_fixo());
        $stmt->bindValue(":cep_end", $pessoa->getcep_end());
        $stmt->bindValue(":logradouro_end", $pessoa->getlogradouro_end());
        $stmt->bindValue(":numero_end", $pessoa->getnumero_end());
        $stmt->bindValue(":complemento_end", $pessoa->getcomplemento_end());
        $stmt->bindValue(":bairro_end", $pessoa->getbairro_end());
        $stmt->bindValue(":localidade_end", $pessoa->getlocalidade_end());
        $stmt->bindValue(":uf_end", $pessoa->getuf_end());

        $stmt->execute();
        //após inserir a PESSOA, retorno o ID que o banco gerou para o registro
        //esse ID será usado na inclusão do PAPEL USUARIO X PESSOA
        return $this->pdo->lastInsertId();
    }

    // Lista todas as pessoas
    public function listar()
    {
        $sql = "SELECT p.*,p.id as id_pessoa,upapel.*,
       u.*,u.id as id_usuario, 
       papel.nome as nome_papel,
       upapel.id as id_usuario_papel 
       FROM pessoa p  
       LEFT JOIN usuario u ON p.usuario_id = u.id  
       LEFT JOIN usuario_papel upapel ON u.id = upapel.usuario_id
       LEFT JOIN papel ON upapel.papel_id = papel.id
       ORDER BY p.nome_completo ASC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lista pessoas com pesquisa por nome ou CPF
    public function listarComPesquisa($pesquisa, $offset = 0, $limit = 100)
    {
        $sql = "SELECT p.*,p.id as id_pessoa,upapel.*,
              u.*,u.id as id_usuario, 
              papel.nome as nome_papel,
              upapel.id as id_usuario_papel 
            FROM pessoa p  
            LEFT JOIN usuario u ON p.usuario_id = u.id  
            LEFT JOIN usuario_papel upapel ON u.id = upapel.usuario_id
            LEFT JOIN papel ON upapel.papel_id = papel.id 
            WHERE nome_completo LIKE :pesquisa OR cpf LIKE :pesquisa
            ORDER BY p.nome_completo ASC 
            LIMIT :offset, :limit";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':pesquisa', '%' . $pesquisa . '%');
        $stmt->bindValue(':offset', (int) $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Busca uma pessoa pelo ID
    public function buscarPorId($id)
    {
        $sql = "SELECT p.*,p.id as id_pessoa,upapel.*,
              u.*,u.id as id_usuario, 
              papel.nome as nome_papel,
              upapel.id as id_usuario_papel 
            FROM pessoa p  
            LEFT JOIN usuario u ON p.usuario_id = u.id  
            LEFT JOIN usuario_papel upapel ON u.id = upapel.usuario_id
            LEFT JOIN papel ON upapel.papel_id = papel.id 
         WHERE p.id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Busca dados da pessoa pelo ID do usuário vinculado
    public function buscarPorPessoaId($usuario_id)
    {
        $sql = "SELECT p.*,p.id as id_pessoa,upapel.*,
              u.*,u.id as id_usuario, 
              papel.nome as nome_papel,
              upapel.id as id_usuario_papel 
            FROM pessoa p  
            INNER JOIN usuario u ON p.usuario_id = u.id  
            INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
            INNER JOIN papel ON upapel.papel_id = papel.id 
            WHERE p.usuario_id = :usuario_id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':usuario_id', $usuario_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Atualiza os dados de uma pessoa
    public function atualizar(PessoaDTO $pessoa)
    {
        $sql = "UPDATE pessoa SET 
                    nome_completo = :nome_completo, 
                    nome_social = :nome_social, 
                    cpf = :cpf, 
                    rg = :rg, 
                    telefone_movel = :telefone_movel, 
                    telefone_fixo = :telefone_fixo, 
                    cep_end = :cep_end, 
                    logradouro_end = :logradouro_end, 
                    numero_end = :numero_end, 
                    complemento_end = :complemento_end, 
                    bairro_end = :bairro_end, 
                    localidade_end = :localidade_end,                     
                    uf_end = :uf_end,
                    usuario_id = :usuario_id
                WHERE id = :id";

        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":nome_completo", $pessoa->getnome_completo());
        $stmt->bindValue(":nome_social", $pessoa->getnome_social());
        $stmt->bindValue(":cpf", $pessoa->getcpf());
        $stmt->bindValue(":rg", $pessoa->getrg());
        $stmt->bindValue(":telefone_movel", $pessoa->gettelefone_movel());
        $stmt->bindValue(":telefone_fixo", $pessoa->gettelefone_fixo());
        $stmt->bindValue(":cep_end", $pessoa->getcep_end());
        $stmt->bindValue(":logradouro_end", $pessoa->getlogradouro_end());
        $stmt->bindValue(":numero_end", $pessoa->getnumero_end());
        $stmt->bindValue(":complemento_end", $pessoa->getcomplemento_end());
        $stmt->bindValue(":bairro_end", $pessoa->getbairro_end());
        $stmt->bindValue(":localidade_end", $pessoa->getlocalidade_end());
        $stmt->bindValue(":uf_end", $pessoa->getuf_end());
        $stmt->bindValue(":usuario_id", $pessoa->getusuario_id());
        $stmt->bindValue(":id", $pessoa->getId(), PDO::PARAM_INT);

        return $stmt->execute();
    }

    // Exclui uma pessoa pelo ID
    public function excluir($id)
    {
        $sql = "DELETE FROM pessoa WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
