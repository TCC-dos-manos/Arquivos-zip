<?php
require_once "Conexao.php";
require_once __DIR__ . "/../dto/ModeloDTO.php";

class ModeloDAO
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }

    // Cadastra um novo modelo
    public function cadastrar($nome, $versao, $ano, $montadora_id)
    {
        $sql = "INSERT INTO modelo (nome, versao, ano, montadora_id) 
                VALUES (:nome, :versao, :ano, :montadora_id)";
        $stmt = $this->pdo->prepare($sql);
        
        $stmt->bindValue(":nome", $nome);
        $stmt->bindValue(":versao", $versao);
        $stmt->bindValue(":ano", $ano);
        $stmt->bindValue(":montadora_id", $montadora_id, PDO::PARAM_INT);

        return $stmt->execute();
    }

    // Lista todos os modelos
    public function listar()
    {
        $sql = "SELECT modelo.*,modelo.nome as nome_modelo, montadora.*,
               montadora.nome as nome_montadora
        FROM modelo
        INNER JOIN montadora ON modelo.montadora_id = montadora.id
        ORDER BY modelo.nome, montadora.nome ASC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lista modelos com pesquisa e paginação
    public function listarComPesquisa($pesquisa, $offset = 0, $limit = 100)
    {
        $sql = "SELECT modelo.*,modelo.nome as nome_modelo, montadora.*,
                       montadora.nome as nome_montadora
                FROM modelo
                INNER JOIN montadora ON modelo.montadora_id = montadora.id
                WHERE modelo.nome_modelo LIKE :pesquisa 
                   OR modelo.versao LIKE :pesquisa
                ORDER BY modelo.nome, montadora.nome ASC 
                LIMIT :offset, :limit";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':pesquisa', '%' . $pesquisa . '%');
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Busca um modelo pelo ID
    public function buscarPorId($id)
    {
        $sql = "SELECT modelo.*,modelo.nome as nome_modelo, montadora.*,
                       montadora.nome as nome_montadora
                  FROM modelo
                  INNER JOIN montadora ON modelo.montadora_id = montadora.id
                  WHERE modelo.id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Atualiza um modelo usando o objeto DTO
    public function atualizar(ModeloDTO $modelo)
    {
        $sql = "UPDATE modelo 
                SET nome = :nome, versao = :versao, ano = :ano, montadora_id = :montadora_id 
                WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);

        $stmt->bindValue(":nome", $modelo->getnome());
        $stmt->bindValue(":versao", $modelo->getversao());
        $stmt->bindValue(":ano", $modelo->getano());
        $stmt->bindValue(":montadora_id", $modelo->getmontadora_id(), PDO::PARAM_INT);
        $stmt->bindValue(":id", $modelo->getid(), PDO::PARAM_INT);

        return $stmt->execute();
    }

    // Exclui um modelo pelo ID
    public function excluir($id)
    {
        $sql = "DELETE FROM modelo WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}