<?php
require_once "Conexao.php";
require_once __DIR__ . "/../dto/MontadoraDTO.php";

class MontadoraDAO
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }

    // Cadastra uma nova montadora
    public function cadastrar(MontadoraDTO $montadora)
    {
        $sql = "INSERT INTO montadora (nome, pais_origem) 
                VALUES (:nome, :pais_origem)";

        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":nome", $montadora->getnome());
        $stmt->bindValue(":pais_origem", $montadora->getpais_origem());

        $stmt->execute();
        
        // Retorna o ID gerado para a montadora
        return $this->pdo->lastInsertId();
    }

    // Lista todas as montadoras
    public function listar()
    {
        $sql = "SELECT * FROM montadora ORDER BY nome ASC";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Lista montadoras com pesquisa por nome ou país
    public function listarComPesquisa($pesquisa, $offset = 0, $limit = 100)
    {
        $sql = "SELECT * FROM montadora 
                WHERE nome LIKE :pesquisa OR pais_origem LIKE :pesquisa
                ORDER BY nome ASC 
                LIMIT :offset, :limit";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':pesquisa', '%' . $pesquisa . '%');
        $stmt->bindValue(':offset', (int) $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Busca uma montadora pelo ID
    public function buscarPorId($id)
    {
        $sql = "SELECT * FROM montadora WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Atualiza os dados de uma montadora
    public function atualizar(MontadoraDTO $montadora)
    {
        $sql = "UPDATE montadora SET 
                    nome = :nome, 
                    pais_origem = :pais_origem
                WHERE id = :id";

        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":nome", $montadora->getnome());
        $stmt->bindValue(":pais_origem", $montadora->getpais_origem());
        $stmt->bindValue(":id", $montadora->getid(), PDO::PARAM_INT);

        return $stmt->execute();
    }

    // Exclui uma montadora pelo ID
    public function excluir($id)
    {
        $sql = "DELETE FROM montadora WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(":id", $id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}