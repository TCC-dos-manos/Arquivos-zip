// ── ALTERNÂNCIA LOGIN ↔ CADASTRO ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {

    const container = document.getElementById('container');
    const btnIrCadastro = document.getElementById('btn-ir-cadastro');
    const btnIrLogin = document.getElementById('btn-ir-login');
    const ativarContainer = document.querySelector('.ativar-container');

    function expandirCortina() {
        ativarContainer.style.left = '0';
        ativarContainer.style.width = '100%';
        ativarContainer.style.borderRadius = '0';
    }

    if (btnIrCadastro) {
        btnIrCadastro.addEventListener('click', () => {
            expandirCortina();
            setTimeout(() => container.classList.add('ativo'), 650);
            setTimeout(() => {
                ativarContainer.style.width = '50%';
                ativarContainer.style.borderRadius = '0 80px 60px 0';
            }, 950);

            document.getElementById('formLogin').reset();
            const dica = document.getElementById('tipo-detectado');
            if (dica) { dica.textContent = ''; dica.className = 'tipo-hint'; }
            document.getElementById('tipo_documento').value = '';

            // Ao ir para cadastro, reseta o modo visual para marrom (padrão)
            document.body.classList.remove('modo-organizador');
        });
    }

    if (btnIrLogin) {
        btnIrLogin.addEventListener('click', () => {
            expandirCortina();
            setTimeout(() => container.classList.remove('ativo'), 650);
            setTimeout(() => {
                ativarContainer.style.left = '50%';
                ativarContainer.style.width = '50%';
                ativarContainer.style.borderRadius = '80px 0 0 60px';
            }, 950);

            const cpf = document.getElementById('cpf');
            const cnpj = document.getElementById('cnpj');
            if (cpf && cnpj) {
                cpf.disabled = false; cpf.style.opacity = '1';
                cnpj.disabled = false; cnpj.style.opacity = '1';
            }

            document.getElementById('formCadastro').reset();
            document.getElementById('papel_id').value = '';

            // Ao voltar pro login, reseta o modo visual
            document.body.classList.remove('modo-organizador');
        });
    }

});


// ── DETECÇÃO DE TIPO DE DOCUMENTO (campo de login) ────────────────────────
const campoDocumento = document.getElementById('documento');
const campoTipo = document.getElementById('tipo_documento');
const dica = document.getElementById('tipo-detectado');

function aplicarMascara(nums, tipo) {
    if (tipo === 'cpf')
        return nums.replace(/(\d{3})(\d{0,3})(\d{0,3})(\d{0,2})/,
            (_, a, b, c, d) => [a, b, c].filter(Boolean).join('.') + (d ? '-' + d : ''));
    if (tipo === 'cnpj')
        return nums.replace(/(\d{2})(\d{0,3})(\d{0,3})(\d{0,4})(\d{0,2})/,
            (_, a, b, c, d, e) => [a, b, c].filter(Boolean).join('.') + (d ? '/' + d : '') + (e ? '-' + e : ''));
    return nums;
}

if (campoDocumento) {
    campoDocumento.addEventListener('input', function (e) {
        const valor = this.value;
        const nums = valor.replace(/\D/g, '');
        const apagando = e.inputType === 'deleteContentBackward';

        if (/[a-zA-Z]/.test(valor) && !valor.includes('@')) {
            campoTipo.value = ''; dica.textContent = ''; dica.className = 'tipo-hint';
            return;
        }

        if (valor.includes('@')) {
            campoTipo.value = 'email';
            dica.textContent = '✓ E-mail detectado';
            dica.className = 'tipo-hint detectado-email';
            return;
        }

        if (nums.length === 0) {
            campoTipo.value = ''; dica.textContent = ''; dica.className = 'tipo-hint';
            return;
        }

        const tipo = nums.length <= 11 ? 'cpf' : 'cnpj';
        const tipoAtual = campoTipo.value;

        if (!(apagando && tipoAtual === tipo)) {
            this.value = aplicarMascara(nums, tipo);
        }

        if (tipo === 'cpf') {
            campoTipo.value = nums.length === 11 ? 'cpf' : '';
            dica.textContent = nums.length === 11 ? '✓ CPF detectado — Colaborador' : '';
            dica.className = nums.length === 11 ? 'tipo-hint detectado-cpf' : 'tipo-hint';
            // CPF confirmado → tema marrom (Colaborador)
            document.body.classList.remove('modo-organizador');
        } else {
            campoTipo.value = nums.length === 14 ? 'cnpj' : '';
            dica.textContent = nums.length === 14 ? '✓ CNPJ detectado — Organizador' : '';
            dica.className = nums.length === 14 ? 'tipo-hint detectado-cnpj' : 'tipo-hint';
            // CNPJ confirmado → tema azul (Organizador)
            if (nums.length === 14) document.body.classList.add('modo-organizador');
            else document.body.classList.remove('modo-organizador');
        }
    });

    document.getElementById('formLogin').addEventListener('submit', function (e) {
        if (!campoTipo.value) {
            e.preventDefault();
            dica.textContent = '⚠ Informe um e-mail, CPF (11 dígitos) ou CNPJ (14 dígitos) válido.';
            dica.className = 'tipo-hint erro';
            campoDocumento.focus();
        }
    });
}


// ── CPF E CNPJ NO CADASTRO (RN-04) ────────────────────────────────────────
//
// Quando o usuário começa a digitar CPF, o CNPJ é bloqueado e vice-versa.
// Além disso, o modo visual do body muda:
//   CPF preenchido  → modo marrom (Colaborador)
//   CNPJ preenchido → modo azul   (Organizador)
// Isso dá feedback visual imediato de qual tipo de conta está sendo criada.

const campoCpf = document.getElementById('cpf');
const campoCnpj = document.getElementById('cnpj');
const campoPapel = document.getElementById('papel_id');

const PAPEL_COLABORADOR = '3'; // ajuste para o ID real na sua tabela `papel`
const PAPEL_ORGANIZADOR = '2'; // ajuste para o ID real na sua tabela `papel`

if (campoCpf && campoCnpj) {

    campoCpf.addEventListener('input', function () {
        if (this.value.length > 0) {
            campoCnpj.disabled = true;
            campoCnpj.style.opacity = '0.4';
            if (campoPapel) campoPapel.value = PAPEL_COLABORADOR;

            // Modo Colaborador → visual marrom
            document.body.classList.remove('modo-organizador');
        } else {
            campoCnpj.disabled = false;
            campoCnpj.style.opacity = '1';
            if (campoPapel) campoPapel.value = '';
        }
    });

    campoCnpj.addEventListener('input', function () {
        if (this.value.length > 0) {
            campoCpf.disabled = true;
            campoCpf.style.opacity = '0.4';
            if (campoPapel) campoPapel.value = PAPEL_ORGANIZADOR;

            // Modo Organizador → visual azul
            document.body.classList.add('modo-organizador');
        } else {
            campoCpf.disabled = false;
            campoCpf.style.opacity = '1';
            if (campoPapel) campoPapel.value = '';

            // Sem CNPJ preenchido → volta para marrom
            document.body.classList.remove('modo-organizador');
        }
    });
}


// ── CEP VIA VIACEP ────────────────────────────────────────────────────────
const campoCep = document.getElementById('cep_end');

if (campoCep) {
    campoCep.addEventListener('blur', async function () {
        const cep = this.value.replace(/\D/g, '');
        if (cep.length !== 8) return;

        try {
            const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            const data = await res.json();
            if (data.erro) return;

            document.getElementById('logradouro_end').value = data.logradouro || '';
            document.getElementById('bairro_end').value = data.bairro || '';
            document.getElementById('localidade_end').value = data.localidade || '';
            document.getElementById('uf_end').value = data.uf || '';
        } catch (_) {
            // Falha silenciosa — o usuário preenche manualmente
        }
    });
}


// ── VALIDAÇÃO DE SENHAS ───────────────────────────────────────────────────
const campoSenha = document.getElementById('senha_hash');
const campoConfirma = document.getElementById('confirma_senha');
const msgSenha = document.getElementById('msg_senha');

if (campoConfirma && campoSenha) {
    campoConfirma.addEventListener('blur', function () {
        msgSenha.style.display = campoSenha.value !== this.value ? 'block' : 'none';
    });

    document.getElementById('formCadastro').addEventListener('submit', function (e) {
        if (campoSenha.value !== campoConfirma.value) {
            e.preventDefault();
            msgSenha.style.display = 'block';
            campoConfirma.focus();
        }
    });
}