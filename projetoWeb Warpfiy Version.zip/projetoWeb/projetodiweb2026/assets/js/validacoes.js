// Máscara de telefone (formato (99) 99999-9999)
document.addEventListener("DOMContentLoaded", function () {
    const telInput = document.getElementById("telefone");
    if (telInput) {
        telInput.addEventListener("input", function (e) {
            let v = e.target.value.replace(/\D/g, "");
            v = v.replace(/^(\d{2})(\d)/g, "($1) $2");
            v = v.replace(/(\d{5})(\d)/, "$1-$2");
            e.target.value = v.substring(0, 15);
        });
    }

    // Validação de senha em tempo real (blur no campo confirmar senha)
    const senha = document.getElementById("senha");
    const confirma = document.getElementById("confirma_senha");
    const msg = document.getElementById("msg_senha");

    if (confirma) {
        confirma.addEventListener("blur", function () {
            if (senha.value !== confirma.value) {
                msg.style.display = "block";
            } else {
                msg.style.display = "none";
            }
        });
    }

    // Bloqueia envio se senha for inválida
    const form = document.getElementById("formCadastro");
    if (form) {
        form.addEventListener("submit", function (e) {
            if (senha.value !== confirma.value) {
                e.preventDefault();
                alert("As senhas não coincidem. Corrija antes de prosseguir.");
            }
        });
    }
});
