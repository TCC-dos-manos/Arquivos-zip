USE `db_concessionaria_rbac`;
-- =============================================================
-- 1. TABELAS DE DOMÍNIO (TRANSAÇÕES)
-- =============================================================

-- Cliente Leticia conversa com a vendedora Maria e faz uma proposta
  
-- PASSO 1 da transação iniciar venda. Cliente Letícia conversa com a vendedora Maria e faz uma proposta para o carro Mobi 
-- Inicia (Maria [2], Jullios [3], Gol [1])
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (1, 3, 2, 1);
-- Registra o histórico da venda. Status: Em Negociação
INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (1, 1, 'Cliente se interessou pelo Mobi, ficou de conversar com o esposo.'); 

-- PASSO 2, cliente faz proposta, precisa de confirmação com o banco  -- Status: Em Análise de Crédito
INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (2, 1, 'Cliente ofereceu 70% de entrada e o restante financiado pelo banco.'); 

-- PASSO 3, Banco confirma e a venda é concluida com a entrega do veículo  -- Status: Crédito Aprovado
INSERT INTO historico_venda (situacao_id, venda_id, observacao) -- 
VALUES (3, 1, 'Gerente Carlos confirmou com o banco a autorização do financiamento'); 
-- atualiza venda defindo o Carlos como gerente que verificou com o banco a aprovação do financimento
UPDATE venda v SET v.pessoa_id_gerente = 1 WHERE v.id = 1;

-- PASSO 3.1, conclusão da venda com a entrega do veículo 
UPDATE venda v SET 
v.observacao = 'Foi dado 5% de desconto',
v.valor_final = '52250.00',
v.data_venda = CURDATE()
WHERE v.id = 1;
-- registra o ultimo historico -- Status: Concluída
INSERT INTO historico_venda (situacao_id, venda_id, observacao) -- 
VALUES (5, 1, 'Carro entregue');

-- ========== Em paralelo o segundo vendedor faz uma venda a vista ==================  
-- 2. Venda Concluída Jose vende Ferrari ao Alexandre com desconto e aprovação do Carlos(Jose [4, Corolla [2], Alexandre [5] Carlos [1])

