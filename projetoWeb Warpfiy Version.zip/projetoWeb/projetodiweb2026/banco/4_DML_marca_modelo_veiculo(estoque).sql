USE `db_concessionaria_rbac`;

-- 1. MONTADORAS
INSERT INTO montadora (id, nome, pais_origem) VALUES 
(1, 'Fiat', 'Itália'),
(2, 'Volkswagen', 'Alemanha'),
(3, 'Chevrolet', 'EUA'),
(4, 'Toyota', 'Japão'),
(5, 'BMW', 'Alemanha'),
(6, 'Porsche', 'Alemanha'),
(7, 'Ferrari', 'Itália');

-- 2. MODELOS (Carros de passeio: Entrada, Intermediário, Premium e Super Esportivos)
INSERT INTO modelo (id, nome, versao, ano, montadora_id) VALUES 
-- Entrada
(1, 'Mobi', 'Like 1.0', 2023, 1),
(2, 'Polo', 'Track 1.0 MPI', 2024, 2),
(3, 'Onix', 'LTZ 1.0 Turbo', 2025, 3),
-- Intermediários
(4, 'Corolla', 'XEI 2.0', 2023, 4),
(5, 'T-Cross', 'Highline 250 TSI', 2025, 2),
(6, 'Tracker', 'Premier 1.2 Turbo', 2024, 3),
-- Premium
(7, 'Série 3', '320i M Sport', 2025, 5),
(8, 'Macan', 'GTS 2.9 V6', 2024, 6),
-- Super Esportivos (Para a regra do preço oculto)
(9, '911', 'GT3 RS', 2026, 6),
(10, 'F8', 'Tributo 3.9 V8', 2025, 7),
(11, 'M8', 'Competition 4.4 V8', 2024, 5);

-- 3. VEÍCULOS (Estoque Físico) Preços realistas e URLs de imagens públicas
INSERT INTO veiculo (modelo_id, chassi, cor, preco_compra, preco_venda, data_compra, oculta_preco, url_foto) VALUES 

-- --- VEÍCULOS DE ENTRADA ---
(1, '9BD11122233344401', 'Branco', 45000.00, 55000.00, '2025-10-15', 0, 'https://production.autoforce.com/uploads/version/profile_image/9614/comprar-like-1-0_182823d236.png'), 
(2, '9BW22233344455502', 'Prata', 60000.00, 75000.00, '2026-01-20', 0, 'https://www.automaistv.com.br/wp-content/uploads/2022/10/MPI-1_edited.jpg'),
(3, '9BG33344455566603', 'Preto', 75000.00, 92000.00, '2026-02-10', 0, 'https://image1.mobiauto.com.br/images/api/images/v1.0/321597511/transform/fl_progressive,f_webp,q_85,w_959'),
-- --- VEÍCULOS INTERMEDIÁRIOS ---
(4, '9BR44455566677704', 'Cinza', 110000.00, 135000.00, '2025-11-05', 0, 'https://media.toyota.com.br/9c183872-6219-4080-bc0b-f8eb6ca88716.png'),
(5, '9BW55566677788805', 'Azul', 105000.00, 128000.00, '2026-03-01', 0, 'https://production.autoforce.com/uploads/version/profile_image/9697/comprar-highline-250-tsi_3b1e9f1b3f.png'),
(6, '9BG66677788899906', 'Branco', 108000.00, 132000.00, '2025-12-12', 0, 'https://www.chevroletnova.com.br/images/versoes/fotos/2024/03/premier-2024_17111365720.jpg'),
-- --- VEÍCULOS PREMIUM ---
(7, 'WBA77788899900007', 'Preto', 230000.00, 285000.00, '2026-01-15', 0, 'https://m.atcdn.co.uk/vms/media/8f4cf13822f8405a9e16053999ab68a1.jpg'), 
(8, 'WP088899900011108', 'Giz (Crayon)', 390000.00, 480000.00, '2026-02-28', 0, 'https://http2.mlstatic.com/D_NQ_NP_887075-MLB109379935261_032026-O-porsche-macan-gts-29-bi-turbo.webp'), 
-- --- SUPER ESPORTIVOS (OCULTA PREÇO = 1) ---
(9, 'WP099900011122209', 'Laranja', 1800000.00, 2350000.00, '2026-03-10', 1, 'https://s3.ecompletocarros.dev/images/lojas/285/veiculos/100735/veiculoInfoVeiculoImagesMobile/vehicle_image_1652532517_d41d8cd98f00b204e9800998ecf8427e.jpeg'),
(10, 'ZFF00011122233310', 'Vermelho', 2600000.00, 3200000.00, '2025-09-20', 1, 'https://image.webmotors.com.br/_fotos/anunciousados/gigante/2026/202601/20260109/ferrari-f8-tributo-3-9-v8-turbo-gasolina-f1dct-wmimagem17033186236.webp'),
(11, 'WBS11122233344411', 'Azul Marinho', 1100000.00, 1450000.00, '2026-02-05', 1, 'https://miamiimports.com.br/wp-content/uploads/2024/08/WhatsApp-Image-2024-08-14-at-15.39.10-1.jpeg'); -- 