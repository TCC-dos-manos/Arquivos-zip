USE `db_concessionaria_rbac`;

-- =============================================================
-- PREPARAÇÃO: CRIANDO O NOVO CLIENTE (ALEXANDRE)
-- =============================================================
-- Para a venda 2 funcionar, precisamos inserir o Alexandre (ID 5)
INSERT INTO usuario (id, email, senha_hash, ativo) VALUES 
(5, 'alexandre.rico@empresa.com.br', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1);

INSERT INTO pessoa (id, usuario_id, nome_completo, nome_social, cpf, telefone_movel, cep_end, uf_end, localidade_end) VALUES 
(5, 5, 'Alexandre Magno Cliente', 'Alexandre', '33344455566', '5511911112222', '04004-000', 'SP', 'São Paulo');

INSERT INTO usuario_papel (usuario_id, papel_id) VALUES (5, 3);

-- =============================================================
-- CENÁRIO 2: VENDA CONCLUÍDA (SUPER ESPORTIVO / À VISTA COM DESCONTO)
-- José (Vendedor 4) vende a Ferrari F8 (Veículo 10) para Alexandre (Cliente 5).
-- Requer aprovação do Carlos (Gerente 1) para dar desconto alto.
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (2, 5, 4, 10);

-- Início
INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (1, 2, 'Cliente chegou na loja decidido a comprar a Ferrari à vista. Solicitou 10% de desconto.'); 

-- Aprovação Direta
INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (3, 2, 'Gerente Carlos aprovou o desconto máximo de 10% para pagamento em PIX.'); 

-- Fechamento
UPDATE venda SET 
    pessoa_id_gerente = 1,
    observacao = 'Venda à vista. Desconto de 10% aplicado via aprovação gerencial.',
    valor_final = 2880000.00, -- 3.2M menos 10%
    data_venda = '2026-03-25'
WHERE id = 2;

INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (5, 2, 'PIX recebido. Veículo entregue e documentação transferida.');


-- =============================================================
-- CENÁRIO 3: VENDA CANCELADA (CRÉDITO REPROVADO)
-- Maria (Vendedora 2) tenta vender o Tracker (Veículo 6) para Letícia (Cliente 3).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (3, 3, 2, 6);

-- Início
INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (1, 3, 'Cliente Letícia buscou um SUV para a família. Gostou do Tracker. Tentará financiamento 100%.'); 

-- Análise
INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (2, 3, 'Proposta enviada para o banco Santander. Aguardando retorno.'); 

-- Reprovação e Cancelamento
INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (4, 3, 'Banco reprovou o crédito devido a score baixo na data da consulta.'); 

INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (6, 3, 'Venda cancelada. Cliente não possuía valor para dar de entrada.'); 
-- Nota pedagógica: O UPDATE na tabela 'venda' não recebe data_venda nem valor_final pois não foi efetivada.


-- =============================================================
-- CENÁRIO 4: VENDA EM ANDAMENTO (EM NEGOCIAÇÃO)
-- José (Vendedor 4) está negociando o Polo (Veículo 2) com Alexandre (Cliente 5) para a filha dele.
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (4, 5, 4, 2);

INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (1, 4, 'Cliente Alexandre avaliando o Polo Track para o primeiro carro da filha. Ficou de trazer ela para um test-drive amanhã.'); 
-- O processo para aqui. Perfeito para relatórios de "Oportunidades no Funil / Pipeline" ou "Estoque Reservado".


-- =============================================================
-- CENÁRIO 5: VENDA CONCLUÍDA (FINANCIADA COM DESCONTO DO VENDEDOR)
-- Maria (Vendedora 2) vende a BMW Série 3 (Veículo 7) para o Alexandre (Cliente 5).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (5, 5, 2, 7);

INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (1, 5, 'Cliente fez test-drive na Série 3. Maria aplicou sua permissão de 5% de desconto autônomo.'); 

INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (2, 5, 'Financiamento de 50% enviado para a financeira da BMW.'); 

INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (3, 5, 'Crédito aprovado pela financiadora.'); 

UPDATE venda SET 
    pessoa_id_gerente = 1,
    observacao = 'Financiamento 50%. Desconto de vendedor de 5% aplicado.',
    valor_final = 270750.00, -- 285k menos 5%
    data_venda = '2026-04-02'
WHERE id = 5;

INSERT INTO historico_venda (situacao_id, venda_id, observacao) 
VALUES (5, 5, 'Carro lavado, polido e entregue ao cliente.');

USE `db_concessionaria_rbac`;

-- =============================================================
-- CENÁRIO 6: VENDA CONCLUÍDA (DEZEMBRO / 2025)
-- Maria (2) vende o Corolla (Veículo 4) para a Letícia (3).
-- Veículo comprado em Nov/2025, vendido em Dez/2025.
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (6, 3, 2, 4);

-- Forçando as datas no histórico para criar a linha do tempo no passado
INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2025-12-10 10:00:00', 1, 6, 'Cliente buscou um sedan confiável de final de ano.'); 

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2025-12-12 14:30:00', 3, 6, 'Gerente Carlos aprovou pagamento de 50% de entrada e parcelamento.'); 

UPDATE venda SET 
    pessoa_id_gerente = 1,
    observacao = 'Venda de final de ano. Sem desconto aplicado.',
    valor_final = 135000.00,
    data_venda = '2025-12-15'
WHERE id = 6;

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2025-12-15 09:00:00', 5, 6, 'Veículo entregue com laço na concessionária.');


-- =============================================================
-- CENÁRIO 7: VENDA CONCLUÍDA (FEVEREIRO / 2026)
-- José (4) vende o Onix (Veículo 3) para Letícia (3).
-- Veículo comprado em Fev/2026, vendido dias depois.
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (7, 3, 4, 3);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-02-15 11:15:00', 1, 7, 'Cliente gostou do Onix para o filho. Pediu desconto.'); 

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-02-16 16:45:00', 2, 7, 'Aguardando aprovação do consórcio contemplado da cliente.'); 

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-02-18 10:20:00', 3, 7, 'Carta de crédito liberada pelo banco.'); 

UPDATE venda SET 
    observacao = 'Venda via carta de crédito. Desconto do vendedor aplicado.',
    valor_final = 90000.00, -- Preço de tabela 92k
    data_venda = '2026-02-20'
WHERE id = 7;

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-02-20 14:00:00', 5, 7, 'Veículo faturado e liberado para o cliente.');


-- =============================================================
-- CENÁRIO 8: VENDA CANCELADA (MARÇO / 2026)
-- Letícia (3) tenta comprar o Macan (Veículo 8) com José (4).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (8, 3, 4, 8);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-05 09:30:00', 1, 8, 'Cliente deseja fazer um upgrade para um Porsche Macan.'); 

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-06 15:00:00', 2, 8, 'Enviado para análise do banco Itaú com 30% de entrada.'); 

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-08 11:10:00', 4, 8, 'Crédito reprovado. Comprometimento de renda muito alto.'); 

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-09 10:00:00', 6, 8, 'Venda cancelada. O veículo Macan volta a ficar disponível no estoque.');
-- Não faz UPDATE na tabela venda (data_venda e valor_final ficam NULL)


-- =============================================================
-- CENÁRIO 9: EM ANÁLISE DE CRÉDITO (MARÇO / 2026)
-- Alexandre (5) negocia o T-Cross (Veículo 5) com Maria (2).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (9, 5, 2, 5);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-28 14:20:00', 1, 9, 'Alexandre buscando um SUV compacto para a esposa.'); 

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-29 16:00:00', 2, 9, 'Proposta no banco Safra. Aguardando a mesa de crédito responder.'); 
-- Para aqui. Excelente para alunos buscarem "Vendas pendentes de ação do gerente".


-- =============================================================
-- CENÁRIO 10: VENDA CONCLUÍDA (ABRIL / 2026)
-- Alexandre (5) compra o BMW M8 (Veículo 11) com Maria (2).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) 
VALUES (10, 5, 2, 11);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-04-01 10:00:00', 1, 10, 'Cliente se apaixonou pelo M8 azul. Negociação iniciada.'); 

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-04-02 11:30:00', 3, 10, 'Aprovado! Pagamento via TED bancária validada pelo Carlos.'); 

UPDATE venda SET 
    pessoa_id_gerente = 1,
    observacao = 'Venda à vista. Desconto aprovado pela gerência.',
    valor_final = 1400000.00, -- Desconto de 50k sobre 1.45M
    data_venda = '2026-04-04'
WHERE id = 10;

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-04-04 15:45:00', 5, 10, 'Veículo entregue.');

USE `db_concessionaria_rbac`;

-- =============================================================
-- 1. NOVOS USUÁRIOS E PESSOAS (ENRIQUECENDO A BASE)
-- =============================================================

-- Nova Vendedora: Fernanda (ID 6)
INSERT INTO usuario (id, email, senha_hash, ativo) VALUES 
(6, 'fernanda.vend@carta.com.br', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1);
INSERT INTO pessoa (id, usuario_id, nome_completo, nome_social, cpf, telefone_movel, uf_end) VALUES 
(6, 6, 'Fernanda Lima Vendedora', 'Fernanda', '11133355577', '5511988883333', 'SP');
INSERT INTO usuario_papel (usuario_id, papel_id) VALUES (6, 2);

-- Novo Cliente: Roberto (ID 7)
INSERT INTO usuario (id, email, senha_hash, ativo) VALUES 
(7, 'roberto.cli@empresa.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1);
INSERT INTO pessoa (id, usuario_id, nome_completo, nome_social, cpf, uf_end) VALUES 
(7, 7, 'Roberto Gomes Cliente', 'Roberto', '22244466688', 'MG');
INSERT INTO usuario_papel (usuario_id, papel_id) VALUES (7, 3);

-- Nova Cliente: Camila (ID 8)
INSERT INTO usuario (id, email, senha_hash, ativo) VALUES 
(8, 'camila.cli@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1);
INSERT INTO pessoa (id, usuario_id, nome_completo, nome_social, cpf, uf_end) VALUES 
(8, 8, 'Camila Rocha Cliente', 'Camila', '99911133355', 'RJ');
INSERT INTO usuario_papel (usuario_id, papel_id) VALUES (8, 3);


-- =============================================================
-- 2. REPOSIÇÃO DE ESTOQUE (NOVOS VEÍCULOS)
-- =============================================================
INSERT INTO veiculo (id, modelo_id, chassi, cor, preco_compra, preco_venda, data_compra, oculta_preco, url_foto) VALUES
(12, 2, '9BW00000000000012', 'Vermelho', 62000.00, 78000.00, '2025-11-20', 0, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRp2Qz2fX7PFxF1mKW2Za5EZb1eRCnSPK-9LA&s'), -- Polo
(13, 4, '9BR00000000000013', 'Prata', 115000.00, 138000.00, '2026-01-05', 0, 'https://production.autoforce.com/uploads/version/profile_image/7014/comprar-altis-hybrid-premium_5d92e5c681.png'), -- Corolla
(14, 6, '9BG00000000000014', 'Preto', 109000.00, 135000.00, '2026-02-15', 0, 'https://www.sinoscarchevrolet.com.br/content/dam/chevrolet/sa/br/pt/master/home/suvs/tracker/tracker-myr-2026/2-colorizer/premier-at-turbo/chevrolet-tracker-premier-preto-ouro-negro.jpg?imwidth=1920'); -- Tracker

-- =============================================================
-- CENÁRIO 11: VENDA CONCLUÍDA (JANEIRO / 2026) - REVENDA DE CARRO CANCELADO
-- A vendedora Fernanda (6) consegue vender o Tracker (Veículo 6) para o Roberto (7).
-- Lembrete: A venda desse carro havia sido cancelada pela Letícia no cenário 3.
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) VALUES (11, 7, 6, 6);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-01-10 10:00:00', 1, 11, 'Cliente Roberto de MG viu o anúncio do Tracker na internet e veio olhar.');

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-01-11 14:00:00', 3, 11, 'Cliente trouxe carta de consórcio contemplada. Aprovado pelo gerente Carlos.');

UPDATE venda SET 
    pessoa_id_gerente = 1, observacao = 'Venda via consórcio. Desconto aplicado.',
    valor_final = 130000.00, data_venda = '2026-01-15'
WHERE id = 11;

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-01-15 09:30:00', 5, 11, 'Veículo emplacado para MG e entregue ao cliente.');


-- =============================================================
-- CENÁRIO 12: VENDA CANCELADA (FEVEREIRO / 2026) - DESISTÊNCIA
-- A vendedora Fernanda (6) tenta vender o Polo (Veículo 12) para Camila (8).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) VALUES (12, 8, 6, 12);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-02-05 11:00:00', 1, 12, 'Cliente adorou o Polo vermelho.');

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-02-06 16:30:00', 2, 12, 'Ficha aprovada na financeira, aguardando o pagamento da entrada.');

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-02-10 10:00:00', 6, 12, 'Venda cancelada. Cliente teve um imprevisto financeiro e desistiu da compra.');
-- Data de venda e valor final continuam NULL


-- =============================================================
-- CENÁRIO 13: VENDA CONCLUÍDA (MARÇO / 2026) - À VISTA SEM FINANCIAMENTO
-- A vendedora Maria (2) vende o Corolla (Veículo 13) para Camila (8).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) VALUES (13, 8, 2, 13);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-20 09:00:00', 1, 13, 'Após desistir do Polo no mês passado, Camila retornou e decidiu levar o Corolla à vista.');

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-20 11:30:00', 3, 13, 'Pagamento em TED confirmado pelo setor financeiro.');

UPDATE venda SET 
    pessoa_id_gerente = 1, observacao = 'Cliente retornou e comprou veículo superior à vista.',
    valor_final = 138000.00, data_venda = '2026-03-22'
WHERE id = 13;

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-03-22 15:00:00', 5, 13, 'Veículo entregue.');


-- =============================================================
-- CENÁRIO 14: EM ANÁLISE DE CRÉDITO (ABRIL / 2026) - VENDA PRESA
-- José (4) tenta vender o Tracker preto (Veículo 14) para Roberto (7).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) VALUES (14, 7, 4, 14);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-04-05 14:20:00', 1, 14, 'Cliente buscando um segundo Tracker para a empresa.');

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-04-06 10:00:00', 2, 14, 'Processo travado no banco pedindo mais comprovantes de faturamento da empresa.');
-- Status atual: Preso na análise. Excelente para dashboards de "Gargalos".


-- =============================================================
-- CENÁRIO 15: VENDA CONCLUÍDA (ABRIL / 2026) - SUPER ESPORTIVO
-- Fernanda (6) bate a meta vendendo o Porsche 911 (Veículo 9) para o Alexandre (5).
-- =============================================================
INSERT INTO venda (id, pessoa_id_cliente, pessoa_id_vendedor, veiculo_id) VALUES (15, 5, 6, 9);

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-04-05 09:15:00', 1, 15, 'Cliente Alexandre colecionador, demonstrou interesse no 911 GT3 RS.');

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-04-05 16:45:00', 3, 15, 'Transferência internacional validada pela gerência.');

UPDATE venda SET 
    pessoa_id_gerente = 1, observacao = 'Venda internacional validada. Sem desconto.',
    valor_final = 2350000.00, data_venda = '2026-04-06'
WHERE id = 15;

INSERT INTO historico_venda (data_inclusao, situacao_id, venda_id, observacao) 
VALUES ('2026-04-06 11:00:00', 5, 15, 'Veículo retirado via guincho plataforma.');