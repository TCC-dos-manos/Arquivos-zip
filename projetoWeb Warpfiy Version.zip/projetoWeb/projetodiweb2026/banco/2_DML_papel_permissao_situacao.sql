/* DML de IAM, Identificação e Controle de Acesso RBAC */
USE `db_concessionaria_rbac`;

-- 1. Inserir os Papéis (Passando IDs para o Guia de Referência)
INSERT INTO papel (id, nome, descricao) VALUES 
(1, 'Gerente', 'Acesso total, aprova financeiro e gere estoque.'),
(2, 'Vendedor', 'Visualiza estoque e gere suas próprias vendas.'),
(3, 'Cliente', 'Vê preços ocultos e acompanha seus pedidos.'),
(4, 'Suporte', 'Acesso completo para fins de manutenção');

-- 2. Inserir Permissões (Ajustadas para o PHP reconhecer os recursos)
INSERT INTO permissao (id, nome, descricao, recurso, acao) VALUES 
-- Catálogo e Veículos
(1, 'Ver Preços', 'Visualiza preços ocultos', 'veiculo', 'ler_preco'),  -- todos
(2, 'Cadastrar Veículo', 'Adiciona carros ao estoque', 'veiculo', 'criar'), -- gerente
(3, 'Editar Veículo', 'Altera dados e preços dos carros', 'veiculo', 'atualizar'), -- gerente
(4, 'Gerenciar Catálogo', 'CRUD de montadoras e modelos', 'modelo', 'gerenciar'), -- gerente
-- Vendas
(5, 'Iniciar Venda', 'Abre negociação de um veículo', 'venda', 'criar'), -- vendedor
(6, 'Minhas Compras', 'Vê histórico de compras próprias', 'venda', 'ler_proprio_cliente'), -- cliente
(7, 'Minhas Vendas', 'Vê carteira de clientes próprios', 'venda', 'ler_proprio_vendedor'),  -- vendedor
(8, 'Todas as Vendas', 'Vê movimentação da loja inteira', 'venda', 'ler_tudo'), -- gerente
(9, 'Aplicar Desconto 5%', 'Permite dar até 5% de desconto na venda', 'venda', 'aplicar_desconto_5'), -- vendedor
(10, 'Aplicar Desconto 10%', 'Permite dar até 10% de desconto na venda', 'venda', 'aplicar_desconto_10'), -- gerente
(11, 'Aprovar Financiamento', 'Efetiva e libera o carro', 'venda', 'aprovar_financiamento'), -- gerente
(12, 'Cancelar Venda', 'Cancela o processo de compra', 'venda', 'cancelar'), -- vendedor e gerente
-- Pessoas e Perfis
(13, 'Ver Meu Perfil', 'Acessa próprios dados', 'pessoa', 'ler_proprio'), -- todos
(14, 'Editar Meu Perfil', 'Altera próprios dados', 'pessoa', 'atualizar_proprio'),  -- todos
(15, 'Ver Carteira de Clientes', 'Acessa dados de todos os clientes', 'pessoa', 'ler_tudo'), -- gerente
(16, 'Acesso completo', 'para suporte do sistema', '*', '*'); -- suporte

-- 3. Ligar Papéis e Permissões (A Mágica do RBAC)
INSERT INTO papel_permissao (papel_id, permissao_id) VALUES 
-- PERMISSÕES GERAIS (Todos os papéis: 1, 2 e 3)
(1, 1), (2, 1), (3, 1),
(1, 13), (2, 13), (3, 13),
(1, 14), (2, 14), (3, 14),
-- PERMISSÕES EXCLUSIVAS DO GERENTE (papel_id = 1)
(1, 2), (1, 3), (1, 4), (1, 8), (1, 10), (1, 11), (1, 15),
-- PERMISSÕES EXCLUSIVAS DO VENDEDOR (papel_id = 2)
(2, 5), (2, 7), (2, 9),
-- PERMISSÕES COMPARTILHADAS (Gerente e Vendedor)
(1, 12), (2, 12),
-- PERMISSÕES EXCLUSIVAS DO CLIENTE (papel_id = 3)
(3, 6),
-- PERMISSÕES EXCLUSIVAS DO SUPORTE (papel_id = 4)
-- (16) Acesso Completo (*.*)
(4, 16);

-- ==========================================
-- POPULANDO A TABELA DE SITUAÇÕES DA VENDA
-- ==========================================
INSERT INTO situacao (id, nome, descricao) VALUES 
(1, 'Em Negociação', 'Venda iniciada pelo vendedor, definindo valores e descontos.'),
(2, 'Em Análise de Crédito', 'Aguardando gerente receber posição da financeira sobre o crédito.'),
(3, 'Crédito Aprovado', 'Financiamento aprovado, aguardando pagamento da entrada/faturamento.'),
(4, 'Crédito Reprovado', 'Financiamento reprovado, verificar com cliente outra forma de pagamento.'),
(5, 'Concluída', 'Veículo faturado, pago e entregue ao cliente.'),
(6, 'Cancelada', 'Negociação abortada por desistência ou reprovação de crédito.');

