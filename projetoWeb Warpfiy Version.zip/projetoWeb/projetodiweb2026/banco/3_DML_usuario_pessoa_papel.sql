USE `db_concessionaria_rbac`;
-- =============================================================
-- TABELAS DE DOMÍNIO (Dados de Usuarios e Objetos (Estoque) )
-- =============================================================
-- 1. AUTENTICAÇÃO - As senhas devem ser geradas com password_hash no PHP AuthModel, aqui usamos hashes ilustrativos
INSERT INTO usuario (id, email, senha_hash, ativo) VALUES 
(1, 'gerente@carta.com.br', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1), -- senha 123456
(2, 'vendedor@hotmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1),
(3, 'cliente.jf@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1),
(4, 'vendedor.segundo@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1);

-- 2. PESSOAS - ligando pessoa ao usuário (O cadastro detalhado vinculado ao usuário)
INSERT INTO pessoa (id, usuario_id, nome_completo, nome_social, cpf, telefone_movel, cep_end, uf_end, localidade_end) VALUES 
(1, 1, 'Carlos Silva Gerente', 'Carlos', '11122233344', '5511999998888', '01001-000', 'SP', 'São Paulo'),
(2, 2, 'Maria Alves Vendedora', 'Maria', '55566677788', '5511977776666', '02002-000', 'SP', 'São Paulo'),
(3, 3, 'Leticia Correia Cliente', 'Leticia', '99988877766', '5511955554444', '13000-000', 'SP', 'Campinas'),
(4, 4, 'Jose Vendedor Segundo', 'Jose', '45685877766', '5511953254414', '72155-000', 'DF', 'Brasília');

-- 6. AUTORIZAÇÃO - dando papel  (A amarração do RBAC) autorização (data_inicio automática)
INSERT INTO usuario_papel (usuario_id, papel_id) VALUES 
(1, 1), -- Carlos é Gerente 
(2, 2), -- Maria é Vendedora 
(3, 3), -- Leticia é Cliente 
(4, 2); -- Jose também é vendedor