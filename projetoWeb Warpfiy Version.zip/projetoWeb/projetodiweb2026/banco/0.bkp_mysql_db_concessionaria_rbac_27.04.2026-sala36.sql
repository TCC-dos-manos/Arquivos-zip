-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 27/04/2026 às 11:36
-- Versão do servidor: 8.3.0
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
-- -----------------------------------------------------
-- Schema db_concessionaria_rbac
-- -----------------------------------------------------
DROP DATABASE IF EXISTS `db_concessionaria_rbac`;
CREATE SCHEMA IF NOT EXISTS `db_concessionaria_rbac` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ;
USE `db_concessionaria_rbac` ;

--
-- Banco de dados: `db_concessionaria_rbac`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `historico_venda`
--

--
-- Estrutura para tabela `papel`
--

DROP TABLE IF EXISTS `papel`;
CREATE TABLE IF NOT EXISTS `papel` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_papel_nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `papel`
--

INSERT INTO `papel` (`id`, `nome`, `descricao`) VALUES
(1, 'Gerente', 'Acesso total, aprova financeiro e gere estoque.'),
(2, 'Vendedor', 'Visualiza estoque e gere suas próprias vendas.'),
(3, 'Cliente', 'Vê preços ocultos e acompanha seus pedidos.'),
(4, 'Suporte', 'Acesso completo para fins de manutenção');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `senha_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativo` tinyint NOT NULL DEFAULT '1',
  `data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_usuario_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuario`
--

INSERT INTO `usuario` (`id`, `email`, `senha_hash`, `ativo`, `data_criacao`) VALUES
(1, 'gerente@carta.com.br', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1, '2026-04-24 16:23:22'),
(2, 'vendedor@hotmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1, '2026-04-24 16:23:22'),
(3, 'cliente.jf@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1, '2026-04-24 16:23:22'),
(4, 'vendedor.segundo@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1, '2026-04-24 16:23:22'),
(5, 'alexandre.rico@empresa.com.br', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1, '2026-04-24 16:24:22'),
(6, 'fernanda.vend@carta.com.br', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1, '2026-04-24 16:24:22'),
(7, 'roberto.cli@empresa.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1, '2026-04-24 16:24:22'),
(8, 'camila.cli@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1, '2026-04-24 16:24:22'),
(9, 'proeja.ronaldo@gmail.com', '$2y$10$EHp73qEdUrmxok8CdJfCpeVxgKdibz5NrhfseW5qxJmET4v.lWPdq', 1, '2026-04-24 23:39:08'),
(11, 'cliente5@gmail.com', '$2y$10$EHp73qEdUrmxok8CdJfCpeVxgKdibz5NrhfseW5qxJmET4v.lWPdq', 1, '2026-04-24 23:45:15'),
(12, 'cliente6@email.com', '$2y$10$EHp73qEdUrmxok8CdJfCpeVxgKdibz5NrhfseW5qxJmET4v.lWPdq', 1, '2026-04-24 23:52:03'),
(13, 'cliente7@gmail.com', '$2y$10$EHp73qEdUrmxok8CdJfCpeVxgKdibz5NrhfseW5qxJmET4v.lWPdq', 1, '2026-04-25 00:05:14'),
(14, 'cliente9@gmail.com', '$2y$10$EHp73qEdUrmxok8CdJfCpeVxgKdibz5NrhfseW5qxJmET4v.lWPdq', 1, '2026-04-26 00:37:43');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario_papel`
--

DROP TABLE IF EXISTS `usuario_papel`;
CREATE TABLE IF NOT EXISTS `usuario_papel` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id` bigint UNSIGNED NOT NULL,
  `papel_id` bigint UNSIGNED NOT NULL,
  `data_inicio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_fim` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_usu_pap_usuario_id_papel_id` (`usuario_id`,`papel_id`),
  KEY `fk_usuario_papel_usuario_idx` (`usuario_id`),
  KEY `fk_usuario_papel_papel_idx` (`papel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuario_papel`
--

INSERT INTO `usuario_papel` (`id`, `usuario_id`, `papel_id`, `data_inicio`, `data_fim`) VALUES
(1, 1, 1, '2026-04-24 16:23:23', NULL),
(2, 2, 2, '2026-04-24 16:23:23', NULL),
(3, 3, 3, '2026-04-24 16:23:23', NULL),
(4, 4, 2, '2026-04-24 16:23:23', NULL),
(5, 5, 3, '2026-04-24 16:24:22', NULL),
(6, 6, 2, '2026-04-24 16:24:22', NULL),
(7, 7, 3, '2026-04-24 16:24:22', NULL),
(8, 8, 3, '2026-04-24 16:24:22', NULL),
(9, 12, 3, '2026-04-24 23:52:04', NULL),
(10, 13, 3, '2026-04-25 00:05:14', NULL),
(11, 14, 3, '2026-04-26 00:37:43', NULL);

-- --------------------------------------------------------
--
-- Estrutura para tabela `pessoa`
--

DROP TABLE IF EXISTS `pessoa`;
CREATE TABLE IF NOT EXISTS `pessoa` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id` bigint UNSIGNED NOT NULL,
  `nome_completo` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_social` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpf` char(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '11122233344 (Sempre 11 dígitos)',
  `rg` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'MG12345678 ou 123456789',
  `telefone_movel` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '5511988887777 (Com DDI e DDD)',
  `telefone_fixo` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '551144443333',
  `cep_end` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '"cep": "01001-000"',
  `logradouro_end` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '"logradouro": "Praça da Sé"',
  `numero_end` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Manual, (A API Correios não devolve isso)',
  `complemento_end` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '"complemento": "lado ímpar"',
  `bairro_end` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '"bairro": "Zona Sul"',
  `localidade_end` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '"localidade": "São Paulo"',
  `uf_end` char(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pessoa_usuario_idx` (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `pessoa`
--

INSERT INTO `pessoa` (`id`, `usuario_id`, `nome_completo`, `nome_social`, `cpf`, `rg`, `telefone_movel`, `telefone_fixo`, `cep_end`, `logradouro_end`, `numero_end`, `complemento_end`, `bairro_end`, `localidade_end`, `uf_end`) VALUES
(1, 1, 'Carlos Silva Gerente', NULL, '11122233344', NULL, '5511999998888', NULL, '01001-000', NULL, NULL, NULL, NULL, 'São Paulo', 'SP'),
(2, 2, 'Maria Alves Vendedora', NULL, '55566677788', NULL, '5511977776666', NULL, '02002-000', NULL, NULL, NULL, NULL, 'São Paulo', 'SP'),
(3, 3, 'Leticia Correia Cliente', 'João Correia Cliente', '99988877766', NULL, '5511955554444', NULL, '13000-000', NULL, NULL, NULL, NULL, 'Campinas', 'SP'),
(4, 4, 'Jose Vendedor Segundo', 'Antonieta Vendedora Segundo', '45685877766', NULL, '5511953254414', NULL, '72155-000', NULL, NULL, NULL, NULL, 'Brasília', 'DF'),
(5, 5, 'Alexandre Magno Cliente', NULL, '33344455566', NULL, '5511911112222', NULL, '04004-000', NULL, NULL, NULL, NULL, 'São Paulo', 'SP'),
(6, 6, 'Fernanda Lima Vendedora', NULL, '11133355577', NULL, '5511988883333', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'SP'),
(7, 7, 'Roberto Gomes Cliente', NULL, '22244466688', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'MG'),
(8, 8, 'Camila Rocha Cliente', 'Marcus Rocha Cliente', '99911133355', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'RJ'),
(9, 9, 'RONALDO DE AALLA LAU', '', '00554950790', '00554950790', '61994102700', '6133445566', '72.210-010', 'QNM 4 CONJUNTO U', '23', 'CASA', 'CEILÂNDIA NORTE', 'BRASILIA', 'DF'),
(10, 11, 'ZULEICA DE TALL MACHADO', 'ZEQUINHA MACHADO', '61046055755', '61046055755', '61994107711', '6133775560', '72.610-110', 'QNN 14 CONJUNTO A LT 12', '01', 'SALA', 'CEILÂNDIA NORTE', 'BRASILIA', 'DF'),
(11, 12, 'TESTE CLIENTE UM', 'JULIA TESTE CLIENTE UM', '47558586402', '47558586402', '61995602711', '6122334455', '72.600-115', 'SETOR BANCÁRIO SUL, LT 15', '123', '5º ANDAR EDIF ZAFIRA', 'ASA SUL', 'BRASILIA', 'DF'),
(12, 13, 'MARIA SILVA FULA SICRANA', '', '22421745330', '22421745330', '61987676760', '', '73401100', 'AV. CONTORNO BLOCO 1100', '48', 'CASA', 'NÚCLEO BANDEIRANTE', 'BRASILIA', 'DF'),
(13, 14, 'CARLA SILVA FULA SICRANA', '', '75082837087', '75082837087', '61987676760', '6177779999', '73201110', 'QUADRA 05 CJ B', '15', 'AP', 'PLANALTINA', 'BRASILIA', 'DF');

-- --------------------------------------------------------

-- --------------------------------------------------------


--
-- Estrutura para tabela `montadora`
--

DROP TABLE IF EXISTS `montadora`;
CREATE TABLE IF NOT EXISTS `montadora` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pais_origem` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `montadora`
--

INSERT INTO `montadora` (`id`, `nome`, `pais_origem`) VALUES
(1, 'Fiat', 'Itália'),
(2, 'Volkswagen', 'Alemanha'),
(3, 'Chevrolet', 'EUA'),
(4, 'Toyota', 'Japão'),
(5, 'BMW', 'Alemanha'),
(6, 'Porsche', 'Alemanha'),
(7, 'Ferrari', 'Itália');

--
-- Estrutura para tabela `modelo`
--

DROP TABLE IF EXISTS `modelo`;
CREATE TABLE IF NOT EXISTS `modelo` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ex. Ecosport',
  `versao` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ex. XLT',
  `ano` year NOT NULL,
  `montadora_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_modelo_montadora_idx` (`montadora_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `modelo`
--

INSERT INTO `modelo` (`id`, `nome`, `versao`, `ano`, `montadora_id`) VALUES
(1, 'Mobi', 'Like 1.0', '2023', 1),
(2, 'Polo', 'Track 1.0 MPI', '2024', 2),
(3, 'Onix', 'LTZ 1.0 Turbo', '2025', 3),
(4, 'Corolla', 'XEI 2.0', '2023', 4),
(5, 'T-Cross', 'Highline 250 TSI', '2025', 2),
(6, 'Tracker', 'Premier 1.2 Turbo', '2024', 3),
(7, 'Série 3', '320i M Sport', '2025', 5),
(8, 'Macan', 'GTS 2.9 V6', '2024', 6),
(9, '911', 'GT3 RS', '2026', 6),
(10, 'F8', 'Tributo 3.9 V8', '2025', 7),
(11, 'M8', 'Competition 4.4 V8', '2024', 5);

-- --------------------------------------------------------


--
-- Estrutura para tabela `permissao`
--

DROP TABLE IF EXISTS `permissao`;
CREATE TABLE IF NOT EXISTS `permissao` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recurso` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'alvo da permissão, o objeto/entidade que será manipulado, exemplo: pedido, usuario, relatorio_gerencial',
  `acao` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Representa "o que pode ser feito" no recurso, Exemplos:\n criar, \nler\n, atualizar, \ndeletar, \naprovar, \ncancelar\n, exportar',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permissao_nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `permissao`
--

INSERT INTO `permissao` (`id`, `nome`, `descricao`, `recurso`, `acao`) VALUES
(1, 'Ver Preços', 'Visualiza preços ocultos', 'veiculo', 'ler_preco'),
(2, 'Cadastrar Veículo', 'Adiciona carros ao estoque', 'veiculo', 'criar'),
(3, 'Editar Veículo', 'Altera dados e preços dos carros', 'veiculo', 'atualizar'),
(4, 'Gerenciar Catálogo', 'CRUD de montadoras e modelos', 'modelo', 'gerenciar'),
(5, 'Iniciar Venda', 'Abre negociação de um veículo', 'venda', 'criar'),
(6, 'Minhas Compras', 'Vê histórico de compras próprias', 'venda', 'ler_proprio_cliente'),
(7, 'Minhas Vendas', 'Vê carteira de clientes próprios', 'venda', 'ler_proprio_vendedor'),
(8, 'Todas as Vendas', 'Vê movimentação da loja inteira', 'venda', 'ler_tudo'),
(9, 'Aplicar Desconto 5%', 'Permite dar até 5% de desconto na venda', 'venda', 'aplicar_desconto_5'),
(10, 'Aplicar Desconto 10%', 'Permite dar até 10% de desconto na venda', 'venda', 'aplicar_desconto_10'),
(11, 'Aprovar Financiamento', 'Efetiva e libera o carro', 'venda', 'aprovar_financiamento'),
(12, 'Cancelar Venda', 'Cancela o processo de compra', 'venda', 'cancelar'),
(13, 'Ver Meu Perfil', 'Acessa próprios dados', 'pessoa', 'ler_proprio'),
(14, 'Editar Meu Perfil', 'Altera próprios dados', 'pessoa', 'atualizar_proprio'),
(15, 'Ver Carteira de Clientes', 'Acessa dados de todos os clientes', 'pessoa', 'ler_tudo'),
(16, 'Acesso completo', 'para suporte do sistema', '*', '*');

-- --------------------------------------------------------

--
-- Estrutura para tabela `papel_permissao`
--

DROP TABLE IF EXISTS `papel_permissao`;
CREATE TABLE IF NOT EXISTS `papel_permissao` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `papel_id` bigint UNSIGNED NOT NULL,
  `permissao_id` bigint UNSIGNED NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_pap_per_papel_id_permissao_id` (`papel_id`,`permissao_id`),
  KEY `fk_papel_permissao_papel_idx` (`papel_id`),
  KEY `fk_papel_permissao_permissao_idx` (`permissao_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `papel_permissao`
--

INSERT INTO `papel_permissao` (`id`, `papel_id`, `permissao_id`, `data_criacao`) VALUES
(1, 1, 1, '2026-04-24 16:22:59'),
(2, 2, 1, '2026-04-24 16:22:59'),
(3, 3, 1, '2026-04-24 16:22:59'),
(4, 1, 13, '2026-04-24 16:22:59'),
(5, 2, 13, '2026-04-24 16:22:59'),
(6, 3, 13, '2026-04-24 16:22:59'),
(7, 1, 14, '2026-04-24 16:22:59'),
(8, 2, 14, '2026-04-24 16:22:59'),
(9, 3, 14, '2026-04-24 16:22:59'),
(10, 1, 2, '2026-04-24 16:22:59'),
(11, 1, 3, '2026-04-24 16:22:59'),
(12, 1, 4, '2026-04-24 16:22:59'),
(13, 1, 8, '2026-04-24 16:22:59'),
(14, 1, 10, '2026-04-24 16:22:59'),
(15, 1, 11, '2026-04-24 16:22:59'),
(16, 1, 15, '2026-04-24 16:22:59'),
(17, 2, 5, '2026-04-24 16:22:59'),
(18, 2, 7, '2026-04-24 16:22:59'),
(19, 2, 9, '2026-04-24 16:22:59'),
(20, 1, 12, '2026-04-24 16:22:59'),
(21, 2, 12, '2026-04-24 16:22:59'),
(22, 3, 6, '2026-04-24 16:22:59'),
(23, 4, 16, '2026-04-24 16:22:59');

-- --------------------------------------------------------



--
-- Estrutura para tabela `situacao`
--

DROP TABLE IF EXISTS `situacao`;
CREATE TABLE IF NOT EXISTS `situacao` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `situacao`
--

INSERT INTO `situacao` (`id`, `nome`, `descricao`) VALUES
(1, 'Em Negociação', 'Venda iniciada pelo vendedor, definindo valores e descontos.'),
(2, 'Em Análise de Crédito', 'Aguardando gerente receber posição da financeira sobre o crédito.'),
(3, 'Crédito Aprovado', 'Financiamento aprovado, aguardando pagamento da entrada/faturamento.'),
(4, 'Crédito Reprovado', 'Financiamento reprovado, verificar com cliente outra forma de pagamento.'),
(5, 'Concluída', 'Veículo faturado, pago e entregue ao cliente.'),
(6, 'Cancelada', 'Negociação abortada por desistência ou reprovação de crédito.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `veiculo`
--

DROP TABLE IF EXISTS `veiculo`;
CREATE TABLE IF NOT EXISTS `veiculo` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `modelo_id` bigint UNSIGNED NOT NULL,
  `chassi` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cor` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preco_compra` decimal(10,2) NOT NULL,
  `preco_venda` decimal(10,2) DEFAULT NULL,
  `data_compra` date NOT NULL,
  `oculta_preco` tinyint DEFAULT '0',
  `url_foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_veiculo_chassi` (`chassi`),
  KEY `fk_veiculo_modelo_idx` (`modelo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `veiculo`
--

INSERT INTO `veiculo` (`id`, `modelo_id`, `chassi`, `cor`, `preco_compra`, `preco_venda`, `data_compra`, `oculta_preco`, `url_foto`) VALUES
(1, 1, '9BD11122233344401', 'Branco', 45000.00, 55000.00, '2025-10-15', 0, 'https://production.autoforce.com/uploads/version/profile_image/9614/comprar-like-1-0_182823d236.png'),
(2, 2, '9BW22233344455502', 'Prata', 60000.00, 75000.00, '2026-01-20', 0, 'https://www.automaistv.com.br/wp-content/uploads/2022/10/MPI-1_edited.jpg'),
(3, 3, '9BG33344455566603', 'Preto', 75000.00, 92000.00, '2026-02-10', 0, 'https://image1.mobiauto.com.br/images/api/images/v1.0/321597511/transform/fl_progressive,f_webp,q_85,w_959'),
(4, 4, '9BR44455566677704', 'Cinza', 110000.00, 135000.00, '2025-11-05', 0, 'https://media.toyota.com.br/9c183872-6219-4080-bc0b-f8eb6ca88716.png'),
(5, 5, '9BW55566677788805', 'Azul', 105000.00, 128000.00, '2026-03-01', 0, 'https://production.autoforce.com/uploads/version/profile_image/9697/comprar-highline-250-tsi_3b1e9f1b3f.png'),
(6, 6, '9BG66677788899906', 'Branco', 108000.00, 132000.00, '2025-12-12', 0, 'https://www.chevroletnova.com.br/images/versoes/fotos/2024/03/premier-2024_17111365720.jpg'),
(7, 7, 'WBA77788899900007', 'Preto', 230000.00, 285000.00, '2026-01-15', 0, 'https://m.atcdn.co.uk/vms/media/8f4cf13822f8405a9e16053999ab68a1.jpg'),
(8, 8, 'WP088899900011108', 'Giz (Crayon)', 390000.00, 480000.00, '2026-02-28', 0, 'https://http2.mlstatic.com/D_NQ_NP_887075-MLB109379935261_032026-O-porsche-macan-gts-29-bi-turbo.webp'),
(9, 9, 'WP099900011122209', 'Laranja', 1800000.00, 2350000.00, '2026-03-10', 1, 'https://s3.ecompletocarros.dev/images/lojas/285/veiculos/100735/veiculoInfoVeiculoImagesMobile/vehicle_image_1652532517_d41d8cd98f00b204e9800998ecf8427e.jpeg'),
(10, 10, 'ZFF00011122233310', 'Vermelho', 2600000.00, 3200000.00, '2025-09-20', 1, 'https://image.webmotors.com.br/_fotos/anunciousados/gigante/2026/202601/20260109/ferrari-f8-tributo-3-9-v8-turbo-gasolina-f1dct-wmimagem17033186236.webp'),
(11, 11, 'WBS11122233344411', 'Azul Marinho', 1100000.00, 1450000.00, '2026-02-05', 1, 'https://miamiimports.com.br/wp-content/uploads/2024/08/WhatsApp-Image-2024-08-14-at-15.39.10-1.jpeg'),
(12, 2, '9BW00000000000012', 'Vermelho', 62000.00, 78000.00, '2025-11-20', 0, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRp2Qz2fX7PFxF1mKW2Za5EZb1eRCnSPK-9LA&s'),
(13, 4, '9BR00000000000013', 'Prata', 115000.00, 138000.00, '2026-01-05', 0, 'https://production.autoforce.com/uploads/version/profile_image/7014/comprar-altis-hybrid-premium_5d92e5c681.png'),
(14, 6, '9BG00000000000014', 'Preto', 109000.00, 135000.00, '2026-02-15', 0, 'https://www.sinoscarchevrolet.com.br/content/dam/chevrolet/sa/br/pt/master/home/suvs/tracker/tracker-myr-2026/2-colorizer/premier-at-turbo/chevrolet-tracker-premier-preto-ouro-negro.jpg?imwidth=1920');

-- --------------------------------------------------------

--
-- Estrutura para tabela `venda`
--

DROP TABLE IF EXISTS `venda`;
CREATE TABLE IF NOT EXISTS `venda` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `valor_final` decimal(10,2) DEFAULT NULL,
  `data_venda` date DEFAULT NULL,
  `observacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pessoa_id_cliente` bigint UNSIGNED NOT NULL,
  `pessoa_id_vendedor` bigint UNSIGNED NOT NULL,
  `pessoa_id_gerente` bigint UNSIGNED DEFAULT NULL,
  `veiculo_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_venda_veiculo_idx` (`veiculo_id`),
  KEY `fk_venda_pessoa_cliente_idx` (`pessoa_id_cliente`),
  KEY `fk_venda_pessoa_vendedor_idx` (`pessoa_id_vendedor`),
  KEY `fk_venda_pessoa_gerente_idx` (`pessoa_id_gerente`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `venda`
--

INSERT INTO `venda` (`id`, `valor_final`, `data_venda`, `observacao`, `pessoa_id_cliente`, `pessoa_id_vendedor`, `pessoa_id_gerente`, `veiculo_id`) VALUES
(1, 52250.00, '2026-04-24', 'Foi dado 5% de desconto', 3, 2, 1, 1),
(2, 2880000.00, '2026-03-25', 'Venda à vista. Desconto de 10% aplicado via aprovação gerencial.', 5, 4, 1, 10),
(3, NULL, NULL, NULL, 3, 2, NULL, 6),
(4, NULL, NULL, NULL, 5, 4, NULL, 2),
(5, 270750.00, '2026-04-02', 'Financiamento 50%. Desconto de vendedor de 5% aplicado.', 5, 2, 1, 7),
(6, 135000.00, '2025-12-15', 'Venda de final de ano. Sem desconto aplicado.', 3, 2, 1, 4),
(7, 90000.00, '2026-02-20', 'Venda via carta de crédito. Desconto do vendedor aplicado.', 3, 4, NULL, 3),
(8, NULL, NULL, NULL, 3, 4, NULL, 8),
(9, NULL, NULL, NULL, 5, 2, NULL, 5),
(10, 1400000.00, '2026-04-04', 'Venda à vista. Desconto aprovado pela gerência.', 5, 2, 1, 11),
(11, 130000.00, '2026-01-15', 'Venda via consórcio. Desconto aplicado.', 7, 6, 1, 6),
(12, NULL, NULL, NULL, 8, 6, NULL, 12),
(13, 138000.00, '2026-03-22', 'Cliente retornou e comprou veículo superior à vista.', 8, 2, 1, 13),
(14, NULL, NULL, NULL, 7, 4, NULL, 14),
(15, 2350000.00, '2026-04-06', 'Venda internacional validada. Sem desconto.', 5, 6, 1, 9);




DROP TABLE IF EXISTS `historico_venda`;
CREATE TABLE IF NOT EXISTS `historico_venda` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `data_inclusao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `situacao_id` bigint UNSIGNED NOT NULL,
  `venda_id` bigint UNSIGNED NOT NULL,
  `observacao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_historico_venda_situacao_idx` (`situacao_id`),
  KEY `fk_historico_venda_venda_idx` (`venda_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `historico_venda`
--
INSERT INTO `historico_venda` (`id`, `data_inclusao`, `situacao_id`, `venda_id`, `observacao`) VALUES
(1, '2026-04-24 16:23:58', 1, 1, 'Cliente se interessou pelo Mobi, ficou de conversar com o esposo.'),
(2, '2026-04-24 16:23:58', 2, 1, 'Cliente ofereceu 70% de entrada e o restante financiado pelo banco.'),
(3, '2026-04-24 16:23:58', 3, 1, 'Gerente Carlos confirmou com o banco a autorização do financiamento'),
(4, '2026-04-24 16:23:58', 5, 1, 'Carro entregue'),
(5, '2026-04-24 16:24:22', 1, 2, 'Cliente chegou na loja decidido a comprar a Ferrari à vista. Solicitou 10% de desconto.'),
(6, '2026-04-24 16:24:22', 3, 2, 'Gerente Carlos aprovou o desconto máximo de 10% para pagamento em PIX.'),
(7, '2026-04-24 16:24:22', 5, 2, 'PIX recebido. Veículo entregue e documentação transferida.'),
(8, '2026-04-24 16:24:22', 1, 3, 'Cliente Letícia buscou um SUV para a família. Gostou do Tracker. Tentará financiamento 100%.'),
(9, '2026-04-24 16:24:22', 2, 3, 'Proposta enviada para o banco Santander. Aguardando retorno.'),
(10, '2026-04-24 16:24:22', 4, 3, 'Banco reprovou o crédito devido a score baixo na data da consulta.'),
(11, '2026-04-24 16:24:22', 6, 3, 'Venda cancelada. Cliente não possuía valor para dar de entrada.'),
(12, '2026-04-24 16:24:22', 1, 4, 'Cliente Alexandre avaliando o Polo Track para o primeiro carro da filha. Ficou de trazer ela para um test-drive amanhã.'),
(13, '2026-04-24 16:24:22', 1, 5, 'Cliente fez test-drive na Série 3. Maria aplicou sua permissão de 5% de desconto autônomo.'),
(14, '2026-04-24 16:24:22', 2, 5, 'Financiamento de 50% enviado para a financeira da BMW.'),
(15, '2026-04-24 16:24:22', 3, 5, 'Crédito aprovado pela financiadora.'),
(16, '2026-04-24 16:24:22', 5, 5, 'Carro lavado, polido e entregue ao cliente.'),
(17, '2025-12-10 10:00:00', 1, 6, 'Cliente buscou um sedan confiável de final de ano.'),
(18, '2025-12-12 14:30:00', 3, 6, 'Gerente Carlos aprovou pagamento de 50% de entrada e parcelamento.'),
(19, '2025-12-15 09:00:00', 5, 6, 'Veículo entregue com laço na concessionária.'),
(20, '2026-02-15 11:15:00', 1, 7, 'Cliente gostou do Onix para o filho. Pediu desconto.'),
(21, '2026-02-16 16:45:00', 2, 7, 'Aguardando aprovação do consórcio contemplado da cliente.'),
(22, '2026-02-18 10:20:00', 3, 7, 'Carta de crédito liberada pelo banco.'),
(23, '2026-02-20 14:00:00', 5, 7, 'Veículo faturado e liberado para o cliente.'),
(24, '2026-03-05 09:30:00', 1, 8, 'Cliente deseja fazer um upgrade para um Porsche Macan.'),
(25, '2026-03-06 15:00:00', 2, 8, 'Enviado para análise do banco Itaú com 30% de entrada.'),
(26, '2026-03-08 11:10:00', 4, 8, 'Crédito reprovado. Comprometimento de renda muito alto.'),
(27, '2026-03-09 10:00:00', 6, 8, 'Venda cancelada. O veículo Macan volta a ficar disponível no estoque.'),
(28, '2026-03-28 14:20:00', 1, 9, 'Alexandre buscando um SUV compacto para a esposa.'),
(29, '2026-03-29 16:00:00', 2, 9, 'Proposta no banco Safra. Aguardando a mesa de crédito responder.'),
(30, '2026-04-01 10:00:00', 1, 10, 'Cliente se apaixonou pelo M8 azul. Negociação iniciada.'),
(31, '2026-04-02 11:30:00', 3, 10, 'Aprovado! Pagamento via TED bancária validada pelo Carlos.'),
(32, '2026-04-04 15:45:00', 5, 10, 'Veículo entregue.'),
(33, '2026-01-10 10:00:00', 1, 11, 'Cliente Roberto de MG viu o anúncio do Tracker na internet e veio olhar.'),
(34, '2026-01-11 14:00:00', 3, 11, 'Cliente trouxe carta de consórcio contemplada. Aprovado pelo gerente Carlos.'),
(35, '2026-01-15 09:30:00', 5, 11, 'Veículo emplacado para MG e entregue ao cliente.'),
(36, '2026-02-05 11:00:00', 1, 12, 'Cliente adorou o Polo vermelho.'),
(37, '2026-02-06 16:30:00', 2, 12, 'Ficha aprovada na financeira, aguardando o pagamento da entrada.'),
(38, '2026-02-10 10:00:00', 6, 12, 'Venda cancelada. Cliente teve um imprevisto financeiro e desistiu da compra.'),
(39, '2026-03-20 09:00:00', 1, 13, 'Após desistir do Polo no mês passado, Camila retornou e decidiu levar o Corolla à vista.'),
(40, '2026-03-20 11:30:00', 3, 13, 'Pagamento em TED confirmado pelo setor financeiro.'),
(41, '2026-03-22 15:00:00', 5, 13, 'Veículo entregue.'),
(42, '2026-04-05 14:20:00', 1, 14, 'Cliente buscando um segundo Tracker para a empresa.'),
(43, '2026-04-06 10:00:00', 2, 14, 'Processo travado no banco pedindo mais comprovantes de faturamento da empresa.'),
(44, '2026-04-05 09:15:00', 1, 15, 'Cliente Alexandre colecionador, demonstrou interesse no 911 GT3 RS.'),
(45, '2026-04-05 16:45:00', 3, 15, 'Transferência internacional validada pela gerência.'),
(46, '2026-04-06 11:00:00', 5, 15, 'Veículo retirado via guincho plataforma.');


--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `historico_venda`
--
ALTER TABLE `historico_venda`
  ADD CONSTRAINT `fk_historico_venda_situacao` FOREIGN KEY (`situacao_id`) REFERENCES `situacao` (`id`),
  ADD CONSTRAINT `fk_historico_venda_venda` FOREIGN KEY (`venda_id`) REFERENCES `venda` (`id`);

--
-- Restrições para tabelas `modelo`
--
ALTER TABLE `modelo`
  ADD CONSTRAINT `fk_modelo_montadora` FOREIGN KEY (`montadora_id`) REFERENCES `montadora` (`id`);

--
-- Restrições para tabelas `papel_permissao`
--
ALTER TABLE `papel_permissao`
  ADD CONSTRAINT `fk_papel_permissao_papel` FOREIGN KEY (`papel_id`) REFERENCES `papel` (`id`),
  ADD CONSTRAINT `fk_papel_permissao_permissao` FOREIGN KEY (`permissao_id`) REFERENCES `permissao` (`id`);

--
-- Restrições para tabelas `pessoa`
--
ALTER TABLE `pessoa`
  ADD CONSTRAINT `fk_pessoa_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`);

--
-- Restrições para tabelas `usuario_papel`
--
ALTER TABLE `usuario_papel`
  ADD CONSTRAINT `fk_usuario_papel_papel` FOREIGN KEY (`papel_id`) REFERENCES `papel` (`id`),
  ADD CONSTRAINT `fk_usuario_papel_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`);

--
-- Restrições para tabelas `veiculo`
--
ALTER TABLE `veiculo`
  ADD CONSTRAINT `fk_veiculo_modelo` FOREIGN KEY (`modelo_id`) REFERENCES `modelo` (`id`);

--
-- Restrições para tabelas `venda`
--
ALTER TABLE `venda`
  ADD CONSTRAINT `fk_venda_pessoa_cliente` FOREIGN KEY (`pessoa_id_cliente`) REFERENCES `pessoa` (`id`),
  ADD CONSTRAINT `fk_venda_pessoa_gerente` FOREIGN KEY (`pessoa_id_gerente`) REFERENCES `pessoa` (`id`),
  ADD CONSTRAINT `fk_venda_pessoa_vendedor` FOREIGN KEY (`pessoa_id_vendedor`) REFERENCES `pessoa` (`id`),
  ADD CONSTRAINT `fk_venda_veiculo` FOREIGN KEY (`veiculo_id`) REFERENCES `veiculo` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
