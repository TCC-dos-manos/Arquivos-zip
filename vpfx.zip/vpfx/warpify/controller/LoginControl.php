<?php
session_start();
if (!isset($_POST['email'])) {
    header("location: ../index.php");
    exit;
}

//include_once($_SERVER['DOCUMENT_ROOT'] . "/projetodiweb2026/model/dao/Conexao.php");
require_once __DIR__ . "/../model/dao/Conexao.php";

$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

try {
    $pdo = Conexao::getInstance();
    $sql = "SELECT u.*,u.id as id_usuario,
           p.*,p.id as id_pessoa,upapel.*,
           papel.nome as nome_papel,
           upapel.id as id_usuario_papel 
    FROM usuario u 
    INNER JOIN pessoa p ON u.id = p.usuario_id
    INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
    INNER JOIN papel ON upapel.papel_id = papel.id
    WHERE u.email = :email LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(":email", $email);
    $stmt->execute();
    $usuario = $stmt->fetch();
    //var_dump($usuario);
    //exit;
    if ($usuario) {
        if (!$usuario['ativo']) {
            //colocar mensagem de usuário INATIVO no Sistema em JavaScript
            echo "<script>alert('Usuário Inativo! Não pode entrar no sistema.'); </script>";
            header("location: ../index.php");
            exit;
        }

        if (password_verify($senha, $usuario['senha_hash'])) {
            // Inicia a estrutura da sessão
            $_SESSION['usuario'] = [
                'id'     => $usuario['id_pessoa'],
                'id_usuario' => $usuario['id_usuario'],
                'nome'   => empty($usuario['nome_social']) ? $usuario['nome_completo'] : $usuario['nome_social'],
                'email'  => $usuario['email'],
                'papel' => $usuario['nome_papel'],
                'permissoes' => [] // Array vazio que será populado abaixo
            ];

            // 2. AUTORIZAÇÃO (RBAC): Busca as permissões baseadas nos papéis
            $sqlPermissoes = "
                    SELECT per.recurso, per.acao
                    FROM usuario_papel up
                    JOIN papel_permissao pp ON up.papel_id = pp.papel_id
                    JOIN permissao per ON pp.permissao_id = per.id
                    WHERE up.usuario_id = :usuario_id
                ";
            $stmtPerm = $pdo->prepare($sqlPermissoes);
            $stmtPerm->execute(['usuario_id' => $usuario['id_usuario']]);

            $lista_permissoes = $stmtPerm->fetchAll();

            // 3. ESTRUTURAÇÃO: Monta o array hierárquico [recurso][acao]
            foreach ($lista_permissoes as $row) {
                $recurso = $row['recurso'];
                $acao = $row['acao'];

                // Se o recurso ainda não existe no array, cria
                if (!isset($_SESSION['usuario']['permissoes'][$recurso])) {
                    $_SESSION['usuario']['permissoes'][$recurso] = [];
                }

                // Adiciona a ação dentro do recurso
                $_SESSION['usuario']['permissoes'][$recurso][] = $acao;
            }
            //var_dump($_SESSION);
            //exit;
            // Redireciona para página conforme perfil
            
            switch ($_SESSION['usuario']['papel']) {
                case 'Administrador':
                    header("Location: ../view/admin/home_admin.php");
                    break;
                case 'Organizador':
                    header("Location: ../view/organizador/home_organizador.php");
                    break;
                case 'Colaborador':
                    header("Location: ../view/colaborador/home_colaborador.php");
                    break;
                case 'Usuário':
                    header("Location: ../view/cliente/home_cliente.php");
                    break;
                default:
                    header("Location: ../view/suporte/home_suporte.php");
            }
            exit;
        } else {
            echo "<script>alert('Senha incorreta! Verifique'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Usuário ou senha inválidos!'); window.history.back();</script>";
    }
} catch (PDOException $e) {
    die("Erro no login: " . $e->getMessage());
}
