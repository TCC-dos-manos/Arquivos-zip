<?php
session_start();
if (isset($_SESSION["usuario"])) {
    $id_usuario_login = $_SESSION["usuario"]["id"];
} else
    $id_usuario_login = "";

require_once __DIR__ . "/../model/dto/UsuarioDTO.php";
require_once __DIR__ . "/../model/dto/PessoaDTO.php";

require_once __DIR__ . "/../model/dao/UsuarioDAO.php";
require_once __DIR__ . "/../model/dao/PessoaDAO.php";

/*
//var_dump(__DIR__);
var_dump(UsuarioDTO);
exit;
*/


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Captura e limpeza de dados
    $acao = $_POST['acao'];
    $usuario_id      = $id_usuario_login;
    $nome_completo   = trim($_POST["nome_completo"] ?? "");
    $nome_social     = trim($_POST["nome_social"] ?? "");
    $cpf             = trim($_POST["cpf"] ?? "");
    $cnpj              = trim($_POST["cnpj"] ?? "");
    $telefone  = trim($_POST["telefone"] ?? "");

    // Validação básica de campos obrigatórios
    /*if (empty($email)) {
        echo "<script>alert('Por favor, preencha os campos obrigatórios (Nome, CPF).'); window.history.back();</script>";
        exit;
    }*/
    
    try {
        //Trata-se a ação "Cadastrar" do Usuário (Não insere a pessoa).
        if($acao == "cadastrar"){

    // Instancia o DTO e popula com os dados
    $pessoaDTO = new PessoaDTO();
    $pessoaDTO->setusuario_id($usuario_id);
    $pessoaDTO->setnome_completo(htmlspecialchars($nome_completo));
    $pessoaDTO->setnome_social(htmlspecialchars($nome_social));
    $pessoaDTO->setcpf(htmlspecialchars($cpf));
    $pessoaDTO->setcnpj(htmlspecialchars($cnpj));
    $pessoaDTO->settelefone(htmlspecialchars($telefone));


    // Executa a operação no Banco de Dados
    $pessoaDAO = new PessoaDAO();
    $id_pessoa_inserida = $pessoaDAO->cadastrar($pessoaDTO);

    if ($id_pessoa_inserida) {
        $_SESSION['usuario']['id'] = $id_pessoa_inserida;
         echo "<script>alert('Dados do perfil cadastrados com sucesso!'); window.location='../public/index.php';</script>";
        } else {
        echo "<script>alert('Erro ao cadastrar dados do peril!'); window.history.back();</script>";
    }
}
/*elseif($acao == 'alteracao'){

}*/
} catch (PDOException $e) {
    die("Favor contactar o Suporte e informar que ocorreu o seguinte Erro na inclusão do USUÁRIO: " . $e->getMessage());
    echo "<script>window.history.back();</script>";
}
}
