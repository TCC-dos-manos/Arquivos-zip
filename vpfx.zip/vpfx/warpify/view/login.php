<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <a href="../public/index.php">Início</a>
    </header>

    <div class="container">
        <h1>Login</h1>
        <p>Digite suas credenciais para acessar o sistema.</p>

        <form action="../controller/LoginControl.php" method="POST" class="form-card">
            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Senha:</label>
            <input type="password" name="senha" value="123456" required>

            <input type="submit" value="Entrar" class="btn">

            <p style="margin-top: 15px; text-align: center;">
                Não tem conta? <a href="cadastroUsuario.php">Cadastre-se</a>
            </p>
        </form>
    </div>
</body>
</html>
