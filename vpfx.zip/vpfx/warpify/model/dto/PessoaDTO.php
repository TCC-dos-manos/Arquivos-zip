<?php
class PessoaDTO
{
    private $id;
    private $usuario_id;
    private $nome_completo;
    private $nome_social;
    private $cpf;
    private $cnpj;
    private $telefone;

    // --- Getters e Setters Originais ---

    public function getid()
    {
        return $this->id;
    }
    public function setid($id)
    {
        $this->id = $id;
    }

    public function getusuario_id()
    {
        return $this->usuario_id;
    }
    public function setusuario_id($usuario_id)
    {
        $this->usuario_id = $usuario_id;
    }

    public function getnome_completo()
    {
        return $this->nome_completo;
    }
    public function setnome_completo($nome_completo)
    {
        $this->nome_completo = $nome_completo;
    }

    public function getnome_social()
    {
        return $this->nome_social;
    }
    public function setnome_social($nome_social)
    {
        $this->nome_social = $nome_social;
    }

    public function getcpf()
    {
        return $this->cpf;
    }
    public function setcpf($cpf)
    {
        $this->cpf = $cpf;
    }

    public function getcnpj()
    {
        return $this->cnpj;
    }
    public function setcnpj($cnpj)
    {
        $this->cnpj = $cnpj;
    }

    public function gettelefone()
    {
        return $this->telefone_movel;
    }
    public function settelefone($telefone_movel)
    {
        $this->telefone_movel = $telefone_movel;
    }
}
