USE warpify;

-- 1. Inserir os Papéis (Passando IDs para o Guia de Referência)
INSERT INTO papel (id, nome, descricao) VALUES 
(1, 'Administrador', 'Acesso total ao sistema.'),
(2, 'Organizador', 'Controle dos eventos.'),
(3, 'Colaborador', 'Execução do evento.'),
(4, 'Usuário', 'Acesso ao sistema para verificação e comentário de eventos.');

-- select * from papel;

-- 2. Inserir Permissões (Ajustadas para o PHP reconhecer os recursos)
INSERT INTO permissao (id, nome, descricao, recurso, acao) VALUES 
-- Catálogo de Eventos
(1, 'Ver Eventos', 'Visualiza os eventos cadastrados pelo Organizador','evento', 'listar'),  -- todos
(2, 'Cadastrar Eventos', 'Adiciona eventos.', 'evento', 'criar'), -- organizador
(3, 'Editar Evento', 'Altera dados dados dos eventos', 'evento', 'atualizar'), -- organizador
(4, 'Gerenciar Catálogo', 'Gerenciamento dos eventos', 'evento', 'gerenciar'), -- organizador
-- Participantes
(5, 'Incluir participação', 'Inclusão de Colaborador em evento.', 'participante', 'criar'), -- vendedor
(6, 'Minhas Participações', 'Vê histórico de particições', 'participante', 'ler_participacoes'), -- cliente
(7, 'Minhas Avaliações', 'Vê avaliações', 'avaliacao', 'ler_avaliacoes_por_evento'),  -- vendedor
(8, 'Todas as Participações', 'Vê todas as participações em eventos', 'participacao', 'ler_tudo'), -- gerente
(9, 'Cancelar Participação', 'Cancela a participação', 'participacao', 'cancelar'), -- vendedor e gerente
-- Pessoas e Perfis
(10, 'Ver Meu Perfil', 'Acessa próprios dados', 'pessoa', 'ler_proprio'), -- todos
(11, 'Editar Meu Perfil', 'Altera próprios dados', 'pessoa', 'atualizar_proprio'),  -- todos
(12, 'Ver Carteira', 'Acessa dados de todos os clientes', 'pessoa', 'ler_tudo'), -- gerente
(13, 'Acesso completo', 'para suporte do sistema', '*', '*'); -- suporte


-- select * from permissao;


-- 3. Ligar Papéis e Permissões (A Mágica do RBAC)
INSERT INTO papel_permissao (papel_id, permissao_id) VALUES 
-- PERMISSÕES GERAIS (Todos os papéis: 1, 2 e 3)
(1, 1), (2, 1), (3, 1),
(1, 10), (2, 10), (3, 10),
(1, 11), (2, 11), (3, 11),
-- PERMISSÕES EXCLUSIVAS DO GERENTE (papel_id = 1)
(1, 2), (1, 3), (1, 4), (1, 8), (1, 12), (1, 13),
-- PERMISSÕES EXCLUSIVAS DO VENDEDOR (papel_id = 2)
(2, 5), (2, 7), (2, 9),
-- PERMISSÕES COMPARTILHADAS (Gerente e Vendedor)
(1, 12), (2, 12),
-- PERMISSÕES EXCLUSIVAS DO CLIENTE (papel_id = 3)
(3, 6),
-- PERMISSÕES EXCLUSIVAS DO SUPORTE (papel_id = 4)
-- (16) Acesso Completo (*.*)
(4, 13);

-- select * from papel_permissao;



-- 1. AUTENTICAÇÃO - As senhas devem ser geradas com password_hash no PHP AuthModel, aqui usamos hashes ilustrativos
INSERT INTO usuario (id, email, senha_hash, ativo) VALUES 
(1,'admin@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1), -- senha 123456
(2,'organizador@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1),
(3,'colaborado@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1),
(4,'usuario@gmail.com', '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1);


-- select * from usuario;

-- 2. PESSOAS - ligando pessoa ao usuário (O cadastro detalhado vinculado ao usuário)
INSERT INTO pessoa (id, usuario_id, nome_completo, nome_social, cpf, cnpj, telefone) VALUES 
(1, 1, 'Carlos Silva Administrador', 'Carlos', '11122233344', '5511999998888', '5511999998888'),
(2, 2, 'Maria Alves Organizador', 'Maria', '55566677788', '5511977776666', '5511999998888'),
(3, 3, 'Leticia Correia Colaborador', 'Leticia', '99988877766', '5511955554444', '5511999998888'),
(4, 4, 'Jose Usuáro Primeiro', 'Jose', '45685877766', '5511953254414', '5511999998888');


-- select * from pessoa;


-- 6. AUTORIZAÇÃO - dando papel  (A amarração do RBAC) autorização (data_inicio automática)
INSERT INTO usuario_papel (usuario_id, papel_id) VALUES 
(1, 1), -- Carlos é Administrador 
(2, 2), -- Maria é Organizador 
(3, 3), -- Leticia é Colaborador 
(4, 2); -- Usuario 


-- select * from usuario_papel;


