<?php
class PessoaDTO
{
    private $id;
    private $usuario_id;
    private $nome_completo;
    private $nome_social;
    private $cpf;

    private $cnpj;

    private $rg;
    private $telefone_movel;
    private $telefone_fixo;
    private $cep_end;
    private $logradouro_end;
    private $numero_end;
    private $complemento_end;
    private $bairro_end;
    private $localidade_end;
    private $uf_end;

    // --- Getters e Setters Originais ---

    public function getid()
    {
        return $this->id;
    }
    public function setid($id)
    {
        $this->id = $id;
    }

    public function getusuario_id()
    {
        return $this->usuario_id;
    }
    public function setusuario_id($usuario_id)
    {
        $this->usuario_id = $usuario_id;
    }

    public function getnome_completo()
    {
        return $this->nome_completo;
    }
    public function setnome_completo($nome_completo)
    {
        $this->nome_completo = $nome_completo;
    }

    public function getnome_social()
    {
        return $this->nome_social;
    }
    public function setnome_social($nome_social)
    {
        $this->nome_social = $nome_social;
    }

    public function getcpf()
    {
        return $this->cpf;
    }
    public function setcpf($cpf)
    {
        $this->cpf = $cpf;
    }

     public function getcnpj()
    {
        return $this->cnpj;
    }
    public function setcnpj($cnpj)
    {
        $this->cnpj = $cnpj;
    }

    public function getrg()
    {
        return $this->rg;
    }
    public function setrg($rg)
    {
        $this->rg = $rg;
    }

    public function gettelefone_movel()
    {
        return $this->telefone_movel;
    }
    public function settelefone_movel($telefone_movel)
    {
        $this->telefone_movel = $telefone_movel;
    }

    public function gettelefone_fixo()
    {
        return $this->telefone_fixo;
    }
    public function settelefone_fixo($telefone_fixo)
    {
        $this->telefone_fixo = $telefone_fixo;
    }

    public function getcep_end()
    {
        return $this->cep_end;
    }
    public function setcep_end($cep_end)
    {
        $this->cep_end = $cep_end;
    }

    public function getlogradouro_end()
    {
        return $this->logradouro_end;
    }
    public function setlogradouro_end($logradouro_end)
    {
        $this->logradouro_end = $logradouro_end;
    }

    public function getnumero_end()
    {
        return $this->numero_end;
    }
    public function setnumero_end($numero_end)
    {
        $this->numero_end = $numero_end;
    }

    public function getcomplemento_end()
    {
        return $this->complemento_end;
    }
    public function setcomplemento_end($complemento_end)
    {
        $this->complemento_end = $complemento_end;
    }

    public function getbairro_end()
    {
        return $this->bairro_end;
    }
    public function setbairro_end($bairro_end)
    {
        $this->bairro_end = $bairro_end;
    }

    public function getlocalidade_end()
    {
        return $this->localidade_end;
    }
    public function setlocalidade_end($localidade_end)
    {
        $this->localidade_end = $localidade_end;
    }

    public function getuf_end()
    {
        return $this->uf_end;
    }
    public function setuf_end($uf_end)
    {
        $this->uf_end = $uf_end;
    }
}

class CardDTO
{
    private int $id;
    private int $pessoa_id;
    private string $titulo;
    private string $descricao;
    private string $tags;
    private string $status;

    public function getId(): int
    {
        return $this->id;
    }
    public function setId(int $v): void
    {
        $this->id = $v;
    }

    public function getPessoaId(): int
    {
        return $this->pessoa_id;
    }
    public function setPessoaId(int $v): void
    {
        $this->pessoa_id = $v;
    }

    public function getTitulo(): string
    {
        return $this->titulo;
    }
    public function setTitulo(string $v): void
    {
        $this->titulo = $v;
    }

    public function getDescricao(): string
    {
        return $this->descricao;
    }
    public function setDescricao(string $v): void
    {
        $this->descricao = $v;
    }

    public function getTags(): string
    {
        return $this->tags;
    }
    public function setTags(string $v): void
    {
        $this->tags = $v;
    }

    public function getStatus(): string
    {
        return $this->status;
    }
    public function setStatus(string $v): void
    {
        $this->status = $v;
    }
}