<?php
require_once __DIR__ . '/Conexao.php';

class CardDAO
{

    public function listarTodos(): array
    {
        $pdo = Conexao::getInstance();
        $sql = "
            SELECT 
                c.id,
                c.titulo,
                c.descricao,
                c.tags,
                c.status,
                c.data_criacao,
                p.nome_social   AS colaborador_nome,
                p.id            AS colaborador_pessoa_id,
                g.caminho       AS banner_url
            FROM card c
            JOIN pessoa p ON p.id = c.pessoa_id
            LEFT JOIN galeria g 
                ON g.pessoa_id = c.pessoa_id 
                AND g.evento_id IS NULL
            WHERE c.status = 'ativo'
            ORDER BY c.data_criacao DESC
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buscarPorId(int $id): ?array
    {
        $pdo = Conexao::getInstance();
        $sql = "
            SELECT 
                c.id,
                c.titulo,
                c.descricao,
                c.tags,
                c.status,
                p.nome_social   AS colaborador_nome,
                g.caminho       AS banner_url
            FROM card c
            JOIN pessoa p ON p.id = c.pessoa_id
            LEFT JOIN galeria g 
                ON g.pessoa_id = c.pessoa_id 
                AND g.evento_id IS NULL
            WHERE c.id = :id
        ";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $id]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ?: null;
    }
}