-- =============================================================
-- WARPIFY — Script completo do banco de dados
-- Execute este arquivo uma única vez no MySQL Workbench ou
-- via terminal: mysql -u root -p < banco_completo.sql
-- =============================================================

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- 1. CRIA O SCHEMA
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `warpify`;
CREATE SCHEMA IF NOT EXISTS `warpify` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `warpify`;

-- -----------------------------------------------------
-- 2. TABELAS (DDL)
-- -----------------------------------------------------

DROP TABLE IF EXISTS `permissao`;
CREATE TABLE IF NOT EXISTS `permissao` (
  `id`        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome`      VARCHAR(100) NOT NULL,
  `recurso`   VARCHAR(100) NOT NULL,
  `acao`      VARCHAR(100) NOT NULL,
  `descricao` TEXT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `papel`;
CREATE TABLE IF NOT EXISTS `papel` (
  `id`        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome`      VARCHAR(100) NOT NULL,
  `descricao` TEXT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `papel_permissao`;
CREATE TABLE IF NOT EXISTS `papel_permissao` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `permissao_id` BIGINT UNSIGNED NOT NULL,
  `papel_id`     BIGINT UNSIGNED NOT NULL,
  `data_criacao` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `fk_pp_permissao_idx` (`permissao_id` ASC),
  INDEX `fk_pp_papel_idx`     (`papel_id` ASC),
  CONSTRAINT `fk_pp_permissao` FOREIGN KEY (`permissao_id`) REFERENCES `permissao` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_pp_papel`     FOREIGN KEY (`papel_id`)     REFERENCES `papel`     (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email`        VARCHAR(100) NOT NULL,
  `senha_hash`   VARCHAR(255) NOT NULL,
  `ativo`        TINYINT NULL DEFAULT 1,
  `data_criacao` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `usuario_papel`;
CREATE TABLE IF NOT EXISTS `usuario_papel` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id` BIGINT UNSIGNED NOT NULL,
  `papel_id`   BIGINT UNSIGNED NOT NULL,
  `data_inicio` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_fim`   DATETIME NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_up_usuario_idx` (`usuario_id` ASC),
  INDEX `fk_up_papel_idx`   (`papel_id` ASC),
  CONSTRAINT `fk_up_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_up_papel`   FOREIGN KEY (`papel_id`)   REFERENCES `papel`   (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `pessoa`;
CREATE TABLE IF NOT EXISTS `pessoa` (
  `id`               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario_id`       BIGINT UNSIGNED NOT NULL,
  `nome_completo`    VARCHAR(100) NULL,
  `nome_social`      VARCHAR(100) NULL,
  `cpf`              VARCHAR(14)  NULL,
  `cnpj`             VARCHAR(18)  NULL,
  `rg`               VARCHAR(20)  NULL,
  `telefone_movel`   VARCHAR(20)  NULL,
  `telefone_fixo`    VARCHAR(20)  NULL,
  `cep_end`          VARCHAR(10)  NULL,
  `logradouro_end`   VARCHAR(150) NULL,
  `numero_end`       VARCHAR(10)  NULL,
  `complemento_end`  VARCHAR(100) NULL,
  `bairro_end`       VARCHAR(100) NULL,
  `localidade_end`   VARCHAR(100) NULL,
  `uf_end`           VARCHAR(2)   NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_pessoa_usuario_idx` (`usuario_id` ASC),
  CONSTRAINT `fk_pessoa_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `notificacao`;
CREATE TABLE IF NOT EXISTS `notificacao` (
  `id`                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `titulo`                VARCHAR(100) NOT NULL,
  `mensagem`              TEXT NOT NULL,
  `destino`               VARCHAR(100) NOT NULL,
  `data_criacao`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pessoa_id_notificador` BIGINT UNSIGNED NOT NULL,
  `pessoa_id_recebedor`   BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_notif_pessoa1_idx` (`pessoa_id_notificador` ASC),
  INDEX `fk_notif_pessoa2_idx` (`pessoa_id_recebedor` ASC),
  CONSTRAINT `fk_notif_pessoa1` FOREIGN KEY (`pessoa_id_notificador`) REFERENCES `pessoa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_notif_pessoa2` FOREIGN KEY (`pessoa_id_recebedor`)   REFERENCES `pessoa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `evento`;
CREATE TABLE IF NOT EXISTS `evento` (
  `id`                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `pessoa_id`           BIGINT UNSIGNED NOT NULL,
  `categoria`           VARCHAR(100) NOT NULL,
  `titulo`              VARCHAR(100) NOT NULL,
  `descricao`           TEXT NOT NULL,
  `ativo`               TINYINT NOT NULL DEFAULT 1,
  `estado`              VARCHAR(100) NOT NULL,
  `cidade`              VARCHAR(100) NOT NULL,
  `bairro`              VARCHAR(100) NOT NULL,
  `lote`                VARCHAR(100) NOT NULL,
  `cep`                 VARCHAR(10)  NOT NULL,
  `fase_evento`         ENUM('Aberto para Colaboradores','Pronto para divulgação','Concluído','Cancelado') NULL DEFAULT 'Aberto para Colaboradores',
  `situacao_evento`     ENUM('Ativo','Inativo') NULL DEFAULT 'Ativo',
  `qtd_colaboradores`   INT NULL DEFAULT 1,
  `tempo_participacao`  TIME NULL DEFAULT '00:30:00',
  PRIMARY KEY (`id`),
  INDEX `fk_evento_pessoa_idx` (`pessoa_id` ASC),
  CONSTRAINT `fk_evento_pessoa` FOREIGN KEY (`pessoa_id`) REFERENCES `pessoa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `avaliacao`;
CREATE TABLE IF NOT EXISTS `avaliacao` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `pessoa_id`  BIGINT UNSIGNED NOT NULL,
  `evento_id`  BIGINT UNSIGNED NOT NULL,
  `estrela`    INT NOT NULL,
  `avaliacao`  TEXT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_aval_evento_idx` (`evento_id` ASC),
  INDEX `fk_aval_pessoa_idx` (`pessoa_id` ASC),
  CONSTRAINT `fk_aval_evento` FOREIGN KEY (`evento_id`) REFERENCES `evento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_aval_pessoa` FOREIGN KEY (`pessoa_id`) REFERENCES `pessoa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `galeria`;
CREATE TABLE IF NOT EXISTS `galeria` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome`        VARCHAR(100) NOT NULL,
  `caminho`     VARCHAR(100) NOT NULL,
  `data_upload` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pessoa_id`   BIGINT UNSIGNED NOT NULL,
  `evento_id`   BIGINT UNSIGNED NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_galeria_pessoa_idx` (`pessoa_id` ASC),
  INDEX `fk_galeria_evento_idx` (`evento_id` ASC),
  CONSTRAINT `fk_galeria_pessoa` FOREIGN KEY (`pessoa_id`) REFERENCES `pessoa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_galeria_evento` FOREIGN KEY (`evento_id`) REFERENCES `evento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `participante`;
CREATE TABLE IF NOT EXISTS `participante` (
  `id`                     INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ordem_participante`     INT NULL DEFAULT 1,
  `descricao_participante` VARCHAR(100) NULL,
  `situacao_participante`  ENUM('Ativo','Cancelado') NULL DEFAULT 'Ativo',
  `evento_id`              BIGINT UNSIGNED NOT NULL,
  `pessoa_id_colaborador`  BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_part_evento_idx` (`evento_id` ASC),
  INDEX `fk_part_pessoa_idx` (`pessoa_id_colaborador` ASC),
  CONSTRAINT `fk_part_evento` FOREIGN KEY (`evento_id`)             REFERENCES `evento` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_part_pessoa` FOREIGN KEY (`pessoa_id_colaborador`) REFERENCES `pessoa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


DROP TABLE IF EXISTS `card`;
CREATE TABLE IF NOT EXISTS `card` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `pessoa_id`    BIGINT UNSIGNED NOT NULL,
  `titulo`       VARCHAR(200) NOT NULL,
  `descricao`    TEXT NOT NULL,
  `tags`         VARCHAR(300) NULL,
  `status`       ENUM('ativo','encerrado','em breve') NOT NULL DEFAULT 'ativo',
  `data_criacao` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `fk_card_pessoa_idx` (`pessoa_id` ASC),
  CONSTRAINT `fk_card_pessoa` FOREIGN KEY (`pessoa_id`) REFERENCES `pessoa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE = InnoDB;


-- -----------------------------------------------------
-- 3. PAPÉIS (DML)
-- -----------------------------------------------------
INSERT INTO `papel` (id, nome, descricao) VALUES
(1, 'Administrador', 'Acesso total ao sistema.'),
(2, 'Organizador',   'Controle dos eventos.'),
(3, 'Colaborador',   'Execução do evento.'),
(4, 'Usuário',       'Acesso ao sistema para verificação e comentário de eventos.');


-- -----------------------------------------------------
-- 4. PERMISSÕES (DML)
-- -----------------------------------------------------
INSERT INTO `permissao` (id, nome, descricao, recurso, acao) VALUES
(1,  'Ver Eventos',           'Visualiza os eventos cadastrados',          'evento',       'listar'),
(2,  'Cadastrar Eventos',     'Adiciona eventos.',                         'evento',       'criar'),
(3,  'Editar Evento',         'Altera dados dos eventos',                  'evento',       'atualizar'),
(4,  'Gerenciar Catálogo',    'Gerenciamento dos eventos',                 'evento',       'gerenciar'),
(5,  'Incluir participação',  'Inclusão de Colaborador em evento.',        'participante', 'criar'),
(6,  'Minhas Participações',  'Vê histórico de participações',             'participante', 'ler_participacoes'),
(7,  'Minhas Avaliações',     'Vê avaliações',                             'avaliacao',    'ler_avaliacoes_por_evento'),
(8,  'Todas as Participações','Vê todas as participações em eventos',      'participacao', 'ler_tudo'),
(9,  'Cancelar Participação', 'Cancela a participação',                    'participacao', 'cancelar'),
(10, 'Ver Meu Perfil',        'Acessa próprios dados',                     'pessoa',       'ler_proprio'),
(11, 'Editar Meu Perfil',     'Altera próprios dados',                     'pessoa',       'atualizar_proprio'),
(12, 'Ver Carteira',          'Acessa dados de todos os clientes',         'pessoa',       'ler_tudo'),
(13, 'Acesso completo',       'Para suporte do sistema',                   '*',            '*');


-- -----------------------------------------------------
-- 5. PAPÉIS x PERMISSÕES (DML)
-- -----------------------------------------------------
INSERT INTO `papel_permissao` (papel_id, permissao_id) VALUES
-- Todos os papéis: ver eventos, ver e editar próprio perfil
(1, 1),  (2, 1),  (3, 1),  (4, 1),
(1, 10), (2, 10), (3, 10), (4, 10),
(1, 11), (2, 11), (3, 11), (4, 11),
-- Administrador
(1, 2), (1, 3), (1, 4), (1, 8), (1, 12), (1, 13),
-- Organizador
(2, 2), (2, 3), (2, 4), (2, 7), (2, 9),
-- Colaborador
(3, 5), (3, 6), (3, 9),
-- Usuário (cliente) — apenas visualização
(4, 6);


-- -----------------------------------------------------
-- 6. USUÁRIOS DE TESTE (DML)
-- Senha de todos: 123456
-- -----------------------------------------------------
INSERT INTO `usuario` (id, email, senha_hash, ativo) VALUES
(1, 'admin@gmail.com',        '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1),
(2, 'organizador@gmail.com',  '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1),
(3, 'colaborador@gmail.com',  '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1),
(4, 'usuario@gmail.com',      '$2y$10$nL6KX7Tm8ZKwg8WFb.1gweixcCKPbowEuzV1oW21jlZlz/wADcIuy', 1);


-- -----------------------------------------------------
-- 7. PESSOAS (DML)
-- -----------------------------------------------------
INSERT INTO `pessoa` (id, usuario_id, nome_completo, nome_social, cpf, telefone_movel, cep_end, uf_end, localidade_end) VALUES
(1, 1, 'Carlos Silva Administrador', 'Carlos',  '11122233344', '5511999998888', '01001-000', 'SP', 'São Paulo'),
(2, 2, 'Maria Alves Organizador',    'Maria',   '55566677788', '5511977776666', '02002-000', 'SP', 'São Paulo'),
(3, 3, 'Leticia Correia Colaborador','Leticia', '99988877766', '5511955554444', '13000-000', 'SP', 'Campinas'),
(4, 4, 'Jose Usuário Primeiro',      'Jose',    '45685877766', '5511953254414', '72155-000', 'DF', 'Brasília');


-- -----------------------------------------------------
-- 8. VÍNCULOS USUÁRIO x PAPEL (DML)
-- -----------------------------------------------------
INSERT INTO `usuario_papel` (usuario_id, papel_id) VALUES
(1, 1), -- Carlos  → Administrador
(2, 2), -- Maria   → Organizador
(3, 3), -- Leticia → Colaborador
(4, 4); -- Jose    → Usuário


SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET SQL_MODE=@OLD_SQL_MODE;

-- =============================================================
-- FIM DO SCRIPT
-- Logins de teste (todos com senha: 123456):
--   admin@gmail.com        → Administrador
--   organizador@gmail.com  → Organizador
--   colaborador@gmail.com  → Colaborador
--   usuario@gmail.com      → Usuário
-- =============================================================