<?php
session_start();
//print_r($_SESSION["usuario"]);
if (isset($_SESSION["usuario"])) {
    $id_usuario_login = $_SESSION["usuario"]["id"];
    $papel_usuario_login = $_SESSION["usuario"]["papel"];
} else {
    $id_usuario_login = "";
    $papel_usuario_login = "";
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastro de Usuário</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <header>
        <?php
        if (empty($id_usuario_login)) {
            echo '<a href="../view/login.php">Login</a>';
        }
        ?>
        <a href="../public/index.php">Início</a>
    </header>

    <div class="container">
        <h1>Cadastro de Usuário</h1>
        <p>Preencha os dados abaixo para criar sua conta.</p>

        <form id="formCadastro" action="../controller/PessoaControl.php" method="POST" class="form-card">
        <!-- O CAMPO acao será usado no controller para definir o comando CRUD -->
        <input type="hidden" name="acao" value="cadastrar">            

            <!-- campos para o cadastro de usuário -->
            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Senha:</label>
            <input type="password" id="senha_hash" name="senha_hash" required>

            <label>Repita a Senha:</label>
            <input type="password" id="confirma_senha" name="confirma_senha" required>
            <small id="msg_senha" style="color:red; display:none;">As senhas não coincidem.</small>

            <!-- ativo = 1 -> Todo usuário se inclui como ATIVO no sistema -->
            <!-- papel_id = 3 -> Id do papel Cliente -->
            <?php

            if (!(empty($papel_usuario_login)) && ($papel_usuario_login == 'Administrador')) {
                echo '
                    <label>Papel:</label>
                    <select name="perfil">
                        <option value="1">Administrador</option>
                        <option value="2">Organizador</option>
                        <option value="3">Colaborador</option>
                        <option value="4" selected>Usuário</option>
                    </select> ';

                echo '<label>Ativo:</label>
                  <select name="ativo">
                      <option value="1" selected>Sim</option>
                      <option value="0">Não</option>
                  </select> ';
            } else {
                echo '<input type="hidden" name="papel_id" value="4">
                      <input type="hidden" name="ativo" value="1">';
            }
            ?>

            <input type="submit" value="Cadastrar" class="btn">
        </form>
    </div>

    <script src="../assets/js/validacoes.js"></script>
</body>

</html>