<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['papel'] !== 'Organizador') {
    header("Location: ../login-cadastro.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Área do Organizador — Warpfiy</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
</head>
<body>
    <header>
        <nav>
            <span>Bem-vindo, <?= htmlspecialchars($_SESSION['usuario']['nome']) ?> (Organizador)</span>
            <a href="../../controller/LogoutControl.php">Sair</a>
        </nav>
    </header>

    <main>
        <h1>Área do Organizador</h1>
        <p>Aqui você gerencia seus eventos e busca colaboradores.</p>
    </main>
</body>
</html>