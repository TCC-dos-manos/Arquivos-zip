<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['papel'] !== 'Colaborador') {
    header("Location: ../login-cadastro.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Área do Colaborador — Warpfiy</title>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
</head>

<body>
    <header>
        <nav>
            <span>Bem-vindo,
                <?= htmlspecialchars($_SESSION['usuario']['nome']) ?> (Colaborador)
            </span>
            <a href="../../controller/LogoutControl.php">Sair</a>
        </nav>
    </header>

    <main>
        <h1>Área do Colaborador</h1>
        <p>Aqui você gerencia seus cards e participações em eventos.</p>
    </main>
</body>

</html>