<?php
session_start();

// Redireciona se não for um cliente autenticado
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['papel'] !== 'Usuário') {
    header("Location: ../login.php"); // Corrigido o caminho
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Área do Cliente</title>
    <!-- CSS específico para cliente -->
    <link rel="stylesheet" href="../../assets/css/cliente.css"> <!-- Corrigido o caminho -->
</head>
<body>
    <header class="topo">
        <div class="container-header">
            <span class="bem-vindo">
                Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario']['nome']); ?> (Cliente)
            </span>
            <a class="logout" href="cadastroUsuario.php">Perfil</a> <!-- Corrigido o caminho -->
            <a class="logout" href="../../controller/LogoutControl.php">Sair</a> <!-- Corrigido o caminho -->
        </div>
    </header>

    <main class="container">
        <h1>Área do Cliente</h1>
        <p>Aqui você pode visualizar seu perfil, editar seus dados e acessar os serviços disponíveis.</p>
    </main>
</body>
</html>
