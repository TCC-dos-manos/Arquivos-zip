<?php
session_start();

if (isset($_SESSION["usuario"])) {
    $id_usuario_login = $_SESSION["usuario"]["id"];
    $papel_usuario_login = $_SESSION["usuario"]["papel"];
} else {
    $id_usuario_login = "";
    $papel_usuario_login = "";
}

// --- NOVO: busca os cards do banco ---
require_once __DIR__ . '/../model/dao/CardDAO.php';

$cardDAO = new CardDAO();
$cards = $cardDAO->listarTodos();

// Converte a string de tags em array para o JS usar
foreach ($cards as &$card) {
    $card['tags'] = !empty($card['tags'])
        ? array_map('trim', explode(',', $card['tags']))
        : [];
}
unset($card);

$cardsJson = json_encode($cards, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/home/header.css">
    <link rel="stylesheet" href="../assets/css/home/slider.css">
    <link rel="stylesheet" href="../assets/css/home/card-info.css">
    <link rel="stylesheet" href="../assets/css/home/flipcard.css">
    <link rel="stylesheet" href="../assets/css/home/modal.css">
    <link rel="stylesheet" href="../assets/css/home/wave-svg.css">
    <link rel="stylesheet" href="../assets/css/home/event-section.css">
    <link rel="stylesheet" href="../assets/css/home/footer.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css"
        integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Warpfiy</title>
</head>

<body>
    <header>
        <nav id="navbar">
            <i><img class="logo-warpfiy" src="../assets/src/warpfiyLogo.png"></i>

            <ul id="nav-list">
                <li class="nav-item active">
                    <a href="#slider" data-target="slider">Conheça nosso site</a>
                </li>
                <li class="nav-item">
                    <a href="#card-section" data-target="card-section">Cards</a>
                </li>
                <li class="nav-item">
                    <a href="#event-section" data-target="event-section">Eventos</a>
                </li>
                <li class="nav-item">
                    <a href="#suporte" data-target="suporte">Suporte</a>
                </li>
            </ul>

            <div class="nav-btn">
                <button class="btn-login open-generic-modal" data-config="pularTutorial" data-perfil="colaborador">
                    Login
                </button>
                <button class="btn-default open-generic-modal" data-config="pularTutorialCadastro"
                    data-perfil="colaborador">
                    Cadastre-se
                </button>
            </div>

            <button id="mobile-btn">
                <i class="fa-solid fa-bars"></i>
            </button>
        </nav>

        <div id="mobile-menu">
            <ul id="mobile-nav-list">
                <li class="nav-item active">
                    <a href="#slider" data-target="slider">Conheça nosso site</a>
                </li>
                <li class="nav-item">
                    <a href="#card-section" data-target="card-section">Cards</a>
                </li>
                <li class="nav-item">
                    <a href="#event-section" data-target="event-section">Eventos</a>
                </li>
                <li class="nav-item">
                    <a href="#suporte" data-target="suporte">Suporte</a>
                </li>
            </ul>
            <button class="btn-default">Cadastre-se</button>
        </div>
    </header>

    <main id="content">
        <section id="slider">
            <div class="slider-content">
                <div class="slider-container">
                    <div class="img-slider on">
                        <img src="../assets/src/carrossel/warpfiyBanner.png" alt="warpfiy">
                    </div>
                    <div class="img-slider">
                        <img src="../assets/src/carrossel/teste1.png" alt="img-1">
                    </div>
                    <div class="img-slider">
                        <img src="../assets/src/carrossel/teste2.png" alt="img-2">
                    </div>
                </div>

                <div class="setas">
                    <button id="prev-btn"> <i class="fa-solid fa-caret-left"></i> </button>
                    <button id="next-btn"> <i class="fa-solid fa-caret-right"></i> </button>
                </div>

                <div class="btn-nav-box">
                    <div class="btn-nav on"></div>
                    <div class="btn-nav"></div>
                    <div class="btn-nav"></div>
                </div>
            </div>
        </section>

        <div class="wave-divider">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 150" preserveAspectRatio="none">
                <path d="M0,80 C400,150 1000,0 1440,100 L1440,0 L0,0 Z" fill="#411616" />
            </svg>
        </div>

        <!-- ══════════════════════════ SEÇÃO DE CARDS (Colaborador — marrom) ══════════════════════════ -->
        <section id="card-section">
            <div class="title-info-card">
                <h2 class="title">Conheça mais sobre os nossos Cards!</h2>
                <span class="subtitle">Teste clicar sobre cada card para saber mais informações sobre cada um
                    deles!</span>

                <div class="flipcards">
                    <div class="flipcard-container" data-highlight="card-content">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-layer-group"></i></div>
                                <h2>Como Funciona um Card?</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-layer-group back-icon"></i>
                                <h2>Como Funciona um Card?</h2>
                                <p>Os cards são uma forma de os colaboradores divulgarem seus produtos de maneira visual
                                    e atrativa.</p>
                            </div>
                        </div>
                    </div>
                    <div class="flipcard-container" data-highlight="title-card">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-book"></i></div>
                                <h2>Título do Card</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-book"></i>
                                <h2>Título do Card</h2>
                                <p>Descrição do card aqui.</p>
                            </div>
                        </div>
                    </div>
                    <div class="flipcard-container" data-highlight="categoria-artistica">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-hashtag"></i></div>
                                <h2>Tags</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-hashtag"></i>
                                <h2>Tags</h2>
                                <p>Servem para categorizar e organizar os cards de maneira mais eficiente.</p>
                            </div>
                        </div>
                    </div>
                    <div class="flipcard-container" data-highlight="profile-img">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-user"></i></div>
                                <h2>Perfil</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-user"></i>
                                <h2>Perfil</h2>
                                <p>Informações sobre o perfil do colaborador.</p>
                            </div>
                        </div>
                    </div>
                    <div class="flipcard-container" data-highlight="card-img">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-image"></i></div>
                                <h2>Imagem</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-image"></i>
                                <h2>Imagem</h2>
                                <p>Imagem principal do card aqui.</p>
                            </div>
                        </div>
                    </div>
                    <div class="flipcard-container" data-highlight="texto-descricao">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-align-center"></i></div>
                                <h2>Descrição</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-align-center"></i>
                                <h2>Descrição</h2>
                                <p>Descrição simples de como o serviço funciona.</p>
                            </div>
                        </div>
                    </div>
                    <div class="flipcard-container" data-highlight="avalie">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-heart"></i></div>
                                <h2>Avaliação</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-heart"></i>
                                <h2>Avaliação</h2>
                                <p>Onde o Organizador pode avaliar o card.</p>
                            </div>
                        </div>
                    </div>
                    <div class="flipcard-container" data-highlight="saiba-mais">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-ellipsis"></i></div>
                                <h2>Saiba Mais</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-ellipsis"></i>
                                <h2>Saiba Mais</h2>
                                <p>Informações mais detalhadas sobre o card aqui.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="card-info">
                <div class="card-container">
                    <div class="card-content">
                        <div class="card">
                            <div class="top-card">
                                <div class="top-info">
                                    <div class="tag-title">
                                        <h2 class="title-card">Como Funciona um Card?</h2>
                                        <div class="categoria-artistica">
                                            <!--
                                                data-perfil="colaborador" → modal genérico recebe tema marrom
                                                Remova os modais individuais de avaliação/tag/pfp do HTML;
                                                eles são gerados dinamicamente pelo modal.js
                                            -->
                                            <a href="#card-section" class="tag open-generic-modal"
                                                data-config="tagModal" data-perfil="colaborador">#Arte</a>
                                            <a href="#card-section" class="tag open-generic-modal"
                                                data-config="tagModal" data-perfil="colaborador">#Banner</a>
                                        </div>
                                    </div>
                                    <div class="profile-img">
                                        <button class="open-generic-modal" data-config="pfpModal"
                                            data-perfil="colaborador">
                                            <img src="../assets/src/pfp/Netulin.png" alt="pfp" class="user-profile">
                                        </button>
                                        <span class="username">Perk</span>
                                    </div>
                                </div>
                            </div>
                            <div class="meio-card">
                                <div class="card-img">
                                    <div class="img-box on">
                                        <img src="../assets/src/card/banner.png" alt="img">
                                    </div>
                                    <div class="img-box">
                                        <img src="../assets/src/card/banner2.png" alt="img">
                                    </div>
                                    <button class="card-carousel-prev" aria-label="Anterior">
                                        <i class="fa-solid fa-chevron-left"></i>
                                    </button>
                                    <button class="card-carousel-next" aria-label="Próxima">
                                        <i class="fa-solid fa-chevron-right"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="bottom-card">
                                <div class="descricao">
                                    <p class="texto-descricao">
                                        O card funciona como uma forma do Colaborador divulgar seu produto,
                                        ele deve estar disponível apenas para o Organizador.
                                    </p>
                                </div>
                                <div class="card-action">
                                    <div class="avalie">
                                        <div class="bottom-action">
                                            <button class="open-generic-modal" data-config="confirmaAvaliacao"
                                                data-perfil="colaborador">Avalie Aqui</button>
                                        </div>
                                    </div>
                                    <div class="saiba-mais">
                                        <div class="bottom-action">
                                            <button class="open-modal" data-modal="saiba-mais-modal">Saiba Mais</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div class="wave-bottom">
            <svg viewBox="0 0 1440 150" preserveAspectRatio="none">
                <path d="M0,0 C400,150 1000,0 1440,100 L1440,150 L0,150 Z" fill="#c4907e" />
            </svg>
        </div>

        <!-- ══════════════════════════ SEÇÃO DE EVENTOS (Organizador — azul) ══════════════════════════ -->
        <section id="event-section">

            <div id="event-info">
                <div class="event-card-content">
                    <div class="event-banner">
                        <img id="ev-banner" src="../assets/src/card/banner3.png" alt="banner evento">
                        <div class="event-badge" id="ev-badge">
                            <i class="fa-solid fa-circle"></i>
                            <span id="ev-status-text">Ativo</span>
                        </div>
                    </div>

                    <div class="event-top">
                        <div class="event-title-block">
                            <h2 class="event-nome" id="ev-nome"></h2>
                            <div class="event-tags" id="ev-tags"></div>
                        </div>
                        <div class="event-organizer open-generic-modal" data-config="pfpModalOrg"
                            data-perfil="organizador">
                            <img id="ev-org-img" src="" alt="organizador">
                            <span id="ev-org-nome"></span>
                        </div>
                    </div>

                    <div class="event-meta" id="event-meta">
                        <div class="event-meta-item">
                            <i class="fa-solid fa-calendar"></i>
                            <span id="ev-data">—</span>
                        </div>
                        <div class="event-meta-item">
                            <i class="fa-solid fa-location-dot"></i>
                            <span id="ev-local">—</span>
                        </div>
                        <div class="event-meta-item">
                            <i class="fa-solid fa-users"></i>
                            <span id="ev-vagas" class="event-vagas">—</span>
                        </div>
                    </div>

                    <div class="event-descricao">
                        <p class="event-texto" id="ev-descricao">—</p>
                    </div>

                    <div class="event-actions" id="event-actions">
                        <button id="btn-ev-saiba-mais">
                            <i class="fa-solid fa-circle-info" style="margin-right:6px"></i>Saiba Mais
                        </button>
                    </div>
                </div>
            </div>

            <div class="title-info-event">
                <h2 class="title">Conheça como funcionam os Eventos!</h2>
                <span class="subtitle">Clique sobre cada card para saber mais sobre cada parte do evento.</span>

                <div class="flipcards">
                    <div class="flipcard-container flipcard-org" data-highlight="event-nome">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-heading"></i></div>
                                <h2>Nome</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-heading"></i>
                                <h2>Nome do Evento</h2>
                                <p>Título principal que identifica o evento para os colaboradores.</p>
                            </div>
                        </div>
                    </div>

                    <div class="flipcard-container flipcard-org" data-highlight="event-tags">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-hashtag"></i></div>
                                <h2>Tags</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-hashtag"></i>
                                <h2>Tags</h2>
                                <p>Categorizam o evento para facilitar a busca por colaboradores.</p>
                            </div>
                        </div>
                    </div>

                    <div class="flipcard-container flipcard-org" data-highlight="event-organizer">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-user"></i></div>
                                <h2>Organizador</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-user"></i>
                                <h2>Organizador</h2>
                                <p>Perfil de quem criou e gerencia o evento.</p>
                            </div>
                        </div>
                    </div>

                    <div class="flipcard-container flipcard-org" data-highlight="event-banner">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-image"></i></div>
                                <h2>Banner</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-image"></i>
                                <h2>Banner</h2>
                                <p>Imagem principal que representa visualmente o evento.</p>
                            </div>
                        </div>
                    </div>

                    <div class="flipcard-container flipcard-org" data-highlight="event-meta">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-calendar"></i></div>
                                <h2>Data e Local</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-calendar"></i>
                                <h2>Data e Local</h2>
                                <p>Quando e onde o evento acontece — presencial ou online.</p>
                            </div>
                        </div>
                    </div>

                    <div class="flipcard-container flipcard-org" data-highlight="event-texto">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-align-center"></i></div>
                                <h2>Descrição</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-align-center"></i>
                                <h2>Descrição</h2>
                                <p>Resumo do evento com informações para o colaborador.</p>
                            </div>
                        </div>
                    </div>

                    <div class="flipcard-container flipcard-org" data-highlight="event-badge">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-circle"></i></div>
                                <h2>Status</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-circle"></i>
                                <h2>Status</h2>
                                <p>Indica se o evento está ativo, encerrado ou em breve.</p>
                            </div>
                        </div>
                    </div>

                    <div class="flipcard-container flipcard-org" data-highlight="event-actions">
                        <div class="flip">
                            <div class="front-card">
                                <div class="front-icon"><i class="fa-solid fa-hand-pointer"></i></div>
                                <h2>Ações</h2>
                                <span class="front-hint">clique para saber mais</span>
                            </div>
                            <div class="back-card">
                                <i class="fa-solid fa-hand-pointer"></i>
                                <h2>Ações</h2>
                                <p>Botões para saber mais sobre o evento ou demonstrar interesse.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ══════════════════════════ MODAIS ══════════════════════════ -->

        <!--
            MODAL GENÉRICO ÚNICO
            O JS aplica .generic-modal--colab (marrom) ou .generic-modal--org (azul)
            dinamicamente via data-perfil no botão que o abre.
        -->
        <dialog id="generic-modal">
            <div class="modal-overlay">
                <div class="modal-container-generic">
                    <div class="generic-modal-banner">
                        <button id="modal-secundary-btn" class="close-modal" data-modal="generic-modal">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                        <div class="tag-flutuante">
                            <i id="modal-tag-icon" class=""></i> <span id="modal-tag-text"></span>
                        </div>
                        <div class="modal-title">
                            <h2 id="modal-title"></h2>
                            <span id="modal-subtitle"></span>
                        </div>
                    </div>
                    <div class="generic-modal-body">
                        <div class="modal-description">
                            <p id="modal-content"></p>
                        </div>
                        <div class="modal-btns">
                            <button id="modal-primary-btn"></button>
                        </div>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- Modal Perfil Colaborador (previa-modal) — tema CLARO -->
        <dialog id="previa-modal">
            <div class="modal-overlay">
                <div class="colab-modal-container">
                    <div class="colab-modal-banner">
                        <button class="colab-modal-close close-modal" data-modal="previa-modal">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                        <div class="colab-modal-identity">
                            <div class="colab-foto-wrapper">
                                <img id="colab-modal-foto" src="../assets/src/pfp/Netulin.png" alt="foto colaborador"
                                    class="colab-foto">
                                <div class="colab-verified-badge" title="Colaborador Verificado">
                                    <i class="fa-solid fa-check"></i>
                                </div>
                            </div>
                            <div class="colab-identity-info">
                                <h2 id="colab-modal-nome">Perk</h2>
                                <span class="colab-tipo">Colaborador · Profissional Autônomo</span>
                                <div class="colab-status-pill">
                                    <i class="fa-solid fa-circle"></i>
                                    <span>Ativo na plataforma</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="colab-modal-body">
                        <div class="colab-tabs">
                            <button class="colab-tab active" data-tab="colab-tab-perfil">
                                <i class="fa-solid fa-user"></i> Perfil
                            </button>
                            <button class="colab-tab" data-tab="colab-tab-cards">
                                <i class="fa-solid fa-id-card"></i> Cards
                            </button>
                            <button class="colab-tab" data-tab="colab-tab-mensagem">
                                <i class="fa-solid fa-message"></i> Mensagem
                            </button>
                        </div>

                        <div class="colab-tab-content active" id="colab-tab-perfil">
                            <div class="colab-grid">
                                <div class="colab-sidebar">
                                    <div class="colab-info-card">
                                        <h3><i class="fa-solid fa-circle-info"></i> Sobre o Profissional</h3>
                                        <div class="colab-info-row">
                                            <span class="colab-info-label">Especialidade</span>
                                            <span class="colab-info-value" id="colab-modal-especialidade">Artes
                                                Digitais</span>
                                        </div>
                                        <div class="colab-info-row">
                                            <span class="colab-info-label">Horário</span>
                                            <span class="colab-info-value" id="colab-modal-horario">09h – 18h</span>
                                        </div>
                                        <div class="colab-info-row">
                                            <span class="colab-info-label">Dias</span>
                                            <span class="colab-info-value" id="colab-modal-dias">Seg – Sex</span>
                                        </div>
                                        <div class="colab-info-row">
                                            <span class="colab-info-label">Localização</span>
                                            <span class="colab-info-value" id="colab-modal-local">Remoto /
                                                Brasília</span>
                                        </div>
                                    </div>
                                    <div class="colab-social-card">
                                        <h3><i class="fa-solid fa-share-nodes"></i> Redes Sociais</h3>
                                        <div class="colab-socials">
                                            <a id="colab-social-instagram" href="https://www.instagram.com/aliz.s2/"
                                                target="_blank" class="colab-social-btn">
                                                <i class="fa-brands fa-instagram"></i>
                                            </a>
                                            <a id="colab-social-maps" href="#" target="_blank" class="colab-social-btn">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="colab-stats-card">
                                        <div class="colab-stat">
                                            <span class="colab-stat-num" id="colab-stat-cards">3</span>
                                            <span class="colab-stat-label">Cards</span>
                                        </div>
                                        <div class="colab-stat-divider"></div>
                                        <div class="colab-stat">
                                            <span class="colab-stat-num" id="colab-stat-avaliacoes">12</span>
                                            <span class="colab-stat-label">Avaliações</span>
                                        </div>
                                        <div class="colab-stat-divider"></div>
                                        <div class="colab-stat">
                                            <span class="colab-stat-num" id="colab-stat-nota">4.8</span>
                                            <span class="colab-stat-label">Nota Média</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="colab-main">
                                    <div class="colab-descricao-card">
                                        <h3><i class="fa-solid fa-quote-left"></i> Sobre</h3>
                                        <p id="colab-modal-descricao">Profissional criativo especializado em design de
                                            banners, identidades visuais e artes digitais para eventos.</p>
                                    </div>
                                    <div class="colab-galeria-card">
                                        <h3><i class="fa-solid fa-images"></i> Portfólio</h3>
                                        <div class="colab-gallery-grid" id="colab-modal-galeria">
                                            <img src="../assets/src/card/banner.png" alt="portfolio 1">
                                            <img src="../assets/src/card/banner2.png" alt="portfolio 2">
                                            <img src="../assets/src/carrossel/teste1.png" alt="portfolio 3">
                                            <img src="../assets/src/carrossel/teste2.png" alt="portfolio 4">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="colab-tab-content" id="colab-tab-cards">
                            <div class="colab-cards-list" id="colab-cards-list">
                                <div class="colab-card-item">
                                    <img src="../assets/src/card/banner.png" alt="card" class="colab-card-thumb">
                                    <div class="colab-card-info">
                                        <p class="colab-card-nome">Design de Banner para Eventos</p>
                                        <div class="colab-card-meta">
                                            <span><i class="fa-solid fa-hashtag"></i> Arte</span>
                                            <span><i class="fa-solid fa-hashtag"></i> Banner</span>
                                        </div>
                                    </div>
                                    <div class="colab-card-badge ativo">Ativo</div>
                                </div>
                                <div class="colab-card-item">
                                    <img src="../assets/src/card/banner2.png" alt="card" class="colab-card-thumb">
                                    <div class="colab-card-info">
                                        <p class="colab-card-nome">Identidade Visual Completa</p>
                                        <div class="colab-card-meta">
                                            <span><i class="fa-solid fa-hashtag"></i> Branding</span>
                                        </div>
                                    </div>
                                    <div class="colab-card-badge ativo">Ativo</div>
                                </div>
                            </div>
                        </div>

                        <div class="colab-tab-content" id="colab-tab-mensagem">
                            <div class="colab-mensagem-box">
                                <div class="colab-mensagem-header">
                                    <i class="fa-solid fa-paper-plane"></i>
                                    <h3>Envie uma Mensagem</h3>
                                    <p>Entre em contato diretamente com o colaborador.</p>
                                </div>
                                <textarea id="colab-mensagem-textarea" maxlength="500"
                                    placeholder="Ex: Boa tarde! Gostaria de um Banner..."></textarea>
                                <span class="colab-char-count" id="colab-mensagem-count">0 / 500</span>
                                <div class="colab-mensagem-btns">
                                    <button class="colab-btn-enviar" id="colab-btn-enviar-mensagem">
                                        <i class="fa-solid fa-paper-plane"></i> Enviar Mensagem
                                    </button>
                                    <button class="colab-btn-cancelar close-modal"
                                        data-modal="previa-modal">Fechar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- ══════════ MODAL SAIBA MAIS — CARD (Colaborador / marrom / ESCURO) ══════════ -->
        <dialog id="saiba-mais-modal">
            <div class="modal-overlay">
                <div class="saiba-mais-container">
                    <div class="saiba-mais-header-banner">
                        <button class="saiba-mais-close-btn close-modal" data-modal="saiba-mais-modal">
                            <i class="fa-solid fa-xmark"></i>
                        </button>

                        <div class="saiba-mais-identity open-generic-modal" data-config="pfpModal"
                            data-perfil="colaborador">
                            <div class="saiba-mais-foto-wrapper">
                                <img src="../assets/src/pfp/Netulin.png" alt="pfp" class="saiba-mais-foto">
                                <div class="saiba-mais-verified" title="Colaborador Verificado">
                                    <i class="fa-solid fa-check"></i>
                                </div>
                            </div>
                            <div class="saiba-mais-identity-info">
                                <h2>Perk</h2>
                                <span class="saiba-mais-tipo">Colaborador · Profissional Autônomo</span>
                                <div class="saiba-mais-status-pill">
                                    <i class="fa-solid fa-circle"></i>
                                    <span>Ativo na plataforma · Clique para ver perfil</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="saiba-mais-body-new">
                        <div class="saiba-mais-grid">
                            <div class="saiba-mais-sidebar">
                                <div class="saiba-mais-info-card">
                                    <h3><i class="fa-solid fa-star"></i> Avaliação</h3>
                                    <div class="saiba-mais-rating-block">
                                        <div class="saiba-mais-rating-num">
                                            <span id="saiba-mais-rating-numero">—</span>
                                        </div>
                                        <div class="saiba-mais-stars-wrap">
                                            <span class="saiba-mais-stars-label">Nota Média</span>
                                            <div id="saiba-mais-stars">
                                                <i class="fa-regular fa-star" data-star="1"></i>
                                                <i class="fa-regular fa-star" data-star="2"></i>
                                                <i class="fa-regular fa-star" data-star="3"></i>
                                                <i class="fa-regular fa-star" data-star="4"></i>
                                                <i class="fa-regular fa-star" data-star="5"></i>
                                            </div>
                                            <div id="saiba-mais-rating-text">Sem avaliações</div>
                                        </div>
                                    </div>

                                    <h3 style="margin-top:4px"><i class="fa-solid fa-circle-info"></i> Sobre o
                                        Colaborador</h3>
                                    <div class="saiba-mais-row">
                                        <span class="saiba-mais-row-label">Nome</span>
                                        <span class="saiba-mais-row-value">Perk</span>
                                    </div>
                                    <div class="saiba-mais-row">
                                        <span class="saiba-mais-row-label">Especialidade</span>
                                        <span class="saiba-mais-row-value">Artes Digitais</span>
                                    </div>
                                    <div class="saiba-mais-row">
                                        <span class="saiba-mais-row-label">Horário</span>
                                        <span class="saiba-mais-row-value">09h – 18h</span>
                                    </div>
                                    <div class="saiba-mais-row">
                                        <span class="saiba-mais-row-label">Dias</span>
                                        <span class="saiba-mais-row-value">Seg – Sex</span>
                                    </div>
                                    <div class="saiba-mais-row">
                                        <span class="saiba-mais-row-label">Local</span>
                                        <span class="saiba-mais-row-value">Remoto / Brasília</span>
                                    </div>
                                </div>

                                <button id="meInteresseiBtnModal" class="saiba-mais-btn-interesse open-generic-modal"
                                    data-config="meInteressei" data-perfil="colaborador">
                                    <i class="fa-solid fa-heart"></i> Me Interessei
                                </button>
                            </div>

                            <div class="saiba-mais-main">
                                <div class="saiba-mais-detail-card">
                                    <h2>Como Funciona um Card? — Detalhes</h2>
                                    <p>Este serviço oferece uma experiência completa em design artístico para banners e
                                        identidades visuais. O colaborador Perk é reconhecido pela agilidade e qualidade
                                        técnica nas entregas.</p>
                                </div>

                                <div class="saiba-mais-gallery-card">
                                    <p class="saiba-mais-section-title">
                                        <i class="fa-solid fa-images"></i> Galeria de Projetos
                                    </p>
                                    <div class="saiba-mais-gallery-grid gallery-grid">
                                        <div class="gallery-item"><img src="../assets/src/card/banner.png" alt="p1">
                                        </div>
                                        <div class="gallery-item"><img src="../assets/src/card/banner2.png" alt="p2">
                                        </div>
                                        <div class="gallery-item"><img src="../assets/src/carrossel/teste1.png"
                                                alt="p3"></div>
                                        <div class="gallery-item"><img src="../assets/src/carrossel/teste2.png"
                                                alt="p4"></div>
                                    </div>
                                </div>

                                <div class="saiba-mais-comments-card" id="modalCommentsList">
                                    <p class="saiba-mais-section-title">
                                        <i class="fa-solid fa-comments"></i> Comentários da Comunidade
                                    </p>
                                    <div class="saiba-mais-comment-item">
                                        <div class="saiba-mais-comment-user">@Organizador_Alpha</div>
                                        <p>Trabalho impecável! O banner ficou exatamente como eu queria para o meu
                                            evento.</p>
                                    </div>

                                    <div id="userCommentSection">
                                        <div class="saiba-mais-comment-item">
                                            <div class="saiba-mais-comment-header">
                                                <div class="saiba-mais-comment-user">@Você</div>
                                                <div class="saiba-mais-comment-rating" id="user-comment-rating">
                                                    <i class="fa-solid fa-star"></i>
                                                    <span id="user-comment-nota">0</span>/5
                                                </div>
                                                <button id="editCommentBtn" class="btn-edit-comment open-generic-modal"
                                                    title="Solicitar edição ao ADM" data-config="editarMensagem"
                                                    data-perfil="colaborador">
                                                    ✏️ Editar
                                                </button>
                                            </div>
                                            <p id="userCommentText"></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- Modal Avaliar -->
        <dialog id="avaliar-modal">
            <div class="avaliar-container">
                <div class="avaliar-header-banner">
                    <button class="avaliar-close close-modal" data-modal="avaliar-modal" id="fecharAvaliarModal">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                    <h2>Avaliar Colaborador</h2>
                    <span>Deixe sua nota e um comentário sobre o serviço.</span>
                </div>
                <div class="avaliar-body">
                    <div class="avaliar-stars-block">
                        <span class="avaliar-stars-label">Sua Nota</span>
                        <div class="avaliar-stars" id="modal-stars">
                            <i class="fa-regular fa-star modal-star" data-star="1"></i>
                            <i class="fa-regular fa-star modal-star" data-star="2"></i>
                            <i class="fa-regular fa-star modal-star" data-star="3"></i>
                            <i class="fa-regular fa-star modal-star" data-star="4"></i>
                            <i class="fa-regular fa-star modal-star" data-star="5"></i>
                        </div>
                        <span class="avaliar-nota-texto" id="avaliar-nota-texto"></span>
                    </div>
                    <div class="avaliar-divider"></div>
                    <div class="avaliar-textarea-block">
                        <label for="avaliar-textarea">Comentário</label>
                        <textarea id="avaliar-textarea" maxlength="300"
                            placeholder="O que você achou do serviço? Seja honesto!"></textarea>
                        <span class="avaliar-char-count" id="avaliar-char-count">0 / 300</span>
                    </div>
                    <div class="avaliar-btns">
                        <button class="avaliar-btn-confirmar" id="confirmar-avaliacao">
                            <i class="fa-solid fa-check" style="margin-right:6px"></i> Confirmar Avaliação
                        </button>
                        <button class="avaliar-btn-cancelar close-modal" data-modal="avaliar-modal"
                            id="cancelarAvaliacaoBtn">
                            Cancelar
                        </button>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- Modal Editar Comentário -->
        <dialog id="solicitacao-editar">
            <div class="editar-container">
                <div class="editar-header-banner">
                    <button class="editar-close close-modal" data-modal="solicitacao-editar" id="fecharEditarModal">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                    <h2>Envie sua Solicitação de Edição</h2>
                    <span>Escreva o motivo da edição para que o administrador analise.</span>
                </div>
                <div class="editar-body">
                    <div class="editar-textarea-block">
                        <label for="editar-textarea">Apelo</label>
                        <textarea id="editar-textarea" maxlength="300"
                            placeholder="Por que deseja editar o comentário?"></textarea>
                        <span class="editar-char-count" id="editar-char-count">0 / 300</span>
                    </div>
                    <div class="editar-btns">
                        <button class="editar-btn-confirmar" id="confirmar-editar">
                            <i class="fa-solid fa-check" style="margin-right:6px"></i> Confirmar Pedido
                        </button>
                        <button class="editar-btn-cancelar close-modal" data-modal="solicitacao-editar"
                            id="cancelarEditarBtn">
                            Cancelar
                        </button>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- Modal Me Interessei (Card) -->
        <dialog id="me-interessei">
            <div class="interesse-container">
                <div class="interesse-header-banner">
                    <button class="interesse-close close-modal" data-modal="me-interessei" id="fecharinteresseModal">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                    <h2>Mostre seu Interesse!</h2>
                    <span>Escreva algo objetivo, ex: Boa tarde! Gostaria de um Banner com as seguintes
                        especificações...</span>
                </div>
                <div class="interesse-body">
                    <div class="interesse-textarea-block">
                        <label for="interesse-textarea">Mensagem</label>
                        <textarea id="interesse-textarea" maxlength="500"
                            placeholder="Seja claro com seu pedido, ele só pode ser enviado uma única vez!"></textarea>
                        <span class="interesse-char-count" id="interesse-char-count">0 / 500</span>
                    </div>
                    <div class="interesse-btns">
                        <button class="interesse-btn-confirmar" id="confirmar-interesse">
                            <i class="fa-solid fa-check" style="margin-right:6px"></i> Enviar Mensagem
                        </button>
                        <button class="interesse-btn-cancelar close-modal" data-modal="me-interessei"
                            id="cancelarinteresseBtn">
                            Mudei de Ideia
                        </button>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- ══════════ MODAL SAIBA MAIS — EVENTO (Organizador / azul / ESCURO) ══════════ -->
        <dialog id="evento-saiba-mais-modal">
            <div class="modal-overlay">
                <div class="evento-saiba-mais-container">
                    <div class="evento-saiba-mais-header">
                        <button class="evento-saiba-mais-close close-modal" data-modal="evento-saiba-mais-modal">
                            <i class="fa-solid fa-xmark"></i>
                        </button>

                        <div class="evento-org-identity open-generic-modal" data-config="pfpModalOrg"
                            data-perfil="organizador">
                            <div class="evento-org-foto-wrapper">
                                <img id="ev-modal-org-img" src="" alt="organizador" class="evento-org-logo">
                                <div class="evento-org-verified" title="Organizador Verificado">
                                    <i class="fa-solid fa-check"></i>
                                </div>
                            </div>
                            <div class="evento-org-info">
                                <h2 id="ev-modal-org-nome">—</h2>
                                <span class="evento-org-tipo">Organizador · Pessoa Jurídica · Clique para ver
                                    perfil</span>
                                <div class="evento-org-status-pill">
                                    <i class="fa-solid fa-circle"></i>
                                    <span>Ativo na plataforma</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="evento-saiba-mais-body">
                        <div class="evento-saiba-mais-grid">
                            <div class="evento-saiba-mais-sidebar">
                                <div class="evento-info-card">
                                    <h3><i class="fa-solid fa-circle-info"></i> Sobre o Evento</h3>
                                    <div class="evento-info-row">
                                        <span class="evento-info-label">Nome</span>
                                        <span class="evento-info-value" id="ev-modal-nome">—</span>
                                    </div>
                                    <div class="evento-info-row">
                                        <span class="evento-info-label">Data</span>
                                        <span class="evento-info-value" id="ev-modal-data">—</span>
                                    </div>
                                    <div class="evento-info-row">
                                        <span class="evento-info-label">Local</span>
                                        <span class="evento-info-value" id="ev-modal-local">—</span>
                                    </div>
                                    <div class="evento-info-row">
                                        <span class="evento-info-label">Vagas</span>
                                        <span class="evento-info-value" id="ev-modal-vagas">—</span>
                                    </div>
                                    <div class="evento-info-row">
                                        <span class="evento-info-label">Status</span>
                                        <span class="evento-info-value" id="ev-modal-status">—</span>
                                    </div>
                                    <div class="evento-info-row">
                                        <span class="evento-info-label">Organiz.</span>
                                        <span class="evento-info-value" id="ev-modal-org">—</span>
                                    </div>
                                </div>

                                <button id="btn-modal-interesse" class="evento-btn-interesse open-generic-modal"
                                    data-config="eventoInteresse" data-perfil="organizador">
                                    <i class="fa-solid fa-heart"></i> Me Interesso
                                </button>
                            </div>

                            <div class="evento-saiba-mais-main">
                                <div class="evento-detail-card">
                                    <h2 id="ev-modal-titulo-detalhe">—</h2>
                                    <p id="ev-modal-descricao">—</p>
                                </div>

                                <div class="evento-tags-card">
                                    <p class="evento-section-title">
                                        <i class="fa-solid fa-hashtag"></i> Tags do Evento
                                    </p>
                                    <div class="event-tags" id="ev-modal-tags"></div>
                                </div>

                                <div class="evento-gallery-card">
                                    <p class="evento-section-title">
                                        <i class="fa-solid fa-images"></i> Galeria de Imagens
                                    </p>
                                    <div class="evento-gallery-grid gallery-grid" id="ev-modal-galeria"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- Modal Me Interesso — Evento (azul) -->
        <dialog id="evento-interesse-modal">
            <div class="interesse-container">
                <div class="interesse-header-banner">
                    <button class="interesse-close close-modal" data-modal="evento-interesse-modal">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                    <h2>Mostre seu Interesse!</h2>
                    <span>Escreva algo objetivo — ex: "Boa tarde! Gostaria de participar como colaborador de..."</span>
                </div>
                <div class="interesse-body">
                    <div class="interesse-textarea-block">
                        <label for="ev-interesse-textarea">Mensagem</label>
                        <textarea id="ev-interesse-textarea" maxlength="500"
                            placeholder="Seja claro com seu pedido, ele só pode ser enviado uma única vez!"></textarea>
                        <span class="interesse-char-count" id="ev-interesse-char-count">0 / 500</span>
                    </div>
                    <div class="interesse-btns">
                        <button class="interesse-btn-confirmar" id="ev-confirmar-interesse">
                            <i class="fa-solid fa-check" style="margin-right:6px"></i> Enviar Mensagem
                        </button>
                        <button class="interesse-btn-cancelar close-modal" data-modal="evento-interesse-modal">
                            Mudei de Ideia
                        </button>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- Modal Perfil do Organizador — tema CLARO -->
        <dialog id="organizador-modal">
            <div class="modal-overlay">
                <div class="org-modal-container">
                    <div class="org-modal-banner">
                        <button class="org-modal-close close-modal" data-modal="organizador-modal">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                        <div class="org-modal-identity">
                            <div class="org-logo-wrapper">
                                <img id="org-modal-logo" src="../assets/src/pfp/Konan.png" alt="logo empresa"
                                    class="org-logo">
                                <div class="org-verified-badge" title="Organizador Verificado">
                                    <i class="fa-solid fa-check"></i>
                                </div>
                            </div>
                            <div class="org-identity-info">
                                <h2 id="org-modal-nome">Otome Company</h2>
                                <span class="org-tipo">Organizador · Pessoa Jurídica</span>
                                <div class="org-status-pill">
                                    <i class="fa-solid fa-circle"></i>
                                    <span>Ativo na plataforma</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="org-modal-body">
                        <div class="org-tabs">
                            <button class="org-tab active" data-tab="org-tab-perfil">
                                <i class="fa-solid fa-building"></i> Perfil
                            </button>
                            <button class="org-tab" data-tab="org-tab-eventos">
                                <i class="fa-solid fa-calendar-days"></i> Eventos
                            </button>
                            <button class="org-tab" data-tab="org-tab-mensagem">
                                <i class="fa-solid fa-message"></i> Mensagem
                            </button>
                        </div>

                        <div class="org-tab-content active" id="org-tab-perfil">
                            <div class="org-grid">
                                <div class="org-sidebar">
                                    <div class="org-info-card">
                                        <h3><i class="fa-solid fa-circle-info"></i> Sobre a Empresa</h3>
                                        <div class="org-info-row">
                                            <span class="org-info-label">CNPJ</span>
                                            <span class="org-info-value" id="org-modal-cnpj">—</span>
                                        </div>
                                        <div class="org-info-row">
                                            <span class="org-info-label">Área</span>
                                            <span class="org-info-value" id="org-modal-area">—</span>
                                        </div>
                                        <div class="org-info-row">
                                            <span class="org-info-label">Localização</span>
                                            <span class="org-info-value" id="org-modal-local">—</span>
                                        </div>
                                        <div class="org-info-row">
                                            <span class="org-info-label">Telefone</span>
                                            <span class="org-info-value" id="org-modal-telefone">—</span>
                                        </div>
                                        <div class="org-info-row">
                                            <span class="org-info-label">Site</span>
                                            <span class="org-info-value"><a id="org-modal-site" href="#"
                                                    target="_blank">—</a></span>
                                        </div>
                                    </div>
                                    <div class="org-social-card">
                                        <h3><i class="fa-solid fa-share-nodes"></i> Redes Sociais</h3>
                                        <div class="org-socials">
                                            <a id="org-social-instagram" href="#" target="_blank"
                                                class="org-social-btn">
                                                <i class="fa-brands fa-instagram"></i>
                                            </a>
                                            <a id="org-social-linkedin" href="#" target="_blank" class="org-social-btn">
                                                <i class="fa-brands fa-linkedin"></i>
                                            </a>
                                            <a id="org-social-maps" href="#" target="_blank" class="org-social-btn">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </a>
                                        </div>
                                    </div>
                                    <div class="org-stats-card">
                                        <div class="org-stat">
                                            <span class="org-stat-num" id="org-stat-eventos">0</span>
                                            <span class="org-stat-label">Eventos</span>
                                        </div>
                                        <div class="org-stat-divider"></div>
                                        <div class="org-stat">
                                            <span class="org-stat-num" id="org-stat-colaboradores">0</span>
                                            <span class="org-stat-label">Colaboradores</span>
                                        </div>
                                        <div class="org-stat-divider"></div>
                                        <div class="org-stat">
                                            <span class="org-stat-num" id="org-stat-anos">0</span>
                                            <span class="org-stat-label">Anos</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="org-main">
                                    <div class="org-descricao-card">
                                        <h3><i class="fa-solid fa-quote-left"></i> Sobre</h3>
                                        <p id="org-modal-descricao">—</p>
                                    </div>
                                    <div class="org-galeria-card">
                                        <h3><i class="fa-solid fa-images"></i> Galeria</h3>
                                        <div class="org-gallery-grid" id="org-modal-galeria"></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="org-tab-content" id="org-tab-eventos">
                            <div class="org-eventos-list" id="org-eventos-list"></div>
                        </div>

                        <div class="org-tab-content" id="org-tab-mensagem">
                            <div class="org-mensagem-box">
                                <div class="org-mensagem-header">
                                    <i class="fa-solid fa-paper-plane"></i>
                                    <h3>Envie uma Mensagem</h3>
                                    <p>Entre em contato diretamente com o organizador.</p>
                                </div>
                                <textarea id="org-mensagem-textarea" maxlength="500"
                                    placeholder="Ex: Boa tarde! Gostaria de saber mais sobre o evento..."></textarea>
                                <span class="org-char-count" id="org-mensagem-count">0 / 500</span>
                                <div class="org-mensagem-btns">
                                    <button class="org-btn-enviar" id="org-btn-enviar-mensagem">
                                        <i class="fa-solid fa-paper-plane"></i> Enviar Mensagem
                                    </button>
                                    <button class="org-btn-cancelar close-modal"
                                        data-modal="organizador-modal">Fechar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </dialog>

        <!-- Toasts -->
        <div class="avaliar-toast" id="avaliar-toast">
            <i class="fa-solid fa-star"></i> Avaliação enviada com sucesso!
        </div>
        <div class="editar-toast" id="editar-toast">
            <i class="fa-solid fa-circle-check"></i> Pedido de Edição enviado com sucesso!
        </div>
        <div class="interesse-toast" id="interesse-toast">
            <i class="fa-solid fa-circle-check"></i> Interesse registrado com sucesso!
        </div>
        <div class="interesse-toast" id="ev-interesse-toast">
            <i class="fa-solid fa-circle-check"></i> Interesse no evento registrado!
        </div>

        <!-- Lightbox -->
        <dialog id="lightbox-overlay" class="lightbox-overlay">
            <div class="lightbox-container">
                <button id="lightbox-close" class="lightbox-close" aria-label="Fechar">
                    <i class="fa-solid fa-xmark"></i>
                </button>
                <button id="lightbox-prev" class="lightbox-arrow lightbox-prev" aria-label="Anterior">
                    <i class="fa-solid fa-chevron-left"></i>
                </button>
                <div class="lightbox-img-wrapper">
                    <img id="lightbox-img" src="" alt="Imagem ampliada">
                </div>
                <button id="lightbox-next" class="lightbox-arrow lightbox-next" aria-label="Próxima">
                    <i class="fa-solid fa-chevron-right"></i>
                </button>
                <div class="lightbox-counter">
                    <span id="lightbox-current">1</span> / <span id="lightbox-total">2</span>
                </div>
            </div>
        </dialog>
    </main>

    <footer id="suporte">

        <!-- Ondinha de transição do event-section para o footer -->
        <svg class="footer-wave" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 80" preserveAspectRatio="none">
            <path d="M0,40 C360,80 1080,0 1440,50 L1440,0 L0,0 Z" fill="#1a1a2e" />
        </svg>

        <div class="footer-content">
            <div class="footer-grid">

                <!-- ── COLUNA 1 — Marca e Redes Sociais ── -->
                <div class="footer-col-brand">
                    <img src="../assets/src/warpfiyLogo.png" alt="Warpfiy" class="footer-logo">
                    <p class="footer-tagline">
                        Conectando organizadores e colaboradores no universo dos eventos socioculturais. Simples, direto
                        e eficiente.
                    </p>
                    <div class="footer-social-row">
                        <a href="#" target="_blank" class="footer-social-btn" title="Instagram">
                            <i class="fa-brands fa-instagram"></i>
                        </a>
                        <a href="#" target="_blank" class="footer-social-btn" title="LinkedIn">
                            <i class="fa-brands fa-linkedin-in"></i>
                        </a>
                        <a href="#" target="_blank" class="footer-social-btn" title="Facebook">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                        <a href="#" target="_blank" class="footer-social-btn" title="TikTok">
                            <i class="fa-brands fa-tiktok"></i>
                        </a>
                        <a href="#" target="_blank" class="footer-social-btn" title="WhatsApp">
                            <i class="fa-brands fa-whatsapp"></i>
                        </a>
                    </div>
                </div>

                <!-- ── COLUNA 2 — Links Rápidos ── -->
                <div class="footer-col-links">
                    <h3 class="footer-col-title">Navegação</h3>
                    <ul class="footer-links-list">
                        <li>
                            <a href="#slider">
                                <i class="fa-solid fa-chevron-right"></i>
                                Conheça o Warpfiy
                            </a>
                        </li>
                        <li>
                            <a href="#card-section">
                                <i class="fa-solid fa-chevron-right"></i>
                                Cards de Colaboradores
                            </a>
                        </li>
                        <li>
                            <a href="#event-section">
                                <i class="fa-solid fa-chevron-right"></i>
                                Eventos Ativos
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-chevron-right"></i>
                                Cadastre-se como Colaborador
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-chevron-right"></i>
                                Cadastre-se como Organizador
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-chevron-right"></i>
                                Política de Privacidade
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa-solid fa-chevron-right"></i>
                                Termos de Uso
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- ── COLUNA 3 — Contato e Formulário Rápido ── -->
                <div class="footer-col-contact">
                    <h3 class="footer-col-title">Suporte</h3>
                    <ul class="footer-contact-list">
                        <li class="footer-contact-item">
                            <div class="footer-contact-icon">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <div>
                                <span class="footer-contact-label">E-mail</span>
                                <a href="mailto:suporte@warpfiy.com" class="footer-contact-value">
                                    suporte@warpfiy.com
                                </a>
                            </div>
                        </li>
                        <li class="footer-contact-item">
                            <div class="footer-contact-icon">
                                <i class="fa-solid fa-clock"></i>
                            </div>
                            <div>
                                <span class="footer-contact-label">Atendimento</span>
                                <span class="footer-contact-value">Seg – Sex, 09h às 18h</span>
                            </div>
                        </li>
                        <li class="footer-contact-item">
                            <div class="footer-contact-icon">
                                <i class="fa-solid fa-location-dot"></i>
                            </div>
                            <div>
                                <span class="footer-contact-label">Localização</span>
                                <span class="footer-contact-value">Brasília – DF, Brasil</span>
                            </div>
                        </li>
                    </ul>

                    <!-- Formulário rápido de contato -->
                    <div class="footer-form">
                        <div class="footer-form-row">
                            <input type="email" class="footer-input" placeholder="Seu e-mail" id="footer-email-input">
                            <button class="footer-submit-btn" id="footer-submit-btn">
                                <i class="fa-solid fa-paper-plane"></i>
                                Enviar
                            </button>
                        </div>
                        <input type="text" class="footer-input" placeholder="Como podemos te ajudar?"
                            id="footer-msg-input">
                    </div>
                </div>

            </div>

            <!-- ── Rodapé inferior ── -->
            <div class="footer-bottom">
                <p class="footer-copy">
                    © 2026 <span>Warpfiy</span>. Todos os direitos reservados.
                </p>
                <div class="footer-bottom-links">
                    <a href="#">Privacidade</a>
                    <a href="#">Termos</a>
                    <a href="#">Cookies</a>
                </div>
                <div class="footer-made-with">
                    <span>Feito com</span>
                    <i class="fa-solid fa-heart"></i>
                    <span>em Brasília</span>
                </div>
            </div>
        </div>

    </footer>

    <script>
    const CARDS_DO_BANCO = <?= $cardsJson ?>;
</script>
<script src="../assets/js/home/card-dinamico.js"></script>

    <script src="../assets/js/home/header.js"></script>
    <script src="../assets/js/home/flipcard.js"></script>
    <script src="../assets/js/home/card.js"></script>
    <script src="../assets/js/home/modal.js"></script>
    <script src="../assets/js/home/event-section.js"></script>
    <script src="../assets/js/script.js"></script>
    <script src="../assets/js/home/footer.js"></script>
</body>

</html>