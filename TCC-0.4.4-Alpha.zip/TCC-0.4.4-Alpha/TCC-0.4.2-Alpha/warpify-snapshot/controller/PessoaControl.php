<?php
session_start();
if (isset($_SESSION["usuario"])) {
    $id_usuario_login = $_SESSION["usuario"]["id"];
} else
    $id_usuario_login = "";

require_once __DIR__ . "/../model/dto/UsuarioDTO.php";
require_once __DIR__ . "/../model/dto/PessoaDTO.php";

require_once __DIR__ . "/../model/dao/UsuarioDAO.php";
require_once __DIR__ . "/../model/dao/PessoaDAO.php";


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Captura e limpeza de dados
    $acao = $_POST['acao'] ?? '';
    $nome_completo = trim($_POST["nome_completo"] ?? "");
    $nome_social = trim($_POST["nome_social"] ?? "");
    $cpf = trim($_POST["cpf"] ?? "");
    $cnpj = trim($_POST["cnpj"] ?? "");
    $rg = trim($_POST["rg"] ?? "");
    $telefone_movel = trim($_POST["telefone_movel"] ?? "");
    $telefone_fixo = trim($_POST["telefone_fixo"] ?? "");
    $cep_end = trim($_POST["cep_end"] ?? "");
    $logradouro_end = trim($_POST["logradouro_end"] ?? "");
    $numero_end = trim($_POST["numero_end"] ?? "");
    $complemento_end = trim($_POST["complemento_end"] ?? "");
    $bairro_end = trim($_POST["bairro_end"] ?? "");
    $localidade_end = trim($_POST["localidade_end"] ?? "");
    $uf_end = trim($_POST["uf_end"] ?? "");

    // Validação básica de campos obrigatórios
    if (empty($nome_completo) || (empty($cpf) && empty($cnpj))) {
        echo "<script>alert('Por favor, preencha os campos obrigatórios (Nome, CPF).'); window.history.back();</script>";
        exit;
    }

    try {
        if ($acao == "cadastrar") {

            // ── 1. CRIAR O USUÁRIO (email + senha) ──────────────────────
            $email = trim($_POST['email'] ?? '');
            $senha = $_POST['senha'] ?? '';
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

            if (empty($email) || empty($senha)) {
                echo "<script>alert('Por favor, preencha o e-mail e a senha.'); window.history.back();</script>";
                exit;
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "<script>alert('O e-mail informado é inválido.'); window.history.back();</script>";
                exit;
            }

            $usuarioDTO = new UsuarioDTO();
            $usuarioDTO->setemail(htmlspecialchars($email));
            $usuarioDTO->setsenha_hash($senha_hash);
            $usuarioDTO->setativo(1);
            $usuarioDTO->setdata_criacao(date("Y-m-d H:i:s"));

            $usuarioDAO = new UsuarioDAO();
            $usuario_id = $usuarioDAO->cadastrar($usuarioDTO); // retorna lastInsertId

            if (!$usuario_id) {
                echo "<script>alert('Erro ao criar o usuário! Tente novamente.'); window.history.back();</script>";
                exit;
            }

            // ── 2. VINCULAR O PAPEL AO USUÁRIO ──────────────────────────
            // papel_id 4 = "Usuário" (cliente padrão). Ajuste conforme seu banco.
            $papel_id = (int) ($_POST['papel_id'] ?? 4);
            $usuarioDAO->inserirUsuarioPapel($usuario_id, $papel_id);

            // ── 3. CRIAR A PESSOA com o usuario_id recém-gerado ─────────
            $pessoaDTO = new PessoaDTO();
            $pessoaDTO->setusuario_id($usuario_id);
            $pessoaDTO->setnome_completo(htmlspecialchars($nome_completo));
            $pessoaDTO->setnome_social(htmlspecialchars($nome_social));
            $pessoaDTO->setcpf(htmlspecialchars($cpf));
            $pessoaDTO->setcnpj(htmlspecialchars($cnpj));
            $pessoaDTO->setrg(htmlspecialchars($rg));
            $pessoaDTO->settelefone_movel(htmlspecialchars($telefone_movel));
            $pessoaDTO->settelefone_fixo(htmlspecialchars($telefone_fixo));
            $pessoaDTO->setcep_end(htmlspecialchars($cep_end));
            $pessoaDTO->setlogradouro_end(htmlspecialchars($logradouro_end));
            $pessoaDTO->setnumero_end(htmlspecialchars($numero_end));
            $pessoaDTO->setcomplemento_end(htmlspecialchars($complemento_end));
            $pessoaDTO->setbairro_end(htmlspecialchars($bairro_end));
            $pessoaDTO->setlocalidade_end(htmlspecialchars($localidade_end));
            $pessoaDTO->setuf_end(htmlspecialchars($uf_end));

            $pessoaDAO = new PessoaDAO();
            $id_pessoa_inserida = $pessoaDAO->cadastrar($pessoaDTO);

            if ($id_pessoa_inserida) {
                $papel_id = $_POST['papel_id'] ?? 4; // 4 = Usuário padrão
                $usuarioDAO->inserirUsuarioPapel($usuario_id, (int) $papel_id);

                echo "<script>alert('Cadastro realizado com sucesso! Faça login para entrar.'); window.location='../view/login-cadastro.php';</script>";
            } else {
                echo "<script>alert('Erro ao cadastrar dados do perfil!'); window.history.back();</script>";
            }
        }

    } catch (PDOException $e) {
        die("Favor contactar o Suporte e informar que ocorreu o seguinte Erro na inclusão do USUÁRIO: " . $e->getMessage());
    }
}