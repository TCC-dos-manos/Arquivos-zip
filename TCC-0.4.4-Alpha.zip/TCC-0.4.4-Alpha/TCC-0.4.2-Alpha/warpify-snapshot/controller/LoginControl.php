<?php
session_start();

// Verifica se o campo correto foi enviado pelo formulário
if (!isset($_POST['documento'])) {
    header("location: ../index.php");
    exit;
}

require_once __DIR__ . "/../model/dao/Conexao.php";

$documento = $_POST['documento'] ?? '';
$tipo = $_POST['tipo_documento'] ?? 'email'; // 'email', 'cpf' ou 'cnpj'

// Montar a cláusula WHERE dinamicamente:
if ($tipo === 'cpf') {
    $where = "p.cpf = :documento";
} elseif ($tipo === 'cnpj') {
    $where = "p.cnpj = :documento";
} else {
    $where = "u.email = :documento";
}
// E ajustar o bindValue de ":email" para ":documento"
$senha = $_POST['senha'] ?? '';

try {
    $pdo = Conexao::getInstance();
    $sql = "SELECT u.*, u.id as id_usuario,
           p.*, p.id as id_pessoa,
           upapel.*, papel.nome as nome_papel,
           upapel.id as id_usuario_papel
    FROM usuario u
    INNER JOIN pessoa p ON u.id = p.usuario_id
    INNER JOIN usuario_papel upapel ON u.id = upapel.usuario_id
    INNER JOIN papel ON upapel.papel_id = papel.id
    WHERE $where LIMIT 1";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(":documento", $documento);
    $stmt->execute();
    $usuario = $stmt->fetch();

    if ($usuario) {
        if (!$usuario['ativo']) {
            echo "<script>alert('Usuário Inativo! Não pode entrar no sistema.'); window.history.back();</script>";
            exit;
        }

        if (password_verify($senha, $usuario['senha_hash'])) {

            // ── 1. MONTA A SESSÃO ────────────────────────────────────────
            $_SESSION['usuario'] = [
                'id' => $usuario['id_pessoa'],
                'id_usuario' => $usuario['id_usuario'],
                'nome' => empty($usuario['nome_social']) ? $usuario['nome_completo'] : $usuario['nome_social'],
                'email' => $usuario['email'],
                'papel' => $usuario['nome_papel'],
                'permissoes' => []
            ];

            // ── 2. BUSCA AS PERMISSÕES (RBAC) ───────────────────────────
            $sqlPermissoes = "
                SELECT per.recurso, per.acao
                FROM usuario_papel up
                JOIN papel_permissao pp ON up.papel_id = pp.papel_id
                JOIN permissao per ON pp.permissao_id = per.id
                WHERE up.usuario_id = :usuario_id
            ";
            $stmtPerm = $pdo->prepare($sqlPermissoes);
            $stmtPerm->execute(['usuario_id' => $usuario['id_usuario']]);
            $lista_permissoes = $stmtPerm->fetchAll();

            // ── 3. ESTRUTURA AS PERMISSÕES [recurso][acao] ───────────────
            foreach ($lista_permissoes as $row) {
                $recurso = $row['recurso'];
                $acao = $row['acao'];
                if (!isset($_SESSION['usuario']['permissoes'][$recurso])) {
                    $_SESSION['usuario']['permissoes'][$recurso] = [];
                }
                $_SESSION['usuario']['permissoes'][$recurso][] = $acao;
            }

            // ── 4. REDIRECIONA CONFORME O PAPEL ─────────────────────────
            switch ($_SESSION['usuario']['papel']) {
                case 'Administrador':
                    header("Location: ../view/admin/home_admin.php");
                    break;
                case 'Organizador':
                    header("Location: ../view/organizador/home_organizador.php");
                    break;
                case 'Colaborador':
                    header("Location: ../view/colaborador/home_colaborador.php");
                    break;
                case 'Usuário':
                    header("Location: ../view/cliente/home_cliente.php");
                    break;
                default:
                    header("Location: ../view/suporte/home_suporte.php");
            }
            exit;

        } else {
            echo "<script>alert('Senha incorreta! Verifique.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Usuário ou senha inválidos!'); window.history.back();</script>";
    }

} catch (PDOException $e) {
    die("Erro no login: " . $e->getMessage());
}