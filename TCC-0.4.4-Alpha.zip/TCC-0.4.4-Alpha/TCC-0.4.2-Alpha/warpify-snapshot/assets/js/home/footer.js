// ================================================== Footer — Formulário de Contato Rápido ==================================================

(function initFooterForm() {
    const emailInput = document.getElementById('footer-email-input');
    const msgInput = document.getElementById('footer-msg-input');
    const submitBtn = document.getElementById('footer-submit-btn');

    if (!submitBtn) return;

    submitBtn.addEventListener('click', () => {
        const email = emailInput?.value.trim();
        const msg = msgInput?.value.trim();

        if (!email || !msg) {
            // Marca os campos vazios visualmente
            if (!email && emailInput) {
                emailInput.style.borderColor = 'rgba(127, 22, 21, 0.6)';
                setTimeout(() => emailInput.style.borderColor = '', 2000);
            }
            if (!msg && msgInput) {
                msgInput.style.borderColor = 'rgba(127, 22, 21, 0.6)';
                setTimeout(() => msgInput.style.borderColor = '', 2000);
            }
            return;
        }

        // Simula envio (tutorial — sem backend)
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-circle-check"></i> Enviado!';
        submitBtn.style.background = 'linear-gradient(135deg, #2d7a3a 0%, #4caf70 100%)';

        if (emailInput) emailInput.value = '';
        if (msgInput) msgInput.value = '';

        setTimeout(() => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Enviar';
            submitBtn.style.background = '';
        }, 3500);
    });
})();