function renderizarCards(cards) {
    const container = document.getElementById("card-lista-dinamica");
    if (!container) return;

    container.innerHTML = "";

    cards.forEach(card => {
        const tagsHtml = card.tags.map(t =>
            `<a href="#card-section" class="tag open-generic-modal"
                data-config="tagModal"
                data-perfil="colaborador">${t}</a>`
        ).join("");

        container.innerHTML += `
        <div class="card-content" data-card-id="${card.id}">
          <div class="card">
            <div class="top-card">
              <div>
                <h2 class="title-card">${card.titulo}</h2>
                <div class="tags-box">${tagsHtml}</div>
              </div>
              <button class="open-generic-modal"
                      data-config="pfpModal"
                      data-perfil="colaborador">
                <img class="profile-img"
                     src="../assets/src/pfp/Netulin.png"
                     alt="${card.colaborador_nome}">
              </button>
            </div>

            <div class="meio-card">
              <div class="card-img">
                <div class="img-box on">
                  <img src="${card.banner_url ?? '../assets/src/card/banner.png'}"
                       alt="${card.titulo}">
                </div>
                <button class="card-carousel-prev" aria-label="Anterior">
                  <i class="fa-solid fa-chevron-left"></i>
                </button>
                <button class="card-carousel-next" aria-label="Próxima">
                  <i class="fa-solid fa-chevron-right"></i>
                </button>
              </div>
            </div>

            <div class="bottom-card">
              <p class="texto-descricao">${card.descricao}</p>
              <div class="card-action">
                <button class="open-generic-modal"
                        data-config="confirmaAvaliacao"
                        data-perfil="organizador">
                  <i class="fa-solid fa-star avalie"></i>
                </button>
                <button class="btn-saiba-mais-dinamico"
                        data-card-id="${card.id}">
                  Saiba Mais
                </button>
              </div>
            </div>
          </div>
        </div>`;
    });

    registrarListeners();
    inicializarCarrosseis();
}

// Re-registra os listeners do modal.js nos elementos gerados dinamicamente
function registrarListeners() {
    document.querySelectorAll(".open-generic-modal").forEach(btn => {
        // Remove listener antigo para não duplicar
        btn.replaceWith(btn.cloneNode(true));
    });
    document.querySelectorAll(".open-generic-modal").forEach(btn => {
        btn.addEventListener("click", () => {
            const perfil = btn.getAttribute("data-perfil") || "colaborador";
            window.openModalWithConfig(btn.getAttribute("data-config"), perfil);
        });
    });

    document.querySelectorAll(".btn-saiba-mais-dinamico").forEach(btn => {
        btn.addEventListener("click", () => {
            const cardId = parseInt(btn.getAttribute("data-card-id"));
            abrirSaibaMais(cardId);
        });
    });
}

// Re-inicializa o carrossel para os novos cards
function inicializarCarrosseis() {
    document.querySelectorAll(".card-img").forEach(cardImg => {
        const slides = cardImg.querySelectorAll(".img-box");
        if (!slides.length) return;
        let index = 0;

        cardImg.querySelector(".card-carousel-prev")
            ?.addEventListener("click", () => irPara(index - 1));
        cardImg.querySelector(".card-carousel-next")
            ?.addEventListener("click", () => irPara(index + 1));

        function irPara(novoIndex) {
            slides[index].classList.remove("on");
            index = (novoIndex + slides.length) % slides.length;
            slides[index].classList.add("on");
        }
    });
}

// Preenche e abre o modal "Saiba Mais" com dados do card correto
function abrirSaibaMais(cardId) {
    const card = CARDS_DO_BANCO.find(c => c.id == cardId);
    if (!card) return;

    document.getElementById("ev-modal-nome")?.
        setAttribute && (document.getElementById("ev-modal-nome").textContent = card.titulo);
    document.getElementById("ev-modal-descricao").textContent = card.descricao;
    document.getElementById("ev-modal-org").textContent = card.colaborador_nome;

    // Atualiza a galeria do modal com o banner do card
    const galeria = document.getElementById("ev-modal-galeria");
    if (galeria) {
        galeria.innerHTML = `
            <div class="gallery-item">
              <img src="${card.banner_url ?? '../assets/src/card/banner.png'}"
                   alt="${card.titulo}">
            </div>`;
    }

    document.getElementById("saiba-mais-modal")?.showModal();
}

// Ponto de entrada: usa os dados injetados pelo PHP
document.addEventListener("DOMContentLoaded", () => {
    if (typeof CARDS_DO_BANCO !== "undefined" && CARDS_DO_BANCO.length > 0) {
        renderizarCards(CARDS_DO_BANCO);
    }
});