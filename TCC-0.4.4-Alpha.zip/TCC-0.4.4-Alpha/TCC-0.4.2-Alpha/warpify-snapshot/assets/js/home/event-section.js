// ============================================================
//  EVENTO ATIVO — edite apenas este objeto para mudar tudo
// ============================================================

const EVENTO_ATIVO = {
    nome: "Festival de Arte Digital 2026",
    status: "ativo",            // "ativo" | "encerrado" | "em breve"
    banner: "../assets/src/card/banner3.png",
    tags: ["#Arte", "#Digital", "#Festival"],
    organizador: {
        nome: "Otome Company",
        img: "../assets/src/pfp/Konan.png",
    },
    data: "20 Jun — 25 Jun, 2025",
    local: "Brasília / Online",
    vagas: "12 vagas restantes",
    descricao: "Um festival dedicado a conectar organizadores e colaboradores da área de artes digitais. Banners, identidade visual, motion design e muito mais — tudo em um só lugar.",
    // Galeria exibida no modal Saiba Mais (pode colocar caminhos locais)
    galeria: [
        "../assets/src/card/banner3.png",
        "../assets/src/card/banner4.png",
        "../assets/src/card/banner5.png",
        "../assets/src/card/banner6.png",
    ],
};

// ============================================================
//  Preenche o card e o modal com os dados do EVENTO_ATIVO
// ============================================================

(function renderizarEvento() {
    const ev = EVENTO_ATIVO;

    // ── Card principal ──────────────────────────────────────
    document.getElementById("ev-banner").src = ev.banner;
    document.getElementById("ev-banner").alt = ev.nome;
    document.getElementById("ev-nome").textContent = ev.nome;
    document.getElementById("ev-data").textContent = ev.data;
    document.getElementById("ev-local").textContent = ev.local;
    document.getElementById("ev-vagas").textContent = ev.vagas;
    document.getElementById("ev-descricao").textContent = ev.descricao;
    document.getElementById("ev-org-img").src = ev.organizador.img;
    document.getElementById("ev-org-img").alt = ev.organizador.nome;
    document.getElementById("ev-org-nome").textContent = ev.organizador.nome;

    // Status badge
    const badgeTextos = { ativo: "Ativo", encerrado: "Encerrado", "em breve": "Em Breve" };
    const badgeIcones = { ativo: "fa-circle", encerrado: "fa-circle-xmark", "em breve": "fa-clock" };
    document.getElementById("ev-status-text").textContent = badgeTextos[ev.status] ?? ev.status;
    const badgeIcon = document.querySelector("#ev-badge i");
    if (badgeIcon) {
        badgeIcon.className = `fa-solid ${badgeIcones[ev.status] ?? "fa-circle"}`;
    }

    // Tags no card
    const tagsEl = document.getElementById("ev-tags");
    tagsEl.innerHTML = ev.tags.map(t =>
        `<a href="#eventos" class="tag open-generic-modal" data-config="tagModal" data-perfil="organizador">${t}</a>`
    ).join("");

    // Nova função para "avisar" ao navegador sobre os novos botões
    function replicarListenersTagsEvento() {
        document.querySelectorAll('#ev-tags .open-generic-modal, #ev-modal-tags .open-generic-modal').forEach(button => {
            button.addEventListener('click', () => {
                const perfil = button.getAttribute('data-perfil') || 'organizador';
                window.openModalWithConfig(button.getAttribute('data-config'), perfil);
            });
        });
    }

    // Chamada da função no final da renderização
    (function renderizarEvento() {
        // ... (código de preenchimento)
        replicarListenersTagsEvento(); // <--- Adicionado aqui
    })();

    // ── Modal Saiba Mais ────────────────────────────────────
    document.getElementById("ev-modal-org-img").src = ev.organizador.img;
    document.getElementById("ev-modal-org-nome").textContent = ev.organizador.nome;
    document.getElementById("ev-modal-nome").textContent = ev.nome;
    document.getElementById("ev-modal-data").textContent = ev.data;
    document.getElementById("ev-modal-local").textContent = ev.local;
    document.getElementById("ev-modal-vagas").textContent = ev.vagas;
    document.getElementById("ev-modal-status").textContent = badgeTextos[ev.status] ?? ev.status;
    document.getElementById("ev-modal-org").textContent = ev.organizador.nome;
    document.getElementById("ev-modal-titulo-detalhe").textContent = ev.nome + " — Detalhes";
    document.getElementById("ev-modal-descricao").textContent = ev.descricao;

    // Tags no modal
    const tagsModal = document.getElementById("ev-modal-tags");
    tagsModal.innerHTML = ev.tags.map(t =>
        `<a href="#eventos" class="tag">${t}</a>`
    ).join("");

    // Galeria no modal
    const galeria = document.getElementById("ev-modal-galeria");
    galeria.innerHTML = ev.galeria.map(src =>
        `<div class="gallery-item"><img src="${src}" alt="foto evento"></div>`
    ).join("");
})();

// Preenche a aba Eventos do organizador-modal com o evento ativo
(function preencherEventosOrganizador() {
    const lista = document.getElementById('org-eventos-list');
    if (!lista) return;
    const ev = EVENTO_ATIVO;

    lista.innerHTML = `
        <div class="org-evento-item">
            <img src="${ev.banner}" alt="${ev.nome}" class="org-evento-img">
            <div class="org-evento-info">
                <p class="org-evento-nome">${ev.nome}</p>
                <div class="org-evento-meta">
                    <span><i class="fa-solid fa-calendar"></i> ${ev.data}</span>
                    <span><i class="fa-solid fa-location-dot"></i> ${ev.local}</span>
                </div>
            </div>
            <div class="org-evento-badge ativo">Ativo</div>
        </div>
    `;

    document.getElementById('org-stat-eventos').textContent = '1'
})();

// ============================================================
//  Botões do card: Saiba Mais e Me Interesso
// ============================================================
document.getElementById("btn-ev-saiba-mais")?.addEventListener("click", () => {
    document.getElementById("evento-saiba-mais-modal").showModal();
});

document.getElementById("btn-ev-interesse")?.addEventListener("click", () => {
    if (usuarioJaInteressouEvento) {
        openModalWithConfig("eventoJaInteressou");
    } else {
        openModalWithConfig("eventoConfirmaInteresse");
    }
});

// Botão "Me Interesso" dentro do modal Saiba Mais
document.getElementById("btn-modal-interesse")?.addEventListener("click", () => {
    // O data-config já chama openModalWithConfig("eventoInteresse") via delegação,
    // mas precisamos checar se já demonstrou interesse antes de abrir.
    // O listener de delegação em modal.js vai chamar openModalWithConfig("eventoInteresse")
    // que por sua vez abre o modal — sobrescrevemos via config abaixo.
});

// ============================================================
//  Configs do Modal Genérico para o Evento
//  (adicione ao objeto modalConfigs existente no modal.js)
// ============================================================

// Injeta as configs no objeto global modalConfigs que já existe em modal.js
Object.assign(modalConfigs, {

    eventoConfirmaInteresse: {
        tagIcon: "fa-solid fa-triangle-exclamation",
        tagText: "Atenção!",
        title: "Registrar Interesse?",
        subtitle: "Tem certeza que deseja demonstrar interesse neste evento?",
        content: "Uma mensagem será enviada ao organizador. Você só pode enviar uma vez — seja objetivo!",
        primaryBtnText: "Estou Ciente",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById("generic-modal").close();
            document.getElementById("evento-interesse-modal").showModal();
        },
    },

    eventoInteresse: {
        tagIcon: "fa-solid fa-triangle-exclamation",
        tagText: "Atenção!",
        title: "Registrar Interesse?",
        subtitle: "Tem certeza que deseja demonstrar interesse neste evento?",
        content: "Uma mensagem será enviada ao organizador. Você só pode enviar uma vez — seja objetivo!",
        primaryBtnText: "Estou Ciente",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById("generic-modal").close();
            document.getElementById("evento-interesse-modal").showModal();
        },
    },

    eventoJaInteressou: {
        tagIcon: "fa-solid fa-circle-check",
        tagText: "Registrado!",
        title: "Você já demonstrou interesse",
        subtitle: "Seu interesse neste evento já foi registrado.",
        content: "O organizador entrará em contato em breve. Fique de olho!",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById("generic-modal").close();
        },
    },

});

// ============================================================
//  Modal Me Interesso — contador de caracteres + confirmar
// ============================================================
let usuarioJaInteressouEvento = false;

const evTextarea = document.getElementById("ev-interesse-textarea");
const evCharCount = document.getElementById("ev-interesse-char-count");
const evToast = document.getElementById("ev-interesse-toast");

evTextarea?.addEventListener("input", () => {
    evCharCount.textContent = `${evTextarea.value.length} / 500`;
});

document.getElementById("ev-confirmar-interesse")?.addEventListener("click", () => {
    const evInteresseModal = document.getElementById("evento-interesse-modal");
    if (evInteresseModal) evInteresseModal.close();
    evTextarea.value = "";
    evCharCount.textContent = "0 / 500";
    usuarioJaInteressouEvento = true;
    mostrarToastEvento();
});

function mostrarToastEvento() {
    evToast.classList.add("show");
    setTimeout(() => evToast.classList.remove("show"), 3000);
}

// ============================================================
//  Galeria do modal Saiba Mais do Evento (reaproveita lightbox)
// ============================================================
document.getElementById("ev-modal-galeria")?.addEventListener("click", function (e) {
    const item = e.target.closest(".gallery-item");
    if (!item) return;

    lightboxImages = Array.from(
        document.querySelectorAll("#ev-modal-galeria .gallery-item img")
    ).map(img => img.src);

    const index = Array.from(
        document.querySelectorAll("#ev-modal-galeria .gallery-item")
    ).indexOf(item);

    abrirLightbox(index);
});

// ============================================================
//  Flipcards da event-section — highlight no card
// ============================================================
document.querySelectorAll(".flipcard-container-event").forEach(flipcard => {
    flipcard.addEventListener("click", () => {
        const jaEstaFlipped = flipcard.classList.contains("flipped");

        document.querySelectorAll(".flipcard-container-event").forEach(f => f.classList.remove("flipped"));
        document.querySelectorAll(".event-highlight").forEach(el => el.classList.remove("event-highlight"));

        if (!jaEstaFlipped) {
            flipcard.classList.add("flipped");

            const targetClass = flipcard.getAttribute("data-highlight");
            if (!targetClass) return;

            const target = targetClass === "event-card-content"
                ? document.querySelector(".event-card-content")
                : document.querySelector(`.event-card-content .${targetClass}`);

            if (target) target.classList.add("event-highlight");
        }
    });
});