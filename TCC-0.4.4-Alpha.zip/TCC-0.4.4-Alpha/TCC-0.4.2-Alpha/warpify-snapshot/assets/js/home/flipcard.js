// --------------------------------------------------- Flipcard Click ---------------------------------------------------

document.querySelectorAll('.flipcard-container').forEach(flipcard => {
    flipcard.addEventListener('click', () => {
        const jaEstaFlipped = flipcard.classList.contains('flipped');

        document.querySelectorAll('.flipcard-container').forEach(f => f.classList.remove('flipped'));
        document.querySelectorAll('.highlighted').forEach(el => el.classList.remove('highlighted'));

        if (!jaEstaFlipped) {
            flipcard.classList.add('flipped');

            const targetClass = flipcard.getAttribute('data-highlight');
            if (!targetClass) return;

            // Sobe no DOM para achar o preview container irmão mais próximo
            const section = flipcard.closest('section');
            const previewContainer = section?.querySelector('[class*="card-content"]');
            if (!previewContainer) return;

            const target = targetClass === previewContainer.className.split(' ')[0]
                ? previewContainer
                : previewContainer.querySelector(`.${targetClass}`);

            if (target) target.classList.add('highlighted');
        }
    });
});

// --------------------------------------------------- Fim Flipcard Click ---------------------------------------------------
