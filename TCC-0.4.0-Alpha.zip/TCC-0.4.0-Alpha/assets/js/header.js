/* ------------------------------------------- Usando o JQUERY ( Substituir depois ) ------------------------------------------- */

$(document).ready(function () {
    $('#mobile-btn').on('click', function () {
        $('#mobile-menu').toggleClass('active');
        $('#mobile-btn').find('i').toggleClass('fa-caret-right');
    });
});

/* ------------------------------------------------------ Usando o JS padrão Feito com IA ---------------------------------------------------- */

const navItems = document.querySelectorAll('.nav-item');
const allLinks = document.querySelectorAll('.nav-item a[data-target]');
const sections = document.querySelectorAll('section[id]');
const mobileBtn = document.getElementById('mobile-btn');
const mobileMenu = document.getElementById('mobile-menu');
const HEADER_HEIGHT = 80;

function easeInOutCubic(t) {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function smoothScrollTo(targetY, duration = 900) {
    const startY = window.scrollY;
    const distance = targetY - startY;
    let startTime = null;
    function step(timestamp) {
        if (!startTime) startTime = timestamp;
        const progress = Math.min((timestamp - startTime) / duration, 1);
        window.scrollTo(0, startY + distance * easeInOutCubic(progress));
        if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
}

let activeTimeout = null;

function setActive(id) {
    clearTimeout(activeTimeout);
    activeTimeout = setTimeout(() => {
        navItems.forEach(item => {
            const link = item.querySelector('a[data-target]');
            if (!link) return;
            item.classList.toggle('active', link.dataset.target === id);
        });
    }, 300); // delay de 300ms
}

allLinks.forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        const target = document.getElementById(link.dataset.target);
        if (!target) return;
        smoothScrollTo(target.offsetTop - HEADER_HEIGHT, 900);
        setActive(link.dataset.target);
        mobileMenu.classList.remove('active');
    });
});

window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
        if (section.getBoundingClientRect().top <= HEADER_HEIGHT + 20) current = section.id;
    });
    if (current) setActive(current);
}, { passive: true });

mobileBtn.addEventListener('click', () => mobileMenu.classList.toggle('active'));