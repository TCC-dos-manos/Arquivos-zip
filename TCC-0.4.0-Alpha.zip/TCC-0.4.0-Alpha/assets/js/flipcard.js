// --------------------------------------------------- Flipcard Click ---------------------------------------------------

document.querySelectorAll('.flipcard-container').forEach(flipcard => {
    flipcard.addEventListener('click', () => {
        const jaEstaFlipped = flipcard.classList.contains('flipped');

        // Fecha todos e remove todos os highlights
        document.querySelectorAll('.flipcard-container').forEach(f => f.classList.remove('flipped'));
        document.querySelectorAll('.card-highlight').forEach(el => el.classList.remove('card-highlight'));

        // Se não estava flipped, abre este e destaca o alvo
        if (!jaEstaFlipped) {
            flipcard.classList.add('flipped');

            const targetClass = flipcard.getAttribute('data-highlight');
            if (!targetClass) return;

            const target = targetClass === 'card-content'
                ? document.querySelector('.card-content')
                : document.querySelector(`.card-content .${targetClass}`);

            if (target) target.classList.add('card-highlight');
        }
    });
});

// --------------------------------------------------- Fim Flipcard Click ---------------------------------------------------
