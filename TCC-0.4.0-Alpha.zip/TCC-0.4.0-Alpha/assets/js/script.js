/* Usando Js padrão para animar o Carrossel */

let imgSlider = document.querySelectorAll('.slider-container .img-slider');
let btnNext = document.querySelector('#next-btn');
let btnPrev = document.querySelector('#prev-btn');
let btnNav = document.querySelectorAll('.btn-nav-box .btn-nav');

let contImg = imgSlider.length;
let imgOn = 0;

btnNext.addEventListener('click', ()=>{
    imgOn++;
    if(imgOn >= contImg){
        imgOn = 0;
    }
    monstrarSlider();
    pauseAutoSliderFor(15000);
});

btnPrev.addEventListener('click', ()=>{
    imgOn--;
    if(imgOn < 0){
        imgOn = contImg - 1;
    }
    monstrarSlider();
    pauseAutoSliderFor(15000);
});

function monstrarSlider(){
    let antigaImg = document.querySelector('.slider-container .img-slider.on');
    let antigoBtnNav = document.querySelector('.btn-nav-box .btn-nav.on');

    antigaImg.classList.remove('on');
    antigoBtnNav.classList.remove('on');

    imgSlider[imgOn].classList.add('on');

    btnNav[imgOn].classList.add('on');
};

btnNav.forEach((btn, indice)=>{
    btn.addEventListener('click', ()=>{
        imgOn = indice;
        monstrarSlider();
        pauseAutoSliderFor(15000);
    });
});

let autoSliderInterval;

function startAutoSlider() {
    clearInterval(autoSliderInterval);
    autoSliderInterval = setInterval(() => {
        imgOn = (imgOn + 1) % contImg;
        monstrarSlider();
    }, 5000);
}

function resetAutoSlider() {
    clearInterval(autoSliderInterval);
    setTimeout(startAutoSlider, 5000);
}

function pauseAutoSliderFor(ms) {
    clearInterval(autoSliderInterval);
    
    setTimeout(() => {
        startAutoSlider();
    }, ms);
}

startAutoSlider();