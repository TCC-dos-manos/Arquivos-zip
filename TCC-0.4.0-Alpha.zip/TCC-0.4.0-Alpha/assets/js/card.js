// ---- Carrossel do Card ----
document.querySelectorAll('.card-img').forEach(cardImg => {
    const slides = cardImg.querySelectorAll('.img-box');
    let index = 0;

    function irPara(novoIndex) {
        slides[index].classList.remove('on');
        index = (novoIndex + slides.length) % slides.length;
        slides[index].classList.add('on');
    }

    cardImg.querySelector('.card-carousel-prev')
        .addEventListener('click', () => irPara(index - 1));
    cardImg.querySelector('.card-carousel-next')
        .addEventListener('click', () => irPara(index + 1));
});