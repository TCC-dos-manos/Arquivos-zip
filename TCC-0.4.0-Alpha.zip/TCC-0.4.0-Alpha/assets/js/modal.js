// --------------------------------------------------- Modal Padrão ------------------------------------------------ 

// Para que o modal Padrão fique dinámico transformaremos ele em um objeto.

const modalConfigs = {
    perfilCompleto: {
        tagIcon: 'fa-solid fa-user',
        tagText: 'Perfil',
        title: "Conheça o Perfil",
        subtitle: 'Você irá visualizar o perfil completo de Perk',
        content: "Este é somente um tutorial, o perfil não será aberto de fato...",
        primaryBtnText: "Ver Perfil",
        secundaryBtnText: "X",
        callback: () => {
            console.log("Perfil aberto");
            // O modal será fechado pelo botão secundário (se visível) ou por outro mecanismo.
            // Se não houver botão secundário, você pode adicionar um fechamento aqui se desejar.
            document.getElementById('generic-modal').close();
        }
    },
    confirmarMensagem: {
        tagIcon: 'fa-solid fa-envelope',
        tagText: 'Confirmar',
        title: "Tem Certeza?",
        subtitle: "tem certeza que deseja enviar a mensagem: ",
        content: "Você enviará uma mensagem pessoal ao colaborador Perk, ela não terá relação com nenhum Card.",
        primaryBtnText: "Tenho Certeza",
        secundaryBtnText: "X",
        callback: () => {
            console.log("Mensagem Enviada");
            document.getElementById('generic-modal').close();
            openModalWithConfig('mensagemSucesso'); // Abre o próximo modal
        }
    },
    mensagemSucesso: {
        tagIcon: 'fa-solid fa-envelope-circle-check',
        tagText: 'Enviada',
        title: "Sucesso!",
        subtitle: "Sua mensagem foi enviada com sucesso!",
        content: "O colaborador Perk receberá sua mensagem em breve. Mas Lembre-se que isso é apenas um Tutorial!",
        primaryBtnText: "Entendido",
        secundaryBtnText: "", // Vazio para ocultar o botão secundário
        callback: () => {
            console.log("Modal de sucesso fechado");
            // O modal será fechado pelo botão secundário (se visível) ou por outro mecanismo.
            document.getElementById('generic-modal').close();
        }
    },
    confirmaAvaliacao: {
        tagIcon: 'fa-solid fa-triangle-exclamation',
        tagText: 'Atenção!',
        title: "Opa! Parece que você não pode comentar nesse Card",
        subtitle: "O Organizador apenas poderá comentar após confirmar que a negociação foi feita com o dono do Card.",
        content: "Porém como isso é um tutorial, clique em 'Liberar Acesso' para avaliar o serviço.",
        primaryBtnText: "Liberar Acesso",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            if (usuarioJaAvaliou) {
                openModalWithConfig('jaAvaliou');
            } else {
                document.getElementById('avaliar-modal').showModal();
            }
        }
    },
    pfpModal: {
        tagIcon: 'fa-solid fa-user',
        tagText: 'Perfil',
        title: "Conheça o Perfil do Profissional",
        subtitle: "Você irá visualizar o perfil de Perk.",
        content: "Atenção! Este é apenas um preview do perfil do profissional pois é um tutorial, você poderá visualizar todas as informações do profissional ao logar no nosso site.",
        primaryBtnText: "Ver Perfil",
        secundaryBtnText: "X",
        callback: () => {
            console.log("Modal de Confirmar Avaliação");
            document.getElementById('generic-modal').close();
            document.getElementById('previa-modal').showModal();
        }
    },
    closeToHome: {
        tagIcon: 'fa-solid fa-circle-question',
        tagText: 'Certeza?',
        title: "Fechar Prévia do Perfil?",
        subtitle: "Deseja mesmo sair da prévia do perfil e voltar ao início?",
        content: "Atenção! Todos os modais já abertos serão fechados, caso mude de ideia clique no 'X' acima",
        primaryBtnText: "Tenho Certeza",
        secundaryBtnText: "X",
        callback: () => {
            console.log("Modal de Confirmar Avaliação");

            const previewNavItems = document.querySelectorAll('#previa-modal .list');
            previewNavItems.forEach(item => item.classList.remove('on'));
            if (previewNavItems[1]) previewNavItems[1].classList.add('on');

            document.getElementById('generic-modal').close();
            document.querySelectorAll('dialog[open]').forEach(modal => modal.close());
        },
        secundaryCallback: () => {
            const previewNavItems = document.querySelectorAll('#previa-modal .list');
            previewNavItems.forEach(item => item.classList.remove('on'));
            if (previewNavItems[1]) previewNavItems[1].classList.add('on');
        }
    },
    tagModal: {
        tagIcon: 'fa-solid fa-hashtag',
        tagText: 'Tags',
        title: "Como Funcionam as Tags?",
        subtitle: "Com elas você pode filtrar por cards com temas específicos.",
        content: "As tags são uma forma de facilitar a vida do Organizador, caso isso não fosse um tutorial você seria direcionado a uma página com cards com a mesma tag na qual clicou.",
        primaryBtnText: "Entendi",
        secundaryBtnText: "",
        callback: () => {
            console.log("Modal de Confirmar Avaliação");
            document.getElementById('generic-modal').close();
        }
    },
    editarMensagem: {
        tagIcon: 'fa-solid fa-pencil',
        tagText: 'Editar',
        title: "Atenção!",
        subtitle: "Você não pode editar o seu comentário a qualquer momento!",
        content: "Para que seu comentário seja editado, um administrador deverá avaliar antes, se a edição do mesmo faz sentido, clique 'Prosseguir' para enviar sua solicitação.",
        primaryBtnText: "Prosseguir",
        secundaryBtnText: "X",
        callback: () => {
            console.log("Modal de Confirmar Avaliação");
            document.getElementById('generic-modal').close();
            document.getElementById('solicitacao-editar').showModal();
        }
    },
    jaAvaliou: {
        tagIcon: 'fa-solid fa-circle-check',
        tagText: 'Avaliado!',
        title: "Você já avaliou este Card",
        subtitle: "Sua avaliação já foi registrada com sucesso.",
        content: "Você só pode avaliar um card uma vez. Caso queira alterar sua avaliação, solicite a um administrador clicando em 'Editar' no seu comentário dentro de 'Saiba Mais'.",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },
    meInteressei: {
        tagIcon: 'fa-solid fa-triangle-exclamation',
        tagText: 'Atenção!',
        title: "Registrar Interesse?",
        subtitle: "Tem certeza que deseja registrar seu interesse nesse card? Essa Ação não pode ser desfeita!",
        content: "Uma solicitação de interesse será enviada ao Colaborador em forma de mensagem, você poderá escrever uma mensagem direta. Dica: Tente ir direto ao ponto.",
        primaryBtnText: "Estou Ciente",
        secundaryBtnText: "X",
        callback: () => {
            document.getElementById('generic-modal').close();
            document.getElementById('me-interessei').showModal();
        }
    },
    jaInteressou: {
        tagIcon: 'fa-solid fa-circle-check',
        tagText: 'Interesse Registrado!',
        title: "Você já demonstrou interesse neste Card",
        subtitle: "Seu interesse já foi registrado com sucesso.",
        content: "Você só pode demonstrar interesse uma vez. O colaborador entrará em contato em breve!",
        primaryBtnText: "Entendido",
        secundaryBtnText: "",
        callback: () => {
            document.getElementById('generic-modal').close();
        }
    },

};

// Função principal para abrir o modal com base em uma configuração.
function openModalWithConfig(configKey) {
    const config = modalConfigs[configKey];
    if (!config) {
        console.error(`Configuração de modal '${configKey}' não encontrada.`);
        return;
    }

    // --- 1. Obter referências aos elementos do modal ---
    const genericModal = document.getElementById('generic-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalSubtitle = document.getElementById('modal-subtitle');
    const modalContent = document.getElementById('modal-content');
    const primaryBtn = document.getElementById('modal-primary-btn');
    const secundaryBtn = document.getElementById('modal-secundary-btn');
    const textArea = document.querySelector('.mensagem-textarea');
    const mensagemAtual = textArea ? textArea.value : "";
    const tagIcon = document.getElementById('modal-tag-icon');
    const tagText = document.getElementById('modal-tag-text');

    if (config.tagIcon) {
        tagIcon.className = `fa-solid ${config.tagIcon}`;
    }
    if (config.tagText) {
        tagText.textContent = config.tagText;
    }

    // --- 2. Preencher o conteúdo do modal ---
    modalTitle.textContent = config.title;
    modalContent.textContent = config.content;

    // Lógica para o subtítulo, incluindo a cor do texto do TextArea
    if (configKey === 'confirmarMensagem') {
        // Usa innerHTML para permitir tags HTML (<span>) para estilização.
        modalSubtitle.innerHTML = config.subtitle + `"<span style="color: #fff;">${mensagemAtual}</span>"?`;
    } else {
        modalSubtitle.textContent = config.subtitle;
    }

    // --- 3. Configurar e exibir/ocultar o Botão Primário ---
    // Verifica se o texto do botão primário está vazio ou contém apenas espaços.
    if (!config.primaryBtnText || config.primaryBtnText.trim() === '') {
        primaryBtn.style.display = 'none'; // Oculta o botão
    } else {
        primaryBtn.style.display = ''; // Exibe o botão (volta ao padrão CSS)
        primaryBtn.textContent = config.primaryBtnText; // Define o texto

        // Remove o listener antigo e adiciona um novo para evitar múltiplos eventos.
        const newPrimaryBtn = primaryBtn.cloneNode(true);
        primaryBtn.parentNode.replaceChild(newPrimaryBtn, primaryBtn);
        newPrimaryBtn.addEventListener('click', () => {
            config.callback(); // Executa a ação definida na configuração do modal
            // O fechamento do modal pelo botão primário é responsabilidade do callback, se necessário.
        });
    }

    // --- 4. Configurar e exibir/ocultar o Botão Secundário ---
    // Verifica se o texto do botão secundário está vazio ou contém apenas espaços.
    if (!config.secundaryBtnText || config.secundaryBtnText.trim() === '') {
        secundaryBtn.style.display = 'none'; // Oculta o botão
    } else {
        secundaryBtn.style.display = ''; // Exibe o botão (volta ao padrão CSS)
        secundaryBtn.textContent = config.secundaryBtnText; // Define o texto

        // Remove o listener antigo e adiciona um novo para o botão secundário.
        // O botão secundário SEMPRE fecha o modal.
        const newSecundaryBtn = secundaryBtn.cloneNode(true);
        secundaryBtn.parentNode.replaceChild(newSecundaryBtn, secundaryBtn);
        newSecundaryBtn.addEventListener('click', () => {
            if (config.secundaryCallback) config.secundaryCallback();
            genericModal.close();
        });
    }

    // --- 5. Abrir o modal ---
    genericModal.showModal();
}

// --- 6. Adicionar listeners aos botões que abrem o modal ---
// Percorre todos os botões com a classe 'open-generic-modal'.
document.querySelectorAll('.open-generic-modal').forEach(button => {
    button.addEventListener('click', () => {
        const configKey = button.getAttribute('data-config'); // Pega a chave da configuração do modal
        openModalWithConfig(configKey); // Abre o modal com a configuração correspondente
    });
});

// --------------------------------------------------- Fim Modal Padrão --------------------------------------------

// --------------------------------------------------- Função Modal ------------------------------------------------ 

const openModalButtons = document.querySelectorAll('.open-modal');

openModalButtons.forEach(button => {
    button.addEventListener('click', () => {
        const modalId = button.getAttribute('data-modal');
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.showModal();
        }
    });
});

const closeModalButtons = document.querySelectorAll('.close-modal');

closeModalButtons.forEach(button => {
    button.addEventListener('click', () => {
        const modalId = button.getAttribute('data-modal');
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.close();
        }
    });
});

// Botão para abrir outro modal (ex: "Ver Perfil" no pfp-modal abre previa-modal)
const openNestedModalButtons = document.querySelectorAll('[data-nested-modal]:not([data-nested-modal="galery-modal"])');

openNestedModalButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault();
        const currentModalId = button.closest('dialog').id;
        const nestedModalId = button.getAttribute('data-nested-modal');

        // Fecha o modal atual
        const currentModal = document.getElementById(currentModalId);
        if (currentModal) {
            currentModal.close();
        }

        // Abre o próximo modal após um pequeno delay
        setTimeout(() => {
            if (nestedModalId === 'previa-modal') {
                abrirPreviaModal();
            } else {
                const nestedModal = document.getElementById(nestedModalId);
                if (nestedModal) nestedModal.showModal();
            }
        }, 100);
    });
});

//--------------------------------------------------- Função Modal ------------------------------------------------ 

//--------------------------------------------------- Modal Previa Perfil ---------------------------------------------

// nav-bar do modal de perfil 
const list = document.querySelectorAll('.list');

function activeLink() {
    list.forEach((item) =>
        item.classList.remove('on'));
    this.classList.add('on');
}
list.forEach((item) =>
    item.addEventListener('click', activeLink));

//------------------------------------------------- Função de abrir a Nav-Bar ----------------------------------------------

const toggleNavbarBtn = document.getElementById('toggle-navbar');
const navBar = document.querySelector('.nav-bar');
const perfilCompleto = document.querySelector('.perfil-completo')

function abrirPreviaModal() {
    // Garante que a navbar começa FECHADA
    isOpen = false;
    if (toggleNavbarBtn) {
        toggleNavbarBtn.classList.remove('fa-align-left');
        toggleNavbarBtn.classList.add('fa-align-justify');
    }
    if (navBar) navBar.classList.remove('open');
    if (perfilCompleto) perfilCompleto.classList.add('on');

    // Reseta o nav para "Perfil" (segundo item)
    const previewNavItems = document.querySelectorAll('#previa-modal .list');
    previewNavItems.forEach(item => item.classList.remove('on'));
    if (previewNavItems[1]) previewNavItems[1].classList.add('on');

    // Abre o modal
    const previaModal = document.getElementById('previa-modal');
    if (previaModal) previaModal.showModal();
}

let isOpen = false;

if (toggleNavbarBtn && navBar) {

    toggleNavbarBtn.addEventListener('click', () => {
        isOpen = !isOpen;

        if (isOpen) {
            // Abre a navbar
            toggleNavbarBtn.classList.remove('fa-align-justify');
            toggleNavbarBtn.classList.add('fa-align-left');
            navBar.classList.add('open');
            perfilCompleto.classList.remove('on');
        } else {
            // Fecha a navbar
            toggleNavbarBtn.classList.remove('fa-align-left');
            toggleNavbarBtn.classList.add('fa-align-justify');
            navBar.classList.remove('open');
            setTimeout(() => {
                perfilCompleto.classList.add('on');
            }, 540);
        }
    });
}

// Reset ao abrir o modal de prévia (sempre começa fechado)
const previaModal = document.getElementById('previa-modal');
if (previaModal) {
    previaModal.addEventListener('show', () => {
        isOpen = false;
        if (toggleNavbarBtn) {
            toggleNavbarBtn.classList.remove('fa-align-left');
            toggleNavbarBtn.classList.add('fa-align-justify');
        }
        if (navBar) navBar.classList.remove('open');
    });
}

//--------------------------------------------------- Função de Enviar Mensagem (Organizado -> Colaborador) -------------------------------------------------

const mensagemBtn = document.getElementById('mensagem-btn');
const mensagemOverlay = document.getElementById('mensagem-overlay');
const closeMensagemBtn = document.getElementById('close-mensagem-overlay');

if (mensagemBtn) {
    mensagemBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (mensagemOverlay) {
            mensagemOverlay.classList.remove('hidden');
        }
    });
}

if (closeMensagemBtn) {
    closeMensagemBtn.addEventListener('click', () => {
        if (mensagemOverlay) {
            mensagemOverlay.classList.add('hidden');
        }
    });
}

if (closeMensagemBtn) {
    closeMensagemBtn.addEventListener('click', () => {
        // Reseta a navbar para Perfil
        const previewNavItems = document.querySelectorAll('#previa-modal .list');
        previewNavItems.forEach(item => item.classList.remove('on'));
        if (previewNavItems[1]) {
            previewNavItems[1].classList.add('on');
        }

        if (mensagemOverlay) {
            mensagemOverlay.classList.add('hidden');
        }
    });
}

//--------------------------------------------------- Galeria dentro do Perfil -------------------------------------------------

// Elemento do nav "Cards" no perfil para abrir galeria
const galeryNavBtn = document.getElementById('galery-nav-btn');
const galeryOverlay = document.getElementById('galery-overlay');
const closeGaleryBtn = document.getElementById('close-galery-overlay');

// Abrir galeria ao clicar em "Cards" no nav do perfil
if (galeryNavBtn) {
    galeryNavBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (galeryOverlay) {
            galeryOverlay.classList.remove('hidden');
        }
    });
}

// Fechar galeria e voltar ao perfil
if (closeGaleryBtn) {
    closeGaleryBtn.addEventListener('click', () => {
        if (galeryOverlay) {
            galeryOverlay.classList.add('hidden');
        }

        // Reseta o nav para "Perfil" quando volta da galeria
        const profileNavItem = document.querySelector('#previa-modal .list:nth-child(2)'); // Segundo item é "Perfil"
        if (profileNavItem) {
            list.forEach(item => item.classList.remove('on'));
            profileNavItem.classList.add('on');
        }
    });
}

//--------------------------------------------------- Fim Galeria Perfil -----------------------------------------------


//--------------------------------------------------- Lightbox da Galeria ---------------------------------------------------

// Feito pela IA :P

// Coleta todas as imagens da galeria e guarda os srcs em um array
// Assim o lightbox sabe quais imagens existem e pode navegar entre elas

let lightboxImages = [];  // Array com os srcs das imagens
let lightboxIndex = 0;   // Índice da imagem atualmente exibida

// Elementos do lightbox
const lightboxOverlay = document.getElementById('lightbox-overlay');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxCurrent = document.getElementById('lightbox-current');
const lightboxTotal = document.getElementById('lightbox-total');
const lightboxCloseBtn = document.getElementById('lightbox-close');
const lightboxPrevBtn = document.getElementById('lightbox-prev');
const lightboxNextBtn = document.getElementById('lightbox-next');

// Abre o lightbox na imagem clicada
function abrirLightbox(index) {
    lightboxIndex = index;
    atualizarLightbox();

    // Guarda qual dialog estava aberto para reabrir depois
    const dialogAberto = document.querySelector('dialog[open]:not(#lightbox-overlay)');
    lightboxOverlay.dataset.returnDialog = dialogAberto ? dialogAberto.id : '';
    if (dialogAberto) dialogAberto.close();

    lightboxOverlay.showModal();
}

// Fecha o lightbox na imagem clicada
function fecharLightbox() {
    lightboxOverlay.close();

    // Reabre o dialog de origem
    const returnId = lightboxOverlay.dataset.returnDialog;
    if (returnId) {
        const dialog = document.getElementById(returnId);
        if (dialog) dialog.showModal();
    }
}

// Atualiza a imagem exibida e o contador (ex: "1 / 2")
function atualizarLightbox() {
    lightboxImg.src = lightboxImages[lightboxIndex];
    lightboxCurrent.textContent = lightboxIndex + 1;
    lightboxTotal.textContent = lightboxImages.length;
}

// Vai para a próxima imagem (volta ao início quando chega no fim)
function proximaImagem() {
    lightboxIndex = (lightboxIndex + 1) % lightboxImages.length;
    atualizarLightbox();
}

// Vai para a imagem anterior (vai para o fim quando está na primeira)
function imagemAnterior() {
    lightboxIndex = (lightboxIndex - 1 + lightboxImages.length) % lightboxImages.length;
    atualizarLightbox();
}

// Registra o clique em cada imagem da galeria
// Usamos delegação de evento no galery-overlay para funcionar mesmo após o overlay ser exibido
document.getElementById('galery-overlay').addEventListener('click', function (e) {
    const imgClicada = e.target.closest('.galery-img');
    if (!imgClicada) return;

    // Recalcula o array de imagens a cada abertura (facilita adicionar/remover imagens depois)
    lightboxImages = Array.from(
        document.querySelectorAll('#galery-overlay .galery-img')
    ).map(img => img.src);

    const index = parseInt(imgClicada.dataset.index, 10);
    abrirLightbox(index);
});

// Botões de navegação e fechar
lightboxCloseBtn.addEventListener('click', fecharLightbox);
lightboxNextBtn.addEventListener('click', proximaImagem);
lightboxPrevBtn.addEventListener('click', imagemAnterior);

// Fecha ao clicar no fundo escuro (fora da imagem)
lightboxOverlay.addEventListener('click', function (e) {
    if (e.target === lightboxOverlay) fecharLightbox();
});

// Navegação pelo teclado: ← → para navegar, Esc para fechar
document.addEventListener('keydown', function (e) {
    if (!lightboxOverlay.open) return;
    if (e.key === 'ArrowRight') proximaImagem();
    if (e.key === 'ArrowLeft') imagemAnterior();
    if (e.key === 'Escape') fecharLightbox();
});

//--------------------------------------------------- Fim Lightbox da Galeria ---------------------------------------------------

//--------------------------------------------------- Galeria do Saiba Mais (reaproveita o lightbox) ----------------------------

document.querySelector('.gallery-grid')?.addEventListener('click', function (e) {
    const item = e.target.closest('.gallery-item');
    if (!item) return;

    // Coleta as imagens do .gallery-grid do saiba-mais
    lightboxImages = Array.from(
        document.querySelectorAll('.gallery-grid .gallery-item img')
    ).map(img => img.src);

    const index = Array.from(
        document.querySelectorAll('.gallery-grid .gallery-item')
    ).indexOf(item);

    abrirLightbox(index);
});

//--------------------------------------------------- Fim Galeria do Saiba Mais ---------------------------------------------------

//--------------------------------------------------------- Avaliar Modal ---------------------------------------------------------

//Labels por nota
const notaLabels = ['', 'Muito ruim', 'Ruim', 'Decente', 'Legal', 'Excelente!'];
let notaSelecionada = 0;

const modalStars = document.querySelectorAll('#modal-stars .modal-star');
const notaTexto = document.getElementById('avaliar-nota-texto');
const textarea = document.getElementById('avaliar-textarea');
const charCount = document.getElementById('avaliar-char-count');
const confirmarBtn = document.getElementById('confirmar-avaliacao');
const toast = document.getElementById('avaliar-toast');

function pintarEstrelas(val) {
    document.querySelectorAll('#modal-stars .modal-star').forEach(s => {
        const sv = parseInt(s.dataset.star);
        s.classList.toggle('fa-solid', sv <= val);
        s.classList.toggle('fa-regular', sv > val);
        s.classList.toggle('lit', sv <= val);
    });
}

// Listeners das estrelas
document.getElementById('modal-stars').addEventListener('mouseover', (e) => {
    const star = e.target.closest('.modal-star');
    if (!star) return;
    pintarEstrelas(parseInt(star.dataset.star));
    notaTexto.textContent = notaLabels[parseInt(star.dataset.star)];
});

document.getElementById('modal-stars').addEventListener('mouseout', (e) => {
    const star = e.target.closest('.modal-star');
    if (!star) return;
    pintarEstrelas(notaSelecionada);
    notaTexto.textContent = notaSelecionada ? notaLabels[notaSelecionada] : '';
});

document.getElementById('modal-stars').addEventListener('click', (e) => {
    const star = e.target.closest('.modal-star');
    if (!star) return;
    notaSelecionada = parseInt(star.dataset.star);
    pintarEstrelas(notaSelecionada);
    notaTexto.textContent = notaLabels[notaSelecionada];
});

let todasAsNotas = [];
let usuarioJaAvaliou = false;
let usuarioJaInteressou = false;

function calcularMedia() {
    if (todasAsNotas.length === 0) return 0;
    return todasAsNotas.reduce((a, b) => a + b, 0) / todasAsNotas.length;
}

function atualizarEstrelasCard(media) {
    const estrelas = document.querySelectorAll('#card-stars .fa-star');
    estrelas.forEach(star => {
        const sv = parseInt(star.dataset.star);
        star.classList.toggle('fa-solid', sv <= Math.round(media));
        star.classList.toggle('fa-regular', sv > Math.round(media));
    });

    const texto = document.getElementById('card-rating-text');
    if (texto) texto.textContent = `${media.toFixed(1)} (${todasAsNotas.length} avaliação${todasAsNotas.length > 1 ? 'ões' : ''})`;
}

function atualizarEstrelasSaibaMais(media) {
    const estrelas = document.querySelectorAll('#saiba-mais-stars .fa-star');
    estrelas.forEach(star => {
        const sv = parseInt(star.dataset.star);
        star.classList.toggle('fa-solid', sv <= Math.round(media));
        star.classList.toggle('fa-regular', sv > Math.round(media));
    });

    const numero = document.getElementById('saiba-mais-rating-numero');
    if (numero) numero.innerHTML = `${media.toFixed(1)}<span>/5</span>`;

    const texto = document.getElementById('saiba-mais-rating-text');
    if (texto) texto.textContent = `${todasAsNotas.length} avaliação${todasAsNotas.length > 1 ? 'ões' : ''}`;
}

function adicionarComentarioSaibaMais(comentario, nota) {
    const userSection = document.getElementById('userCommentSection');
    const userText = document.getElementById('userCommentText');
    const userNota = document.getElementById('user-comment-nota');
    const ratingEl = document.getElementById('user-comment-rating');

    if (userSection && userText) {
        if (nota) {
            userNota.textContent = nota;
            ratingEl.style.display = 'inline-flex';
        }
        if (comentario) userText.textContent = comentario;
        userSection.style.display = 'block';
    }
}

confirmarBtn.addEventListener('click', () => {
    if (notaSelecionada === 0) {
        notaTexto.textContent = '⚠ Selecione uma nota antes de continuar.';
        notaTexto.style.color = '#c0392b';
        setTimeout(() => {
            notaTexto.style.color = '';
            notaTexto.textContent = '';
        }, 2500);
        return;
    }

    const comentario = textarea.value.trim();

    todasAsNotas.push(notaSelecionada);
    usuarioJaAvaliou = true;
    const media = calcularMedia();

    atualizarEstrelasCard(media);
    atualizarEstrelasSaibaMais(media);

    adicionarComentarioSaibaMais(comentario, notaSelecionada);

    document.getElementById('avaliar-modal').close();
    resetarModal();
    mostrarToast();
});

document.getElementById('fecharAvaliarModal').addEventListener('click', resetarModal);
document.getElementById('cancelarAvaliacaoBtn').addEventListener('click', resetarModal);

function resetarModal() {
    notaSelecionada = 0;
    pintarEstrelas(0);
    notaTexto.textContent = '';
    textarea.value = '';
    charCount.textContent = '0 / 300';
    charCount.classList.remove('warn');
    document.getElementById('avaliar-modal').close();
}

function mostrarToast() {
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

//--------------------------------------------------------- Editar Modal ---------------------------------------------------------

const editarTextarea = document.getElementById('editar-textarea');
const editarCharCount = document.getElementById('editar-char-count');
const confirmarEditarBtn = document.getElementById('confirmar-editar');
const editarToast = document.getElementById('editar-toast');

// Contador de caracteres
editarTextarea.addEventListener('input', () => {
    const len = editarTextarea.value.length;
    editarCharCount.textContent = `${len} / 300`;
});

// Confirmar pedido
confirmarEditarBtn.addEventListener('click', () => {
    document.querySelectorAll('dialog[open]').forEach(modal => modal.close());
    editarTextarea.value = '';
    editarCharCount.textContent = '0 / 300';
    mostrarEditarToast();
});

function mostrarEditarToast() {
    editarToast.classList.add('show');
    setTimeout(() => editarToast.classList.remove('show'), 3000);
}

//--------------------------------------------------------- Me Interessei Modal ---------------------------------------------------------

const interesseTextarea = document.getElementById('interesse-textarea');
const interesseCharCount = document.getElementById('interesse-char-count');
const confirmarInteresseBtn = document.getElementById('confirmar-interesse');
const interesseToast = document.getElementById('interesse-toast');

// Contador de caracteres
interesseTextarea.addEventListener('input', () => {
    const len = interesseTextarea.value.length;
    interesseCharCount.textContent = `${len} / 500`;
});

// Confirmar interesse
confirmarInteresseBtn.addEventListener('click', () => {
    document.querySelectorAll('dialog[open]').forEach(modal => modal.close());
    interesseTextarea.value = '';
    interesseCharCount.textContent = '0 / 500';
    usuarioJaInteressou = true;
    mostrarInteresseToast();
});

document.getElementById('meInteresseiBtnModal').addEventListener('click', () => {
    if (usuarioJaInteressou) {
        openModalWithConfig('jaInteressou');
    } else {
        
    }
});

function mostrarInteresseToast() {
    interesseToast.classList.add('show');
    setTimeout(() => interesseToast.classList.remove('show'), 3000);
}
